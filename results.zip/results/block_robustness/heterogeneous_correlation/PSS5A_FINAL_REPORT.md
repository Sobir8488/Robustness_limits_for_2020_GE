# PSS-5A final report

Heterogeneous correlation closure: **True**.
G37 threshold closure: **True**.

The exact r^-2 A3 null model is not present in the frozen model family. No constant empirical cross-track surrogate is substituted.

No physical A2 or Yarkovsky detection is authorized by PSS-5A. The wider support-resampling, cross-code and radar boundaries remain controlling.
