# PSS-5B2A station parallax-radius ablation — recovered finalization

The nonlinear science calculation completed before the v1.0.0 post-processing
NameError. This report is reconstructed from the frozen PASS baseline replay,
station-scale runtime audit, radius audit, and the already-written final
rho=0 harmonized result.

- OrbFit target parallax radius: **6378136.300000 m**
- Tudat Earth average radius: **6371008.366667 m**
- parallax-constant scale factor: **1.001118807718**
- maximum body-fixed station shift: **7129.949 m**

Frozen Tudat A2:
`-1.9127881663788407e-12 au d^-2`

Harmonized Tudat A2:
`-1.9058268866388961e-12 au d^-2`

Frozen |A2,T|/|A2,O|:
`4.632897980`

Harmonized |A2,T|/|A2,O|:
`4.616037305`

Relative A2 shift:
`0.363934%`

Fraction of the log-amplitude gap removed:
`0.237804%`

Harmonized final objective:
`688.408851503`

The objective at the *frozen baseline parameters under the harmonized station
scale* was computed in memory by v1.0.0 but had not yet been serialized when
the post-processing NameError occurred, so it is intentionally recorded as
unavailable rather than reconstructed from an unsupported assumption.

Reciprocal no-refit chi-square ratios were not recomputed in this substage.
No physical A2, Yarkovsky, or single-cause claim is authorized.
