# PSS-5B1 force-law equivalence report

Frozen cross-code amplitude ratio: **4.632898**.

Same-state OrbFit/Tudat instantaneous transverse-force ratio:
- minimum: **0.987418412**
- median: **0.999710679**
- maximum: **1.00057578**
- maximum |ratio-1|: **1.258%**
- minimum direction cosine: **1.000000000000**

The observed factor-4.633 coefficient gap is outside the instantaneous force-normalization range sampled on the frozen same-state trajectory.

This stage does not re-estimate either orbit and therefore does not alter the frozen reciprocal no-refit chi-square ratios (370.026, 12861.052).

Physical A2 and Yarkovsky claims remain blocked.
