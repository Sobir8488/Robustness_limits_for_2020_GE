# PSS-5B3R relativity ablation

Recovered OrbFit configuration:
- `propag.def`: `irel = 0`
- actual `2020GE.fop`: no `irel` override

Controlled Tudat change:
- baseline: Sun point-mass gravity + Schwarzschild correction
- ablation: Sun point-mass gravity only
- all other force, observation, weighting, integration, and fitting settings frozen

Frozen Tudat A2:
`-1.9127881663788407e-12 au d^-2`

Relativity-off Tudat A2:
`-1.8987885193314833e-12 au d^-2`

Frozen |A2,T|/|A2,O|:
`4.632897980`

Relativity-off |A2,T|/|A2,O|:
`4.598989919`

Relative A2 shift:
`0.731897%`

Fraction of the log-amplitude gap removed:
`0.479127%`

Baseline objective:
`666.265674114`

Relativity-off objective at frozen baseline parameters:
`2885.6795915`

Relativity-off final objective:
`724.252960926`

Reciprocal no-refit chi-square ratios are not recomputed in this substage.
No physical A2, Yarkovsky, or single-cause claim is authorized.
