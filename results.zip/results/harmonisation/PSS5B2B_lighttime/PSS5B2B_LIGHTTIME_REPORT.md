# PSS-5B2B light-time iteration sensitivity

OrbFit effective configuration: `iaber=1`.
Tudat branches restrict the iterative light-time solution to 1 or 2 iterations.
This is a sensitivity test, not an exact OrbFit aber1 emulator.

## max1
- A2 = `-1.9127879760863535e-12 au d^-2`
- |A2,T|/|A2,O| = `4.632897519`
- relative A2 shift = `0.000010%`
- log-gap removed = `0.000006%`
- final objective = `666.265648386`
- converged = `True`

## max2
- A2 = `-1.9127879760863535e-12 au d^-2`
- |A2,T|/|A2,O| = `4.632897519`
- relative A2 shift = `0.000010%`
- log-gap removed = `0.000006%`
- final objective = `666.265648386`
- converged = `True`

Reciprocal no-refit metrics are not recomputed here.
No physical A2, Yarkovsky, or single-cause claim is authorized.
