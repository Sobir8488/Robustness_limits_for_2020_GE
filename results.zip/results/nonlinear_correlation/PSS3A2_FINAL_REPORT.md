# PSS3-A2 nonlinear correlated-likelihood report

## Method
For each prescribed within-station-night equicorrelation coefficient, the full seven-parameter Tudat M_Y orbit was re-estimated by an external generalized Gauss-Newton loop. Each outer iteration re-integrated the Tudat dynamics and variational equations at the current state-force vector, extracted the 102x7 design matrix and 102 scalar residuals, solved the block-correlated GLS normal problem, and accepted the step only when the full correlated objective decreased.

RA and Dec are treated as separate correlation channels within each station-night; the original scalar sigmas are retained on the covariance diagonal.

## Results

- rho=0.00: status=STATIONARY_NO_RESOLVABLE_IMPROVEMENT, A2=-1.912788e-12 au d^-2, sigma_scaled=1.532648e-14, 95%=[-1.942828e-12, -1.882748e-12], Q=666.265648.
- rho=0.25: status=STATIONARY_NO_RESOLVABLE_IMPROVEMENT, A2=-1.911008e-12 au d^-2, sigma_scaled=1.574350e-14, 95%=[-1.941866e-12, -1.880151e-12], Q=559.113966.
- rho=0.50: status=CONVERGED, A2=-1.910126e-12 au d^-2, sigma_scaled=1.643597e-14, 95%=[-1.942340e-12, -1.877911e-12], Q=516.488457.
- rho=0.75: status=STATIONARY_NO_RESOLVABLE_IMPROVEMENT, A2=-1.910235e-12 au d^-2, sigma_scaled=1.803050e-14, 95%=[-1.945575e-12, -1.874896e-12], Q=569.952823.
- rho=0.90: status=STATIONARY_NO_RESOLVABLE_IMPROVEMENT, A2=-1.914551e-12 au d^-2, sigma_scaled=2.091194e-14, 95%=[-1.955538e-12, -1.873563e-12], Q=842.717879.

## Claim disposition
This calculation closes the specific reviewer question of whether the local off-diagonal covariance result survives full nonlinear re-estimation. It does not, by itself, authorize a physical A2 or Yarkovsky detection. The publication claim remains controlled by the wider evidence hierarchy: support-conditioned station-night resampling, G37 practical-identifiability diagnostics, cross-code same-candidate transport, and radar closure.

Numerical closure ready: **True**.
Overall Phase-3 scientific closure ready: **True**.
