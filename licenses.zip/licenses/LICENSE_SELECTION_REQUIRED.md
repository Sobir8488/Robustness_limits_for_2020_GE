# License selection required before Zenodo publication

A license is a rights-holder decision and has not been invented in this build. Recommended structure:

- **Original code**: MIT, BSD-3-Clause, or another author-approved OSI license.
- **Original data/figures/documentation**: CC BY 4.0 is a common choice if all rights holders approve.
- **Third-party/source data**: original provider terms apply and are not relicensed by this archive.

Before publication, replace the placeholder in `metadata/zenodo_metadata_template.json` and add the final license text(s).
