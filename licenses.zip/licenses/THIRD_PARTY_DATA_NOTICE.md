# Third-party data notice

Some input records originate from external astronomical services/catalogues (including MPC/JPL-derived material). Inclusion here is for reproducibility. No license selected for the authors' original materials should be interpreted as relicensing third-party content. Users must respect the original providers' terms, attribution requirements, and applicable public-data policies. OrbFit binaries/source trees and external ephemeris binaries are not redistributed in this package.
