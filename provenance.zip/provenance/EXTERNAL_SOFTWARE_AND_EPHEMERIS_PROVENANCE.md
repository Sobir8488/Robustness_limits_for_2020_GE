# External software and ephemeris provenance

The following runtime assets are required for exact end-to-end replay but are not redistributed in this Zenodo archive.

- OrbFit executable: `fitobs.x`, OrbFit 5.0.8 Stage-3F2 build.
  - SHA256: `b1fd3e0e1c154f5415a75beef7c33d18bc71661c723831369cb3d106361c373b`
- OrbFit planetary ephemeris: `jpleph.431.1000_3000` (DE431).
  - SHA256: `ae41cc5166dd824f55f0566165bc89b182383da6684263def38b5ea207aa3d8d`
- Tudat core source used in the frozen model family: `scripts/03_run_model_family.py`.
  - frozen source hash: `84686ac3da98dadc764188543ba81e5b4c840b0dc795d7b4a0aa6dbefe2af892`
- Frozen model configuration `stage2b.yaml`.
  - SHA256: `4223acbb41e74f85005f3dbf95318f37a4b1f71af583b9bc57bfb92d3dd05c07`
- Canonical prepared input data lineage hash used by the nonlinear-refit package: `1fbc469f4c4e5a5c7630c76feeafbd8e1e8351879b88a41cf25a7aa97c574d3a`.

The archive does not bundle third-party ephemeris binaries or an OrbFit installation. This avoids redistributing large/external runtime assets while retaining exact identity checks.
