# Figure Q1+ polish report

## Changes

- Rebuilt all six manuscript/supplement figures as vector PDFs.
- Raised final-scale labels/ticks/legends substantially (target ~10--11 / 9--10 / 9 pt).
- Increased line, error-bar, cap, and marker weights for two-column reduction.
- Reconstructed the two legacy figures from exact frozen numerical source data and added their source CSVs/scripts.
- Eliminated Type-3 Matplotlib fonts by forcing Type-42 PDF embedding.
- Increased the two full-width main-text figure placements to 0.96 and 0.98 text width, and the supplementary weighting figure to 0.82 text width.
- No scientific values, captions, claims, tables, equations, or references were changed.

## Scientific integrity

The work is graphical only. The residual chronology and temporal-LOO plots are regenerated from frozen project evidence; provenance hashes are recorded in `figure_sources/Q1PLUS_SOURCE_DATA_PROVENANCE.json`.
