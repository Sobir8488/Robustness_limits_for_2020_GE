# PSS-5A3 exact A3 null-model boundary

The frozen 2020 GE Tudat model family implements only `M0`, `M_SRP`, `M_Y`, and `M_SY`. The frozen source does not contain an estimatable standard normal `A3 (1 au/r)^2` component.

Tudat supports empirical RSW accelerations, including a cross-track component, but a constant empirical W acceleration is **not the same force law** as the manuscript's Marsden-style r^-2 normal coefficient. It would therefore be scientifically misleading to use it as a drop-in A3 null test.

PSS-5A intentionally does not fabricate this test. If A3 becomes necessary, implement and validate an exact r^-2 normal acceleration with an estimatable parameter and its partials as a separate frozen extension. Until then the paper should avoid saying A3 has been statistically rejected.
