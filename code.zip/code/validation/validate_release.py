from pathlib import Path
import hashlib,json,sys,re
ROOT=Path(__file__).resolve().parents[2]

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()

def fail(msg):
    print('FAIL:',msg); raise SystemExit(2)

manifest=ROOT/'MANIFEST_SHA256.txt'
if not manifest.is_file(): fail('MANIFEST_SHA256.txt missing')
for line in manifest.read_text(encoding='utf-8').splitlines():
    if not line.strip(): continue
    h,rel=line.split('  ',1); p=ROOT/rel
    if not p.is_file(): fail(f'missing manifest file: {rel}')
    if sha(p)!=h: fail(f'hash mismatch: {rel}')

# Manuscript must be absent. Figures are allowed; manuscript/supplement source is not.
forbidden_exact={'main.tex','main.pdf','supplementary_material.tex','supplementary_material.pdf','references.bib','main.bbl','supplementary_material.bbl','highlights.txt'}
for p in ROOT.rglob('*'):
    if p.is_file() and p.name.lower() in forbidden_exact:
        fail(f'forbidden manuscript asset present: {p.relative_to(ROOT)}')
    low=str(p.relative_to(ROOT)).lower()
    if '/manuscript/' in '/'+low:
        fail(f'manuscript directory present: {low}')

req=[
 'data/optical/2020_GE_prepared_fallback_1.csv',
 'data/radar/2020_GE__jpl_sb_radar_astrometry.csv',
 'configuration/stage2b.yaml',
 'code/core_pipeline/03_run_model_family.py',
 'code/nonlinear_correlation/pss3a2_nonlinear_correlated_refit.py',
 'results/main_tables/key_results_current.json',
 'results/main_tables/model_comparison.csv',
 'results/main_tables/table_external_closure_current.csv',
 'results/harmonisation/PSS5C_HARMONISATION_LEDGER.csv',
 'figures/fig_external_closure.pdf',
 'figures/fig_station_night_robustness.pdf',
]
for r in req:
    if not (ROOT/r).is_file(): fail(f'required release asset missing: {r}')

k=json.loads((ROOT/'results/main_tables/key_results_current.json').read_text(encoding='utf-8'))
checks={
 'optical_positions':51,
 'station_night_blocks':19,
 'radar_measurements':7,
 'Tudat_to_OrbFit_amplitude_ratio_abs':4.632897979626392,
 'physical_A2_detection_authorized':False,
 'Yarkovsky_detection_authorized':False,
}
for key,val in checks.items():
    if k.get(key)!=val: fail(f'key-result mismatch {key}: {k.get(key)!r} != {val!r}')

figs=list((ROOT/'figures').glob('*.pdf'))
if len(figs)!=6: fail(f'expected 6 final vector PDFs, got {len(figs)}')

print('ZENODO_RELEASE_CONTENT_VALIDATION=PASS')
print('MANUSCRIPT_INCLUDED=false')
print('FINAL_VECTOR_FIGURES=6')
print('SCIENTIFIC_CONTENT_FROZEN=true')
print('METADATA_PENDING=true')
