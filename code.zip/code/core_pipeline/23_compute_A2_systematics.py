from __future__ import annotations

import argparse
import math
from pathlib import Path

from _robustness_common import (
    TARGET, a2_from_summary, a2_sigma_from_summary, delete_group_jackknife,
    dump_json, load_json, project_root, read_table, require_project_files,
    sample_sd, write_csv,
)


def loo_values_from_files(root: Path, model: str) -> list[dict]:
    rows = []
    for cluster in range(5):
        path = root / "results" / "models" / f"2020_GE__{model}__fallback_1__exclude_cluster_{cluster}__summary.json"
        if not path.exists():
            return []
        data = load_json(path)
        rows.append({
            "excluded_cluster": cluster,
            "A2_estimated_au_d2": a2_from_summary(data),
            "A2_sigma_au_d2": a2_sigma_from_summary(data),
            "A2_z": float(data.get("A2_z", float("nan"))),
            "rms_residual_arcsec": float(data.get("rms_residual_arcsec", float("nan"))),
            "fit_valid": bool(data.get("fit_valid")),
        })
    return rows


def main() -> int:
    parser = argparse.ArgumentParser(description="Compute formal, temporal, weighting, and model-family A2 uncertainty components.")
    parser.add_argument("--allow-provisional-MSY", action="store_true", help="Use M_SY LOO only for a clearly labelled provisional diagnostic when M_Y LOO is absent.")
    args = parser.parse_args()

    root = project_root()
    require_project_files(root, [
        "results/models/2020_GE__M_Y__fallback_1__summary.json",
        "results/models/2020_GE__M_SY__fallback_1__summary.json",
    ])
    my = load_json(root / "results/models/2020_GE__M_Y__fallback_1__summary.json")
    msy = load_json(root / "results/models/2020_GE__M_SY__fallback_1__summary.json")
    full = a2_from_summary(my)
    formal = a2_sigma_from_summary(my)

    loo_model = "M_Y"
    loo_rows = loo_values_from_files(root, "M_Y")
    provisional = False
    if not loo_rows and args.allow_provisional_MSY:
        loo_model = "M_SY"
        loo_rows = loo_values_from_files(root, "M_SY")
        provisional = True
    if not loo_rows:
        raise FileNotFoundError("M_Y LOO outputs are absent. Run scripts/22_run_MY_cluster_loo.py first.")

    loo_values = [float(r["A2_estimated_au_d2"]) for r in loo_rows]
    jack = delete_group_jackknife(loo_values)
    loo_max_shift = max(abs(v - full) for v in loo_values)

    weight_values = []
    weight_rows = []
    for fallback in ("0.5", "1", "1.5"):
        path = root / "results" / "models" / f"2020_GE__M_Y__fallback_{fallback}__summary.json"
        if path.exists():
            data = load_json(path)
            value = a2_from_summary(data)
            weight_values.append(value)
            weight_rows.append({"variant": f"fallback_{fallback}_arcsec", "A2_estimated_au_d2": value})
    weight_sd = sample_sd(weight_values)
    weight_max_shift = max((abs(v - full) for v in weight_values), default=0.0)

    model_shift = abs(a2_from_summary(msy) - full)
    combined_transport = math.sqrt(formal**2 + jack["jackknife_se"]**2 + weight_sd**2)
    conservative_with_model = math.sqrt(combined_transport**2 + model_shift**2)

    drift_full = -0.08195  # published model-equivalent drift associated with the v0.5.8 M_Y baseline
    drift_scale = drift_full / full
    result = {
        "protocol_version": "0.6.0",
        "target_id": TARGET,
        "baseline_model": "M_Y",
        "loo_model_used": loo_model,
        "provisional_due_to_MSY_LOO_substitution": provisional,
        "A2_baseline_au_d2": full,
        "formal_sigma_au_d2": formal,
        "formal_fractional_sigma": formal / abs(full),
        "temporal_delete_cluster": jack,
        "temporal_max_abs_shift_from_MY_full_au_d2": loo_max_shift,
        "weighting_A2_values_au_d2": weight_values,
        "weighting_sample_sd_au_d2": weight_sd,
        "weighting_max_abs_shift_au_d2": weight_max_shift,
        "model_family_abs_shift_MY_vs_MSY_au_d2": model_shift,
        "combined_sigma_formal_plus_temporal_plus_weight_au_d2": combined_transport,
        "conservative_sigma_including_model_family_au_d2": conservative_with_model,
        "sensitivity_envelope_au_d2": [min([full, *loo_values, *weight_values]), max([full, *loo_values, *weight_values])],
        "model_equivalent_da_dt_au_Myr": drift_full,
        "formal_da_dt_sigma_au_Myr": abs(drift_scale) * formal,
        "transport_da_dt_sigma_au_Myr": abs(drift_scale) * combined_transport,
        "conservative_da_dt_sigma_au_Myr": abs(drift_scale) * conservative_with_model,
        "publication_rule": "Report the formal covariance separately from the temporal/weight/model sensitivity; do not collapse them into a sub-percent physical precision claim.",
        "final_gate_eligible": not provisional,
    }
    outdir = root / "results" / "systematics"
    dump_json(outdir / "2020_GE__M_Y__A2_systematic_uncertainty.json", result)

    components = [
        {"component": "formal_scaled_covariance", "sigma_or_shift_au_d2": formal, "role": "conditional statistical"},
        {"component": f"delete_cluster_jackknife_{loo_model}", "sigma_or_shift_au_d2": jack["jackknife_se"], "role": "temporal support"},
        {"component": "fallback_weight_sample_sd", "sigma_or_shift_au_d2": weight_sd, "role": "weight sensitivity"},
        {"component": "MY_vs_MSY_abs_shift", "sigma_or_shift_au_d2": model_shift, "role": "model-family sensitivity"},
        {"component": "combined_transport", "sigma_or_shift_au_d2": combined_transport, "role": "formal+temporal+weight"},
        {"component": "conservative_with_model", "sigma_or_shift_au_d2": conservative_with_model, "role": "sensitivity summary, not Gaussian likelihood"},
    ]
    write_csv(outdir / "2020_GE__M_Y__A2_systematic_uncertainty.csv", components)

    report = f"""# 2020 GE M_Y A2 uncertainty audit — protocol v0.6.0

- Baseline: `{full:.12e} au d^-2`
- Overdispersion-scaled formal sigma: `{formal:.12e}`
- Temporal LOO source: `{loo_model}`{' **(PROVISIONAL ONLY)**' if provisional else ''}
- Delete-cluster jackknife SE: `{jack['jackknife_se']:.12e}`
- Fallback-weight sample SD: `{weight_sd:.12e}`
- M_Y–M_SY absolute model shift: `{model_shift:.12e}`
- Combined formal+temporal+weight scale: `{combined_transport:.12e}`
- Conservative sensitivity scale including model family: `{conservative_with_model:.12e}`
- Sensitivity envelope: `[{result['sensitivity_envelope_au_d2'][0]:.12e}, {result['sensitivity_envelope_au_d2'][1]:.12e}]`

The formal covariance remains reproducible, but it is conditional on the selected force and weight model. The delete-cluster and model-family terms are sensitivity diagnostics and are not automatically interpreted as independent Gaussian errors. The manuscript must quote the formal value and the transport/systematic scale separately.
"""
    (outdir / "2020_GE__M_Y__A2_systematic_uncertainty.md").write_text(report, encoding="utf-8")
    if provisional:
        print("Systematic audit written in PROVISIONAL mode using M_SY LOO. It cannot finalize the M_Y claim.")
    else:
        print("M_Y systematic uncertainty audit: COMPLETE")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
