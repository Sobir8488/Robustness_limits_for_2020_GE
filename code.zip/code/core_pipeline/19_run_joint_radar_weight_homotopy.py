from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

import argparse
import json
import traceback

import pandas as pd

from darkcomet_stage2b.common import dump_json, ensure_directories, load_config, project_root, safe_slug
from darkcomet_stage2b.joint_homotopy import compact_stage_row, homotopy_stage_gate
from scripts_import_bridge import load_script_module


preflight_module = load_script_module(ROOT / "scripts" / "18_run_joint_optical_radar_preflight.py", "stage2b_joint_preflight")
_build_and_run = preflight_module._build_and_run


def _load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def _multiplier_slug(value: float) -> str:
    return f"{float(value):g}"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--target", default="2020 GE")
    parser.add_argument("--models", nargs="+", default=["M_SY", "M_Y"])
    parser.add_argument("--multipliers", nargs="+", type=float, default=None)
    parser.add_argument("--rerun-seed", action="store_true")
    parser.add_argument("--continue-on-error", action="store_true")
    args = parser.parse_args()

    cfg = load_config()
    ensure_directories(cfg)
    root = project_root()
    out_dir = root / cfg["paths"]["joint_directory"]
    out_dir.mkdir(parents=True, exist_ok=True)
    settings = cfg["radar_joint_homotopy"]
    configured = settings["stages"]
    configured_map = {float(x["multiplier"]): int(x["maximum_iterations"]) for x in configured}
    multipliers = [float(x) for x in (args.multipliers or [x["multiplier"] for x in configured])]
    if multipliers != sorted(multipliers, reverse=True):
        raise ValueError("Homotopy multipliers must be supplied in descending order")
    for m in multipliers:
        if m not in configured_map:
            raise ValueError(f"Multiplier {m:g} is not in the frozen homotopy schedule")

    all_rows = []
    model_results = {}
    failures = []
    slug = safe_slug(args.target)

    for model in args.models:
        previous_vector = None
        previous_source = "optical_only_best_fit"
        model_rows = []
        model_failures = []
        stopped = False

        for stage_index, multiplier in enumerate(multipliers):
            mslug = _multiplier_slug(multiplier)
            max_iterations = configured_map[multiplier]
            reused_seed = False

            # Reuse the already validated 1000x v0.5.1 preflight as the numerical
            # seed unless the user explicitly requests a rerun.  All lower-weight
            # stages are newly estimated and warm-start from the immediately
            # preceding accepted stage.
            if stage_index == 0 and multiplier == 1000.0 and not args.rerun_seed:
                seed_path = out_dir / f"{slug}__{model}__joint_preflight_radar_sigma_x1000__summary.json"
                if seed_path.exists():
                    seed = _load_json(seed_path)
                    if "total_postfit_nrms_improved" not in seed:
                        seed["total_postfit_nrms_improved"] = bool(
                            float(seed.get("total_postfit_nrms", float("inf")))
                            <= float(seed.get("total_prefit_nrms", float("-inf")))
                        )
                    if "force_parameter_diagnostics" not in seed:
                        initial_seed = seed.get("initial_parameter_vector", [])
                        final_seed = seed.get("final_parameter_vector", [])
                        if initial_seed and final_seed:
                            a2_initial = float(initial_seed[-1])
                            a2_final = float(final_seed[-1])
                            seed["force_parameter_diagnostics"] = {
                                "A2_initial_m_s2": a2_initial,
                                "A2_final_m_s2": a2_final,
                                "A2_optical_baseline_m_s2": a2_initial,
                                "A2_sign_consistent_with_optical_baseline": bool(
                                    (a2_initial < 0 and a2_final < 0) or (a2_initial > 0 and a2_final > 0)
                                ),
                                "A2_abs_ratio_to_optical_baseline": abs(a2_final / a2_initial) if a2_initial != 0.0 else None,
                                "srp_scale_final": float(final_seed[-2]) if model == "M_SY" else None,
                            }
                    seed.setdefault("warm_start_source", "optical_only_best_fit")
                    if bool(seed.get("joint_preflight_gate_pass", False)):
                        seed["homotopy_stage_gate_pass"], seed["homotopy_stage_checks"] = homotopy_stage_gate(seed, settings)
                        if seed["homotopy_stage_gate_pass"]:
                            reused_seed = True
                            previous_vector = seed["final_parameter_vector"]
                            previous_source = str(seed_path.relative_to(root)).replace("\\", "/")
                            row = compact_stage_row(seed, reused_seed=True)
                            row["stage_index"] = stage_index
                            model_rows.append(row)
                            all_rows.append(row)
                            continue

            try:
                summary = _build_and_run(
                    args.target,
                    model,
                    multiplier,
                    cfg,
                    initial_parameter_vector_override=previous_vector,
                    warm_start_source=previous_source,
                    maximum_iterations_override=max_iterations,
                    scope_override="staged joint optical-radar radar-weight homotopy",
                )
                summary["claim_boundary"] = (
                    "Numerical continuation diagnostic only. Even the formal-weight stage is not a publication-grade "
                    "joint solution until radar media, Earth-orientation, editing, and nuisance-model controls are frozen."
                )
                summary["homotopy_stage_gate_pass"], summary["homotopy_stage_checks"] = homotopy_stage_gate(summary, settings)
                summary["homotopy_stage_index"] = stage_index
                out = out_dir / f"{slug}__{model}__joint_homotopy_radar_sigma_x{mslug}__summary.json"
                dump_json(out, summary)
                row = compact_stage_row(summary, reused_seed=reused_seed)
                row["stage_index"] = stage_index
                model_rows.append(row)
                all_rows.append(row)
                print(json.dumps(summary, indent=2))

                if not summary["homotopy_stage_gate_pass"]:
                    stopped = True
                    model_failures.append({
                        "model": model,
                        "radar_sigma_multiplier": multiplier,
                        "error": "homotopy_stage_gate_failed",
                        "checks": summary["homotopy_stage_checks"],
                    })
                    break
                previous_vector = summary["final_parameter_vector"]
                previous_source = str(out.relative_to(root)).replace("\\", "/")
            except Exception as exc:
                stopped = True
                failure = {
                    "target_id": args.target,
                    "model": model,
                    "radar_sigma_multiplier": multiplier,
                    "error": str(exc),
                    "traceback": traceback.format_exc(),
                }
                model_failures.append(failure)
                failures.append(failure)
                dump_json(out_dir / f"{slug}__{model}__joint_homotopy_radar_sigma_x{mslug}__failure.json", failure)
                print(json.dumps(failure, indent=2))
                if not args.continue_on_error:
                    raise
                break

        completed = len(model_rows) == len(multipliers) and not stopped
        formal_rows = [r for r in model_rows if float(r["radar_sigma_multiplier"]) == 1.0]
        model_results[model] = {
            "model": model,
            "n_requested_stages": len(multipliers),
            "n_completed_stages": len(model_rows),
            "all_requested_stages_completed": completed,
            "all_completed_stage_gates_pass": bool(model_rows and all(bool(r.get("homotopy_stage_gate_pass")) for r in model_rows)),
            "formal_weight_stage_reached": bool(formal_rows),
            "formal_weight_stage_gate_pass": bool(formal_rows and formal_rows[-1].get("homotopy_stage_gate_pass")),
            "stopped_early": stopped,
            "stage_rows": model_rows,
            "failures": model_failures,
        }

    rows_path = out_dir / f"{slug}__joint_radar_weight_homotopy_rows.csv"
    pd.DataFrame(all_rows).to_csv(rows_path, index=False)
    combined = {
        "target_id": args.target,
        "protocol_version": cfg["protocol"]["frozen_protocol_version"],
        "frozen_multipliers": multipliers,
        "models_requested": args.models,
        "model_results": model_results,
        "all_models_completed_schedule": bool(model_results and all(v["all_requested_stages_completed"] for v in model_results.values())),
        "all_models_stage_gates_pass": bool(model_results and all(v["all_completed_stage_gates_pass"] for v in model_results.values())),
        "all_models_reached_formal_weight": bool(model_results and all(v["formal_weight_stage_reached"] for v in model_results.values())),
        "formal_weight_numerical_gate_pass": bool(model_results and all(v["formal_weight_stage_gate_pass"] for v in model_results.values())),
        "failures": failures,
        "rows_csv": str(rows_path.relative_to(root)).replace("\\", "/"),
        "physical_claim_ready": False,
        "claim_boundary": (
            "The homotopy validates numerical continuation from softened to formal radar weights. It does not replace "
            "radar-specific media, Earth-orientation, editing, bias, and independent-software validation."
        ),
    }
    summary_path = out_dir / f"{slug}__joint_radar_weight_homotopy_summary.json"
    dump_json(summary_path, combined)
    print(json.dumps(combined, indent=2))
    if failures:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
