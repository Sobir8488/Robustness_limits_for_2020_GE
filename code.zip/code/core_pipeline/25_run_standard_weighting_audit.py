from __future__ import annotations

import argparse
import csv
import math
import shutil
from pathlib import Path

from _robustness_common import (
    TARGET, a2_from_summary, copy_if_exists, dump_json, dump_yaml, find_column,
    load_json, load_yaml, project_root, require_project_files,
    run_python, write_csv,
)

# Conservative station-class floors for a reproducible sensitivity audit.
# This is explicitly NOT an exact reproduction of the proprietary/current JPL weighting implementation.
STATION_FLOORS_ARCSEC = {
    "F51": 0.30,
    "G96": 0.50, "I52": 0.50, "L01": 0.50, "T12": 0.50,
    "J95": 0.70, "H21": 0.70, "G37": 0.70,
    "033": 1.00, "309": 1.00, "695": 1.00,
}


def parse_float(value: str | None) -> float | None:
    try:
        x = float(value) if value not in (None, "") else None
        return x if x is not None and math.isfinite(x) else None
    except ValueError:
        return None


def write_variant(source: Path, destination: Path, variant: str) -> dict:
    with source.open("r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        rows = list(reader)
        fields = list(reader.fieldnames or [])
    if not rows:
        raise ValueError(f"No rows in {source}")
    stn_col = find_column(fields, ["stn", "observatory", "observatory_code"])
    ra_col = find_column(fields, ["rmsRA", "rms_ra", "sigRA", "ra_sigma", "sigma_ra"])
    dec_col = find_column(fields, ["rmsDec", "rms_dec", "sigDec", "dec_sigma", "sigma_dec"])
    if stn_col is None:
        raise ValueError("Could not identify station-code column")
    if ra_col is None:
        ra_col = "rmsRA"
        fields.append(ra_col)
    if dec_col is None:
        dec_col = "rmsDec"
        fields.append(dec_col)

    station_counts = {}
    for row in rows:
        stn = str(row.get(stn_col, "")).strip()
        station_counts[stn] = station_counts.get(stn, 0) + 1
        if variant == "uniform_1arcsec":
            sigma_ra = sigma_dec = 1.0
        elif variant == "station_floor_gaia_era_informed":
            floor = STATION_FLOORS_ARCSEC.get(stn, 1.0)
            old_ra = parse_float(row.get(ra_col))
            old_dec = parse_float(row.get(dec_col))
            sigma_ra = max(floor, old_ra or floor)
            sigma_dec = max(floor, old_dec or floor)
        else:
            raise ValueError(variant)
        row[ra_col] = f"{sigma_ra:.6f}"
        row[dec_col] = f"{sigma_dec:.6f}"
    destination.parent.mkdir(parents=True, exist_ok=True)
    with destination.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
    return {"rows": len(rows), "station_counts": station_counts, "ra_uncertainty_column": ra_col, "dec_uncertainty_column": dec_col}



def prepare_inputs(root: Path, target: str) -> None:
    proc = run_python(root, "scripts/01_prepare_tudat_inputs.py", [
        "--target", target, "--fallback-sigma", "1.0"
    ], check=False)
    if proc.returncode != 0:
        run_python(root, "scripts/01_prepare_tudat_inputs.py", [])


def remove_canonical_fit_products(root: Path, model: str) -> None:
    """Remove only full-sample canonical products, never LOO/exclusion outputs."""
    candidates = [
        root / "results/models" / f"2020_GE__{model}__fallback_1__summary.json",
        root / "results/models" / f"2020_GE__{model}__fallback_1__parameters.csv",
        root / "results/models" / f"2020_GE__{model}__fallback_1__failure.json",
        root / "results/residuals" / f"2020_GE__{model}__fallback_1__residuals.csv",
    ]
    for path in candidates:
        if path.exists():
            path.unlink()

def main() -> int:
    parser = argparse.ArgumentParser(description="Run baseline, uniform, and Gaia-era-informed station-floor optical weighting audits.")
    parser.add_argument("--target", default=TARGET)
    args = parser.parse_args()
    root = project_root()
    require_project_files(root, [
        "scripts/01_prepare_tudat_inputs.py", "scripts/03_run_model_family.py",
        "config/stage2b.yaml", "data/input/2020_GE_ades.csv",
        "results/models/2020_GE__M_Y__fallback_1__summary.json",
    ])
    config_path = root / "config/stage2b.yaml"
    original_config = config_path.read_bytes()
    source = root / "data/input/2020_GE_ades.csv"
    variants = ["uniform_1arcsec", "station_floor_gaia_era_informed"]
    rows = []

    baseline_my = load_json(root / "results/models/2020_GE__M_Y__fallback_1__summary.json")
    baseline_msy = load_json(root / "results/models/2020_GE__M_SY__fallback_1__summary.json")
    baseline_a2 = a2_from_summary(baseline_my)
    rows.append({
        "variant": "baseline_ADES_RMS_else_fallback_same_night_deweighted",
        "model": "M_Y", "fit_valid": baseline_my.get("fit_valid"),
        "A2_estimated_au_d2": baseline_a2, "A2_z": baseline_my.get("A2_z"),
        "rms_residual_arcsec": baseline_my.get("rms_residual_arcsec"),
        "reduced_chi2": baseline_my.get("reduced_chi2"), "bic": baseline_my.get("bic"),
        "profile_scale_bic": baseline_my.get("profile_scale_bic"),
    })
    rows.append({
        "variant": "baseline_ADES_RMS_else_fallback_same_night_deweighted",
        "model": "M_SY", "fit_valid": baseline_msy.get("fit_valid"),
        "A2_estimated_au_d2": a2_from_summary(baseline_msy), "A2_z": baseline_msy.get("A2_z"),
        "rms_residual_arcsec": baseline_msy.get("rms_residual_arcsec"),
        "reduced_chi2": baseline_msy.get("reduced_chi2"), "bic": baseline_msy.get("bic"),
        "profile_scale_bic": baseline_msy.get("profile_scale_bic"),
    })

    metadata = {}
    try:
        for variant in variants:
            temp_rel = f"weight_audit/2020_GE_ades__{variant}.csv"
            temp_input = root / "data/input" / temp_rel
            metadata[variant] = write_variant(source, temp_input, variant)
            cfg = load_yaml(config_path)
            cfg["protocol"]["frozen_protocol_version"] = "0.6.0-weight-audit"
            cfg["targets"][args.target]["input_file"] = temp_rel.replace("/", "\\")
            cfg["weighting"]["fallback_sigma_arcsec"] = 1.0
            dump_yaml(config_path, cfg)

            prepare_inputs(root, args.target)
            for model in ("M_Y", "M_SY"):
                remove_canonical_fit_products(root, model)
                proc = run_python(root, "scripts/03_run_model_family.py", [
                    "--target", args.target, "--model", model, "--fallback-sigma", "1.0",
                ], check=False)
                summary_path = root / "results/models" / f"2020_GE__{model}__fallback_1__summary.json"
                outdir = root / "results/weighting_standard" / variant
                outdir.mkdir(parents=True, exist_ok=True)
                if summary_path.exists():
                    shutil.copy2(summary_path, outdir / summary_path.name)
                    data = load_json(summary_path)
                else:
                    data = {}
                for folder, suffix in (("models", "parameters.csv"), ("residuals", "residuals.csv")):
                    path = root / "results" / folder / f"2020_GE__{model}__fallback_1__{suffix}"
                    copy_if_exists(path, outdir / path.name)
                rows.append({
                    "variant": variant, "model": model, "process_returncode": proc.returncode,
                    "fit_valid": data.get("fit_valid"), "A2_estimated_au_d2": data.get("A2_estimated_au_d2"),
                    "A2_z": data.get("A2_z"), "rms_residual_arcsec": data.get("rms_residual_arcsec"),
                    "reduced_chi2": data.get("reduced_chi2"), "bic": data.get("bic"),
                    "profile_scale_bic": data.get("profile_scale_bic"),
                })
    finally:
        config_path.write_bytes(original_config)
        # Recreate baseline processed inputs and canonical M_Y/M_SY products after temporary branches.
        prepare_inputs(root, args.target)
        for model in ("M_Y", "M_SY"):
            run_python(root, "scripts/03_run_model_family.py", ["--target", args.target, "--model", model, "--fallback-sigma", "1.0"], check=False)

    my_rows = [r for r in rows if r["model"] == "M_Y"]
    gate_rows = [r for r in my_rows if r["variant"] != "baseline_ADES_RMS_else_fallback_same_night_deweighted"]
    gate = len(gate_rows) == 2 and all(
        bool(r.get("fit_valid"))
        and float(r.get("A2_estimated_au_d2")) < 0
        and abs(float(r.get("A2_z"))) >= 3.5
        and 0.5 <= abs(float(r.get("A2_estimated_au_d2")) / baseline_a2) <= 2.0
        for r in gate_rows
    )
    result = {
        "protocol_version": "0.6.1",
        "target_id": args.target,
        "audit_name": "Vereš/Gaia-era-informed weighting sensitivity audit",
        "exact_JPL_weighting_reproduction": False,
        "methodological_boundary": "The station-floor branch is a transparent sensitivity test. It does not claim to reproduce every survey/time/magnitude/rate and catalogue-debiasing rule used by current operational orbit systems.",
        "variant_metadata": metadata,
        "rows": rows,
        "standard_weighting_transport_gate_pass": gate,
    }
    outdir = root / "results/weighting_standard"
    dump_json(outdir / "2020_GE__standard_weighting_audit.json", result)
    write_csv(outdir / "2020_GE__standard_weighting_audit.csv", rows)
    report = "# Standard optical weighting audit\n\n" + result["methodological_boundary"] + f"\n\nTransport gate: **{'PASS' if gate else 'FAIL'}**\n"
    (outdir / "2020_GE__standard_weighting_audit.md").write_text(report, encoding="utf-8")
    if not gate:
        raise RuntimeError("Standard-weighting A2 transport gate failed")
    print("Standard-weighting A2 transport gate: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
