from __future__ import annotations

import argparse
from pathlib import Path

from _robustness_common import TARGET, dump_json, load_json, project_root, read_table, require_project_files


def boolish(value) -> bool:
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in {"1", "true", "yes", "pass", "passed"}


def main() -> int:
    parser = argparse.ArgumentParser(description="Apply a formal radar-closure gate and generate Appendix-only manuscript text when closure fails.")
    parser.add_argument("--target", default=TARGET)
    args = parser.parse_args()
    root = project_root()
    require_project_files(root, [
        "results/joint/2020_GE__joint_radar_weight_homotopy_rows.csv",
        "results/joint/2020_GE__joint_radar_weight_homotopy_summary.json",
        "results/tables/2020_GE__M_Y__radar_prediction_summary.json",
    ])
    rows = read_table(root / "results/joint/2020_GE__joint_radar_weight_homotopy_rows.csv")
    summary = load_json(root / "results/joint/2020_GE__joint_radar_weight_homotopy_summary.json")
    pred = load_json(root / "results/tables/2020_GE__M_Y__radar_prediction_summary.json")

    x1 = [r for r in rows if r.get("model") == "M_Y" and abs(float(r.get("radar_sigma_multiplier", "nan")) - 1.0) < 1e-12]
    x1_pass = bool(x1) and any(
        boolish(r.get("homotopy_stage_gate_pass")) or boolish(r.get("stage_gate_pass")) or boolish(r.get("accepted"))
        for r in x1
    )
    x1_nrms = None
    if x1:
        for key in ("radar_postfit_nrms", "postfit_radar_nrms", "radar_nrms"):
            try:
                x1_nrms = float(x1[0][key])
                break
            except (KeyError, TypeError, ValueError):
                pass
    formal_nrms_limit = 5.0
    formal_closure = x1_pass and x1_nrms is not None and x1_nrms <= formal_nrms_limit
    disposition = "main_text_joint_solution" if formal_closure else "appendix_only_diagnostic"

    result = {
        "protocol_version": "0.6.0",
        "target_id": args.target,
        "formal_M_Y_multiplier_1_row_present": bool(x1),
        "formal_M_Y_multiplier_1_gate_pass": x1_pass,
        "formal_M_Y_multiplier_1_radar_nrms": x1_nrms,
        "formal_radar_nrms_limit": formal_nrms_limit,
        "formal_radar_closure_pass": formal_closure,
        "publication_disposition": disposition,
        "existing_homotopy_summary": summary,
        "prediction_only_M_Y_radar_nrms": pred.get("radar_normalized_rms") or pred.get("normalized_rms") or pred.get("radar_nrms"),
        "claim": (
            "A formal-weight optical-radar solution passes the frozen closure gate."
            if formal_closure else
            "Radar remains a diagnostic consistency and failure-analysis layer. It does not independently confirm A2 and is moved to the Appendix."
        ),
    }
    outdir = root / "results/publication"
    dump_json(outdir / "2020_GE__radar_publication_disposition.json", result)
    (outdir / "2020_GE__radar_publication_disposition.md").write_text(
        "# Radar publication disposition\n\n"
        f"Formal closure: **{'PASS' if formal_closure else 'FAIL'}**\n\n"
        f"Disposition: **{disposition}**\n\n{result['claim']}\n",
        encoding="utf-8",
    )

    patchdir = root / "manuscript_patch"
    patchdir.mkdir(parents=True, exist_ok=True)
    if formal_closure:
        abstract = "The formal-weight optical--radar solution passes the frozen closure gate and independently constrains the transverse term."
        appendix = "% Formal radar closure passed; retain the calibrated joint solution in the main Results section.\n"
    else:
        abstract = "Radar diagnostics do not reach formal-weight closure and are therefore used only to bound, rather than confirm, the optical inference."
        appendix = r"""\section{Radar diagnostics and failed formal closure}
\label{app:radar_diagnostics}
The seven radar measurements were subjected to acquisition, unit, station-pair, sign, prediction, nuisance-bias, and staged weight-continuation audits. These checks preserve the optical transverse solution at softened radar weights, but the continuation does not reach the formal multiplier of unity. The radar residual scale remains sensitive to nuisance treatment, and the radial increment does not improve the independent Canberra--ATCA holdout. We therefore report no joint optical--radar covariance and do not treat radar as an independent detection of $A_2$. The radar products are retained as a transparent failure-analysis and compatibility layer only.
"""
    (patchdir / "ABSTRACT_RADAR_SENTENCE.tex").write_text(abstract + "\n", encoding="utf-8")
    (patchdir / "RADAR_APPENDIX_REPLACEMENT.tex").write_text(appendix + "\n", encoding="utf-8")
    (patchdir / "CONCLUSION_RADAR_SENTENCE.tex").write_text(
        ("A formal-weight joint optical--radar solution passes the closure gate.\n" if formal_closure else
         "Radar does not reach formal-weight closure; no joint covariance or independent radar confirmation is claimed.\n"),
        encoding="utf-8",
    )
    print(f"Radar disposition: {disposition}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
