from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

import json
import pandas as pd
from darkcomet_stage2b.common import load_config, ensure_directories, project_root, sha256_file, dump_json


def main():
    cfg = load_config()
    ensure_directories(cfg)
    root = project_root()
    rows = []
    for target_id, target_cfg in cfg["targets"].items():
        path = root / cfg["paths"]["input_directory"] / target_cfg["input_file"]
        if not path.exists():
            raise FileNotFoundError(path)
        frame = pd.read_csv(path)
        required = {"obstime", "ra", "dec", "stn", "provid", "Obstype"}
        missing = sorted(required - set(frame.columns))
        if missing:
            raise ValueError(f"{target_id}: missing columns {missing}")
        rows.append({
            "target_id": target_id,
            "input_file": str(path.relative_to(root)),
            "rows": int(len(frame)),
            "sha256": sha256_file(path),
            "first_obstime": str(frame["obstime"].min()),
            "last_obstime": str(frame["obstime"].max()),
        })
    payload = {
        "protocol_version": cfg["protocol"]["frozen_protocol_version"],
        "targets": rows,
        "model_families": list(cfg["models"]),
    }
    dump_json(root / cfg["paths"]["tables_directory"] / "stage2b_input_validation.json", payload)
    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()
