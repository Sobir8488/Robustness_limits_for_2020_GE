from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

import argparse
import json
import math
import traceback

import numpy as np
import pandas as pd

from darkcomet_stage2b.common import (
    ARCSEC_TO_RAD,
    dump_json,
    ensure_directories,
    load_config,
    project_root,
    safe_slug,
)
from darkcomet_stage2b.joint_preflight import (
    normalized_rms,
    parameter_update_diagnostics,
    preflight_gate,
)
from darkcomet_stage2b.ra_branch import normalize_ra_observation_branches, wrap_to_pi
from darkcomet_stage2b.radar_observables import normalize_longitude_deg
from darkcomet_stage2b.tudat_compat import create_offline_batch_mpc, make_rkf78_integrator


def _load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def _station_name(code: str) -> str:
    return "RADAR_" + str(code).replace("-", "M").replace("+", "P")


def _resolve_observable_type(model_settings, candidates):
    for name in candidates:
        if hasattr(model_settings, name):
            return getattr(model_settings, name), name
    raise AttributeError(f"None of the observable type names exist: {candidates}")


def _type_slice(collection, observable_type):
    mapping = collection.observable_type_start_index_and_size
    entry = mapping.get(observable_type) if hasattr(mapping, "get") else mapping[observable_type]
    if isinstance(entry, (tuple, list, np.ndarray)) and len(entry) == 2:
        return slice(int(entry[0]), int(entry[0]) + int(entry[1]))
    raise RuntimeError(f"Unsupported observable_type_start_index_and_size entry: {entry!r}")


def _build_and_run(
    target_id: str,
    model_name: str,
    radar_sigma_multiplier: float,
    cfg: dict,
    *,
    initial_parameter_vector_override=None,
    warm_start_source: str = "optical_only_best_fit",
    maximum_iterations_override: int | None = None,
    scope_override: str | None = None,
) -> dict:
    from tudatpy.interface import spice
    from tudatpy.astro import element_conversion
    from tudatpy.dynamics import environment_setup, propagation_setup, parameters_setup
    from tudatpy.estimation import (
        observable_models_setup,
        estimation_analysis,
        observations as tudat_observations,
        observations_setup,
    )

    root = project_root()
    slug = safe_slug(target_id)
    suffix = "fallback_1"
    model_path = root / cfg["paths"]["models_directory"] / f"{slug}__{model_name}__{suffix}__summary.json"
    model_summary = _load_json(model_path)
    if not bool(model_summary.get("fit_valid", False)):
        raise RuntimeError(f"Optical {model_name} fit is not valid")

    prepared_path = root / cfg["paths"]["processed_directory"] / f"{slug}_prepared_{suffix}.csv"
    batch_path = root / cfg["paths"]["processed_directory"] / f"{slug}_batchmpc_{suffix}.csv"
    radar_path = root / cfg["paths"]["radar_directory"] / f"{slug}__radar_observables_tudat.csv"
    prepared = pd.read_csv(prepared_path)
    batch_table = pd.read_csv(batch_path)
    radar = pd.read_csv(radar_path)
    if len(radar) != 7 or not bool(radar["direct_fit_eligible"].astype(bool).all()):
        raise RuntimeError("Expected seven direct-fit-eligible center-of-mass radar records")

    spice.load_standard_kernels()
    batch, _ = create_offline_batch_mpc(
        batch_table,
        target_id=target_id,
        observatory_cache_path=root / cfg["paths"]["observatory_cache"],
    )
    batch.set_weights(prepared["weight_per_coordinate_rad_inverse2"].to_numpy(float))

    dcfg = cfg["dynamics"]
    origin = dcfg["global_frame_origin"]
    orientation = dcfg["global_frame_orientation"]
    body_settings = environment_setup.get_default_body_settings(dcfg["bodies"], origin, orientation)
    bodies = environment_setup.create_system_of_bodies(body_settings)
    optical_collection = batch.to_tudat(
        bodies=bodies,
        included_satellites=None,
        apply_weights_VFCC17=False,
        apply_star_catalog_debias=False,
    )
    target_name = str(batch.MPC_objects[0])
    bodies.get(target_name).mass = 1.0

    coords_path = root / cfg["paths"]["radar_directory"] / f"{slug}__jpl_sb_radar_station_coordinates.json"
    coords = _load_json(coords_path)
    radar_station_map = {}
    for code in sorted(set(radar["xmit"].astype(str)) | set(radar["rcvr"].astype(str))):
        c = coords[code]
        station_name = _station_name(code)
        position = [
            float(c["altitude"]) * 1000.0,
            math.radians(float(c["latitude"])),
            math.radians(normalize_longitude_deg(float(c["longitude"]))),
        ]
        environment_setup.add_ground_station(
            bodies.get_body("Earth"), station_name, position, element_conversion.geodetic_position_type
        )
        radar_station_map[code] = station_name

    mcfg = cfg["models"][model_name]
    if mcfg["srp"]:
        rp_settings = environment_setup.radiation_pressure.cannonball_radiation_target(
            float(model_summary["reference_area_m2_per_1kg"]), 1.0, {"Sun": ["Earth"]}
        )
        environment_setup.add_radiation_pressure_target_model(bodies, target_name, rp_settings)

    accelerations = {
        "Sun": [
            propagation_setup.acceleration.point_mass_gravity(),
            propagation_setup.acceleration.relativistic_correction(use_schwarzschild=True),
        ],
        "Mercury": [propagation_setup.acceleration.point_mass_gravity()],
        "Venus": [propagation_setup.acceleration.point_mass_gravity()],
        "Earth": [propagation_setup.acceleration.point_mass_gravity()],
        "Moon": [propagation_setup.acceleration.point_mass_gravity()],
        "Mars": [propagation_setup.acceleration.point_mass_gravity()],
        "Jupiter": [propagation_setup.acceleration.point_mass_gravity()],
        "Saturn": [propagation_setup.acceleration.point_mass_gravity()],
        "Uranus": [propagation_setup.acceleration.point_mass_gravity()],
        "Neptune": [propagation_setup.acceleration.point_mass_gravity()],
    }
    if mcfg["srp"]:
        accelerations["Sun"].append(propagation_setup.acceleration.radiation_pressure())
    if mcfg["yarkovsky"]:
        accelerations["Sun"].append(
            propagation_setup.acceleration.yarkovsky(float(model_summary["A2_estimated_m_s2"]))
        )
    acceleration_models = propagation_setup.create_acceleration_models(
        bodies, {target_name: accelerations}, [target_name], [origin]
    )
    initial_time = float(model_summary["propagation_epoch_start_tdb_s_j2000"])
    end_time = max(
        float(model_summary["propagation_epoch_end_tdb_s_j2000"]),
        float(radar["epoch_tdb_s_j2000"].max()) + 2.0 * 86400.0,
    )
    propagator_settings = propagation_setup.propagator.translational(
        central_bodies=[origin],
        acceleration_models=acceleration_models,
        bodies_to_integrate=[target_name],
        initial_states=np.asarray(model_summary["final_parameter_vector"][:6], dtype=float),
        initial_time=initial_time,
        integrator_settings=make_rkf78_integrator(propagation_setup.integrator, dcfg),
        termination_settings=propagation_setup.propagator.time_termination(end_time),
    )

    parameter_settings = parameters_setup.initial_states(propagator_settings, bodies)
    if mcfg["srp"]:
        parameter_settings.append(parameters_setup.radiation_pressure_target_direction_scaling(target_name, "Sun"))
    if mcfg["yarkovsky"]:
        parameter_settings.append(parameters_setup.yarkovsky_parameter(target_name, "Sun"))
    parameters = parameters_setup.create_parameter_set(parameter_settings, bodies, propagator_settings)
    optical_baseline_vector = np.asarray(model_summary["final_parameter_vector"], dtype=float)
    if initial_parameter_vector_override is None:
        initial_vector = optical_baseline_vector.copy()
    else:
        initial_vector = np.asarray(initial_parameter_vector_override, dtype=float).reshape(-1)
    if initial_vector.size != np.asarray(parameters.parameter_vector).size:
        raise RuntimeError("Joint-preflight parameter ordering mismatch")
    if not np.isfinite(initial_vector).all():
        raise RuntimeError("Joint-preflight initial parameter vector contains non-finite values")
    parameters.parameter_vector = initial_vector.copy()

    observation_settings = []
    angular_type = observable_models_setup.model_settings.angular_position_type
    for link in list(optical_collection.get_link_definitions_for_observables(angular_type)):
        observation_settings.append(observable_models_setup.model_settings.angular_position(link, bias_settings=None))

    light_time_correction = observable_models_setup.light_time_corrections.first_order_relativistic_light_time_correction(["Sun"])
    links_by_pair = {}
    for pair in sorted(radar["station_pair"].astype(str).unique()):
        xmit, rcvr = pair.split("->", 1)
        link_ends = {
            observable_models_setup.links.transmitter: observable_models_setup.links.body_reference_point_link_end_id("Earth", radar_station_map[xmit]),
            observable_models_setup.links.retransmitter: observable_models_setup.links.body_origin_link_end_id(target_name),
            observable_models_setup.links.receiver: observable_models_setup.links.body_reference_point_link_end_id("Earth", radar_station_map[rcvr]),
        }
        link = observable_models_setup.links.LinkDefinition(link_ends)
        links_by_pair[pair] = link
        observation_settings.append(observable_models_setup.model_settings.two_way_range(link, light_time_correction_settings=[light_time_correction]))
        observation_settings.append(observable_models_setup.model_settings.two_way_doppler_instantaneous(link, light_time_correction_settings=[light_time_correction], normalized_with_speed_of_light=False))

    estimator = estimation_analysis.Estimator(
        bodies=bodies,
        estimated_parameters=parameters,
        observation_settings=observation_settings,
        propagator_settings=propagator_settings,
        integrate_on_creation=True,
    )
    range_type, range_type_name = _resolve_observable_type(observable_models_setup.model_settings, ["n_way_range_type", "two_way_range_type"])
    doppler_type, doppler_type_name = _resolve_observable_type(observable_models_setup.model_settings, ["two_way_instantaneous_doppler_type", "two_way_doppler_instantaneous_type"])

    # Normalize only the optical RA representation before radar collections are appended.
    tudat_observations.compute_residuals_and_dependent_variables(optical_collection, estimator.observation_simulators, bodies)
    raw_prefit = np.asarray(optical_collection.get_concatenated_residuals(), dtype=float).reshape(-1)
    original_values = np.asarray(optical_collection.concatenated_observations, dtype=float).reshape(-1)
    adjusted, branch = normalize_ra_observation_branches(original_values, raw_prefit)
    if branch["n_ra_branch_shifts"] > 0:
        optical_collection.set_observations(adjusted)
        tudat_observations.compute_residuals_and_dependent_variables(optical_collection, estimator.observation_simulators, bodies)
    verified = np.asarray(optical_collection.get_concatenated_residuals(), dtype=float).reshape(-1)
    expected = raw_prefit.copy()
    expected[0::2] = wrap_to_pi(expected[0::2])
    branch_error = float(np.max(np.abs(verified - expected)))
    if branch_error > 1.0e-9:
        raise RuntimeError(f"Optical RA branch verification failed: {branch_error}")

    # Build one radar collection per scalar, then make a fresh joint collection.  In
    # TudatPy 1.0, mutating an optical collection after computed residual buffers
    # have been populated can leave those internal buffers at the old optical-only
    # size.  A subsequent compute_residuals_and_dependent_variables call then tries
    # to reset a 109-scalar vector into a 102-scalar buffer and fails.  The official
    # merge helper creates a clean collection index; append is retained only as an
    # API-compatibility fallback.  Joint prefit residuals are taken from column zero
    # of EstimationOutput.residual_history, not by pre-resetting the collection.
    radar_collections = []
    for _, row in radar.iterrows():
        obs_type = range_type if str(row["measurement_type"]).lower() == "delay" else doppler_type
        settings = [observations_setup.observations_simulation_settings.tabulated_simulation_settings(
            obs_type,
            links_by_pair[str(row["station_pair"])],
            np.asarray([float(row["epoch_tdb_s_j2000"])], dtype=float),
            reference_link_end_type=observable_models_setup.links.receiver,
        )]
        one = observations_setup.observations_wrapper.simulate_observations(
            settings, estimator.observation_simulators, bodies
        )
        one.set_observations(np.asarray([float(row["observed_tudat_value"])], dtype=float))
        sigma = float(row["observed_tudat_sigma"]) * float(radar_sigma_multiplier)
        one.set_tabulated_weights(np.asarray([1.0 / (sigma * sigma)], dtype=float))
        radar_collections.append(one)

    merge_function = getattr(tudat_observations, "merge_observation_collections", None)
    if callable(merge_function):
        joint_collection = merge_function([optical_collection, *radar_collections])
        collection_merge_method = "merge_observation_collections"
    else:
        joint_collection = optical_collection
        for one in radar_collections:
            joint_collection.append(one)
        collection_merge_method = "append_compatibility_fallback"

    all_obs = np.asarray(joint_collection.concatenated_observations, dtype=float).reshape(-1)
    all_weights = np.asarray(joint_collection.concatenated_weights, dtype=float).reshape(-1)
    expected_size = 2 * len(prepared) + len(radar)
    reported_vector_size = int(getattr(joint_collection, "observation_vector_size", all_obs.size))
    partition_gate = bool(
        all_obs.size == expected_size
        and all_weights.size == expected_size
        and reported_vector_size == expected_size
    )
    if not partition_gate:
        raise RuntimeError(
            "Joint observation partition mismatch before estimation: "
            f"observations={all_obs.size}, weights={all_weights.size}, "
            f"reported={reported_vector_size}, expected={expected_size}"
        )

    max_iterations = int(
        maximum_iterations_override
        if maximum_iterations_override is not None
        else cfg["radar_joint_preflight"]["maximum_iterations"]
    )
    if max_iterations < 1:
        raise ValueError("maximum_iterations must be at least 1")
    pod_input = estimation_analysis.EstimationInput(
        observations_and_times=joint_collection,
        convergence_checker=estimation_analysis.estimation_convergence_checker(maximum_iterations=max_iterations),
    )
    pod_input.set_weights_from_observation_collection()
    pod_input.define_estimation_settings(reintegrate_variational_equations=True)
    pod_output = estimator.perform_estimation(pod_input)

    final_vector = np.asarray(pod_output.final_parameters, dtype=float).reshape(-1)
    final_residuals = np.asarray(pod_output.final_residuals, dtype=float).reshape(-1)
    final_weights = np.asarray(joint_collection.concatenated_weights, dtype=float).reshape(-1)
    residual_history = np.asarray(pod_output.residual_history, dtype=float)
    if residual_history.ndim != 2 or residual_history.shape[0] != expected_size or residual_history.shape[1] < 1:
        raise RuntimeError(
            "Unexpected joint residual-history shape: "
            f"{residual_history.shape}; expected ({expected_size}, >=1)"
        )
    joint_prefit = residual_history[:, 0].copy()
    best_iteration = int(np.argmin(np.sqrt(np.mean(np.square(residual_history), axis=0))))

    angular_slice = _type_slice(joint_collection, angular_type)
    range_slice = _type_slice(joint_collection, range_type)
    doppler_slice = _type_slice(joint_collection, doppler_type)
    radar_indices = np.r_[np.arange(range_slice.start, range_slice.stop), np.arange(doppler_slice.start, doppler_slice.stop)]
    optical_indices = np.arange(angular_slice.start, angular_slice.stop)

    radar_prefit_nrms = normalized_rms(joint_prefit[radar_indices], all_weights[radar_indices])
    radar_postfit_nrms = normalized_rms(final_residuals[radar_indices], final_weights[radar_indices])
    optical_postfit_rms_arcsec = float(np.sqrt(np.mean(np.square(final_residuals[optical_indices]))) / ARCSEC_TO_RAD)

    summary = {
        "target_id": target_id,
        "model": model_name,
        "protocol_version": cfg["protocol"]["frozen_protocol_version"],
        "scope": scope_override or "joint optical-radar estimator preflight with deliberately softened radar weights",
        "runtime_success": True,
        "radar_sigma_multiplier": float(radar_sigma_multiplier),
        "maximum_iterations": max_iterations,
        "n_optical_vector_observations": int(len(prepared)),
        "n_optical_scalars": int(2 * len(prepared)),
        "n_radar_scalars": int(len(radar)),
        "n_total_scalars": int(all_obs.size),
        "observation_partition_gate_pass": partition_gate,
        "collection_merge_method": collection_merge_method,
        "reported_observation_vector_size": reported_vector_size,
        "prefit_residual_source": "estimation_output_residual_history_column_0",
        "range_observable_type_name": range_type_name,
        "doppler_observable_type_name": doppler_type_name,
        "reference_link_end": "receiver",
        "ra_branch_normalization": {
            "n_ra_branch_shifts": int(branch["n_ra_branch_shifts"]),
            "verification_max_error_rad": branch_error,
            "verification_pass": bool(branch_error <= 1.0e-9),
        },
        "best_iteration": best_iteration,
        "n_estimation_iterations": int(residual_history.shape[1] - 1),
        "all_final_residuals_finite": bool(np.isfinite(final_residuals).all()),
        "total_prefit_nrms": normalized_rms(joint_prefit, all_weights),
        "total_postfit_nrms": normalized_rms(final_residuals, final_weights),
        "radar_prefit_nrms": radar_prefit_nrms,
        "radar_postfit_nrms": radar_postfit_nrms,
        "radar_postfit_nrms_improved": bool(np.isfinite(radar_prefit_nrms) and np.isfinite(radar_postfit_nrms) and radar_postfit_nrms < radar_prefit_nrms),
        "optical_postfit_rms_arcsec": optical_postfit_rms_arcsec,
        "warm_start_source": str(warm_start_source),
        "optical_baseline_parameter_vector": [float(x) for x in optical_baseline_vector],
        "initial_parameter_vector": [float(x) for x in initial_vector],
        "final_parameter_vector": [float(x) for x in final_vector],
        "parameter_update": parameter_update_diagnostics(initial_vector, final_vector),
        "total_postfit_nrms_improved": bool(
            np.isfinite(normalized_rms(joint_prefit, all_weights))
            and np.isfinite(normalized_rms(final_residuals, final_weights))
            and normalized_rms(final_residuals, final_weights) <= normalized_rms(joint_prefit, all_weights)
        ),
        "optical_baseline_rms_arcsec": float(model_summary["rms_residual_arcsec"]),
        "optical_postfit_rms_ratio_to_baseline": float(
            optical_postfit_rms_arcsec / float(model_summary["rms_residual_arcsec"])
        ),
        "force_parameter_diagnostics": {
            "A2_initial_m_s2": float(initial_vector[-1]) if mcfg["yarkovsky"] else None,
            "A2_final_m_s2": float(final_vector[-1]) if mcfg["yarkovsky"] else None,
            "A2_optical_baseline_m_s2": float(optical_baseline_vector[-1]) if mcfg["yarkovsky"] else None,
            "A2_sign_consistent_with_optical_baseline": bool(
                (not mcfg["yarkovsky"])
                or (np.sign(final_vector[-1]) == np.sign(optical_baseline_vector[-1]))
            ),
            "A2_abs_ratio_to_optical_baseline": float(
                abs(final_vector[-1] / optical_baseline_vector[-1])
            ) if mcfg["yarkovsky"] and optical_baseline_vector[-1] != 0.0 else None,
            "srp_scale_initial": float(initial_vector[-2]) if mcfg["srp"] and mcfg["yarkovsky"] else (float(initial_vector[-1]) if mcfg["srp"] else None),
            "srp_scale_final": float(final_vector[-2]) if mcfg["srp"] and mcfg["yarkovsky"] else (float(final_vector[-1]) if mcfg["srp"] else None),
        },
        "claim_boundary": "This is an API/conditioning preflight at inflated radar uncertainties. It is not a formal optical-radar solution and must not enter physical parameter claims or information-criterion ranking.",
    }
    summary["joint_preflight_gate_pass"] = preflight_gate(summary)
    return summary


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--target", default="2020 GE")
    parser.add_argument("--models", nargs="+", default=["M_SY", "M_Y"])
    parser.add_argument("--radar-sigma-multiplier", type=float, default=1000.0)
    parser.add_argument("--continue-on-error", action="store_true")
    args = parser.parse_args()

    cfg = load_config()
    ensure_directories(cfg)
    root = project_root()
    out_dir = root / cfg["paths"]["joint_directory"]
    out_dir.mkdir(parents=True, exist_ok=True)
    summaries = []
    failures = []
    for model in args.models:
        try:
            s = _build_and_run(args.target, model, args.radar_sigma_multiplier, cfg)
            summaries.append(s)
            dump_json(out_dir / f"{safe_slug(args.target)}__{model}__joint_preflight_radar_sigma_x{args.radar_sigma_multiplier:g}__summary.json", s)
            print(json.dumps(s, indent=2))
        except Exception as exc:
            f = {"target_id": args.target, "model": model, "error": str(exc), "traceback": traceback.format_exc()}
            failures.append(f)
            dump_json(out_dir / f"{safe_slug(args.target)}__{model}__joint_preflight_radar_sigma_x{args.radar_sigma_multiplier:g}__failure.json", f)
            print(json.dumps(f, indent=2))
            if not args.continue_on_error:
                raise

    combined = {
        "target_id": args.target,
        "protocol_version": cfg["protocol"]["frozen_protocol_version"],
        "radar_sigma_multiplier": float(args.radar_sigma_multiplier),
        "models_requested": args.models,
        "n_success": len(summaries),
        "n_failed": len(failures),
        "all_preflights_success": len(failures) == 0,
        "all_preflight_gates_pass": bool(summaries and len(failures) == 0 and all(s["joint_preflight_gate_pass"] for s in summaries)),
        "model_summaries": {s["model"]: s for s in summaries},
        "failures": failures,
        "claim_boundary": "Soft-weight joint-estimator preflight only; no physical model ranking.",
    }
    dump_json(out_dir / f"{safe_slug(args.target)}__joint_preflight_radar_sigma_x{args.radar_sigma_multiplier:g}__comparison.json", combined)
    print(json.dumps(combined, indent=2))
    if failures:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
