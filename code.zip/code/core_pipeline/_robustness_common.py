from __future__ import annotations

import csv
import hashlib
import json
import math
import os
import shutil
import subprocess
import sys
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterable

try:
    import yaml
except ImportError:  # pragma: no cover
    yaml = None

TARGET = "2020 GE"
PROTOCOL = "0.6.0"


def project_root() -> Path:
    return Path(__file__).resolve().parents[1]


def require_project_files(root: Path, paths: Iterable[str]) -> None:
    missing = [p for p in paths if not (root / p).exists()]
    if missing:
        joined = "\n  - ".join(missing)
        raise FileNotFoundError(
            "This hotfix must be extracted over the existing Stage-2B project. "
            f"Missing:\n  - {joined}"
        )


def load_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def dump_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="\n") as f:
        json.dump(data, f, indent=2, ensure_ascii=False, sort_keys=False)
        f.write("\n")


def write_csv(path: Path, rows: list[dict[str, Any]], fieldnames: list[str] | None = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if fieldnames is None:
        fieldnames = list(rows[0]) if rows else []
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def run_python(root: Path, relative_script: str, args: list[str], *, check: bool = True) -> subprocess.CompletedProcess[str]:
    cmd = [sys.executable, str(root / relative_script), *args]
    print("\n>", subprocess.list2cmdline(cmd), flush=True)
    return subprocess.run(cmd, cwd=root, check=check, text=True)


def copy_if_exists(src: Path, dst: Path) -> None:
    if src.exists():
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)


def remove_glob(directory: Path, pattern: str) -> None:
    if directory.exists():
        for path in directory.glob(pattern):
            if path.is_file():
                path.unlink()


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def finite(value: Any) -> bool:
    try:
        return math.isfinite(float(value))
    except (TypeError, ValueError):
        return False


def a2_from_summary(summary: dict[str, Any]) -> float:
    value = summary.get("A2_estimated_au_d2")
    if not finite(value):
        raise ValueError("A2_estimated_au_d2 is missing or non-finite")
    return float(value)


def a2_sigma_from_summary(summary: dict[str, Any]) -> float:
    for key in ("A2_sigma_overdispersion_scaled_au_d2", "A2_sigma_raw_au_d2"):
        value = summary.get(key)
        if finite(value) and float(value) > 0:
            return float(value)
    raise ValueError("No finite positive A2 uncertainty in summary")


def model_summary_path(root: Path, model: str, fallback: str = "1", suffix: str = "") -> Path:
    return root / "results" / "models" / f"2020_GE__{model}__fallback_{fallback}{suffix}__summary.json"


def model_parameters_path(root: Path, model: str, fallback: str = "1", suffix: str = "") -> Path:
    return root / "results" / "models" / f"2020_GE__{model}__fallback_{fallback}{suffix}__parameters.csv"


def residual_path(root: Path, model: str, fallback: str = "1", suffix: str = "") -> Path:
    return root / "results" / "residuals" / f"2020_GE__{model}__fallback_{fallback}{suffix}__residuals.csv"


def load_yaml(path: Path) -> dict[str, Any]:
    if yaml is None:
        raise RuntimeError("PyYAML is required. Install pyyaml in the active Conda environment.")
    with path.open("r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def dump_yaml(path: Path, data: dict[str, Any]) -> None:
    if yaml is None:
        raise RuntimeError("PyYAML is required. Install pyyaml in the active Conda environment.")
    with path.open("w", encoding="utf-8", newline="\n") as f:
        yaml.safe_dump(data, f, sort_keys=False, allow_unicode=True)


@contextmanager
def preserved_file(path: Path):
    existed = path.exists()
    content = path.read_bytes() if existed else None
    try:
        yield
    finally:
        if existed and content is not None:
            path.write_bytes(content)
        elif path.exists():
            path.unlink()


def read_table(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def find_column(columns: Iterable[str], candidates: Iterable[str]) -> str | None:
    lookup = {c.lower().replace("_", "").replace("-", ""): c for c in columns}
    for candidate in candidates:
        key = candidate.lower().replace("_", "").replace("-", "")
        if key in lookup:
            return lookup[key]
    return None


def delete_group_jackknife(values: list[float]) -> dict[str, float]:
    if len(values) < 2:
        raise ValueError("At least two delete-group estimates are required")
    mean = sum(values) / len(values)
    se = math.sqrt((len(values) - 1) / len(values) * sum((v - mean) ** 2 for v in values))
    sorted_values = sorted(values)
    median = sorted_values[len(values) // 2] if len(values) % 2 else 0.5 * (
        sorted_values[len(values) // 2 - 1] + sorted_values[len(values) // 2]
    )
    deviations = sorted(abs(v - median) for v in values)
    mad = deviations[len(deviations) // 2] if len(deviations) % 2 else 0.5 * (
        deviations[len(deviations) // 2 - 1] + deviations[len(deviations) // 2]
    )
    return {
        "n_groups": len(values),
        "mean": mean,
        "minimum": min(values),
        "maximum": max(values),
        "jackknife_se": se,
        "median": median,
        "mad_scaled_sigma": 1.4826 * mad,
    }


def sample_sd(values: list[float]) -> float:
    if len(values) < 2:
        return 0.0
    mean = sum(values) / len(values)
    return math.sqrt(sum((v - mean) ** 2 for v in values) / (len(values) - 1))
