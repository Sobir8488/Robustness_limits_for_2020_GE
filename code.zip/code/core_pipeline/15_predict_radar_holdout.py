from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path: sys.path.insert(0, str(SRC))

import argparse, json, math
import numpy as np
import pandas as pd
from astropy.time import Time
from darkcomet_stage2b.common import load_config, project_root, safe_slug, dump_json, SOLAR_PRESSURE_1AU_N_M2, au_d2_to_m_s2
from darkcomet_stage2b.radar_prediction import geodetic_to_ecef_m, HermiteStateInterpolator, predict_delay_seconds, predict_doppler_hz
from darkcomet_stage2b.tudat_compat import make_rkf78_integrator


def utc_to_tdb_seconds(text):
    return float((Time(str(text), format="iso", scale="utc").tdb.jd - 2451545.0) * 86400.0)


def build_trajectory(cfg, target_id, model_name, summary, epoch_end):
    from tudatpy.interface import spice
    from tudatpy.dynamics import environment_setup, propagation_setup, parameters_setup, simulator
    spice.load_standard_kernels()
    dcfg=cfg['dynamics']; tcfg=cfg['targets'][target_id]; mcfg=cfg['models'][model_name]
    body_settings=environment_setup.get_default_body_settings(dcfg['bodies'], dcfg['global_frame_origin'], dcfg['global_frame_orientation'])
    bodies=environment_setup.create_system_of_bodies(body_settings)
    target_name=f"({target_id})"
    try:
        bodies.get(target_name)
    except Exception:
        bodies.create_empty_body(target_name)
    bodies.get(target_name).mass=1.0
    a1_si=au_d2_to_m_s2(abs(float(tcfg['jpl_catalogue_A1_au_d2'])))
    area=max(a1_si/SOLAR_PRESSURE_1AU_N_M2,1e-8)
    if mcfg['srp']:
        rp=environment_setup.radiation_pressure.cannonball_radiation_target(area,1.0,{"Sun":["Earth"]})
        environment_setup.add_radiation_pressure_target_model(bodies,target_name,rp)
    acc={"Sun":[propagation_setup.acceleration.point_mass_gravity(),propagation_setup.acceleration.relativistic_correction(use_schwarzschild=True)],
         "Mercury":[propagation_setup.acceleration.point_mass_gravity()],"Venus":[propagation_setup.acceleration.point_mass_gravity()],"Earth":[propagation_setup.acceleration.point_mass_gravity()],"Moon":[propagation_setup.acceleration.point_mass_gravity()],"Mars":[propagation_setup.acceleration.point_mass_gravity()],"Jupiter":[propagation_setup.acceleration.point_mass_gravity()],"Saturn":[propagation_setup.acceleration.point_mass_gravity()],"Uranus":[propagation_setup.acceleration.point_mass_gravity()],"Neptune":[propagation_setup.acceleration.point_mass_gravity()]}
    if mcfg['srp']: acc['Sun'].append(propagation_setup.acceleration.radiation_pressure())
    if mcfg['yarkovsky']: acc['Sun'].append(propagation_setup.acceleration.yarkovsky(float(summary['A2_estimated_m_s2'])))
    models=propagation_setup.create_acceleration_models(bodies,{target_name:acc},[target_name],[dcfg['global_frame_origin']])
    start=float(summary['propagation_epoch_start_tdb_s_j2000'])
    vector=np.asarray(summary['final_parameter_vector'],float)
    prop=propagation_setup.propagator.translational([dcfg['global_frame_origin']],models,[target_name],vector[:6],start,make_rkf78_integrator(propagation_setup.integrator,dcfg),propagation_setup.propagator.time_termination(float(epoch_end)))
    pset=parameters_setup.initial_states(prop,bodies)
    if mcfg['srp']: pset.append(parameters_setup.radiation_pressure_target_direction_scaling(target_name,"Sun"))
    if mcfg['yarkovsky']: pset.append(parameters_setup.yarkovsky_parameter(target_name,"Sun"))
    params=parameters_setup.create_parameter_set(pset,bodies,prop); params.parameter_vector=vector
    sim=simulator.create_dynamics_simulator(bodies,prop)
    if not sim.integration_completed_successfully: raise RuntimeError("Dynamics propagation failed")
    return HermiteStateInterpolator(sim.state_history), spice


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--target',default='2020 GE'); ap.add_argument('--fallback-sigma',type=float,default=1.0); ap.add_argument('--models',nargs='+',default=['M_SY','M_Y']); args=ap.parse_args()
    cfg=load_config(); root=project_root(); slug=safe_slug(args.target); suffix=f"fallback_{args.fallback_sigma:g}"
    radar=pd.read_csv(root/cfg['paths']['radar_directory']/f"{slug}__jpl_sb_radar_astrometry.csv")
    coords=json.loads((root/cfg['paths']['radar_directory']/f"{slug}__jpl_sb_radar_station_coordinates.json").read_text())
    epochs=np.array([utc_to_tdb_seconds(x) for x in radar['epoch']],float); radar['epoch_tdb_s_j2000']=epochs
    derivative_step=float(cfg['radar_validation'].get('holdout_doppler_derivative_step_s',1.0))
    rows=[]; model_summaries={}
    for model in args.models:
        sp=root/cfg['paths']['models_directory']/f"{slug}__{model}__{suffix}__summary.json"
        summary=json.loads(sp.read_text());
        if not summary.get('fit_valid'): raise RuntimeError(f"{model} baseline fit is not valid")
        traj, spice=build_trajectory(cfg,args.target,model,summary,float(max(epochs)+86400.0))
        station_ecef={k:geodetic_to_ecef_m(v['longitude'],v['latitude'],v['altitude'],v['alt_units']) for k,v in coords.items()}
        def station_pos(code,t):
            earth=np.asarray(spice.get_body_cartesian_state_at_epoch('Earth','SSB','J2000','NONE',float(t)),float)[:3]
            rot=np.asarray(spice.compute_rotation_matrix_between_frames('ITRF93','J2000',float(t)),float)
            return earth + rot@station_ecef[str(code)]
        target_pos=lambda t: traj(float(t))[:3]
        for _,r in radar.iterrows():
            tr=float(r['epoch_tdb_s_j2000']); xmit=str(int(r['xmit'])); rcvr=str(int(r['rcvr']))
            tx=lambda t,c=xmit: station_pos(c,t); rx=lambda t,c=rcvr: station_pos(c,t)
            delay_fn=lambda t: predict_delay_seconds(float(t),rx,tx,target_pos)
            pred_delay_us=delay_fn(tr)*1e6
            if r['measurement_type']=='delay': pred=pred_delay_us
            else: pred=predict_doppler_hz(tr,float(r['freq'])*1e6,delay_fn,derivative_step)
            residual=float(r['value'])-pred; norm=residual/float(r['sigma'])
            rows.append({**r.to_dict(),'model':model,'predicted_value':pred,'residual_observed_minus_predicted':residual,'normalized_residual':norm,'predicted_two_way_delay_us':pred_delay_us})
        mdf=pd.DataFrame([x for x in rows if x['model']==model])
        model_summaries[model]={
            'n_records':int(len(mdf)),
            'delay_rms_us':float(np.sqrt(np.mean(mdf.loc[mdf.measurement_type=='delay','residual_observed_minus_predicted']**2))),
            'doppler_rms_hz':float(np.sqrt(np.mean(mdf.loc[mdf.measurement_type=='doppler','residual_observed_minus_predicted']**2))),
            'max_abs_normalized_residual':float(mdf.normalized_residual.abs().max()),
            'within_10sigma_all':bool((mdf.normalized_residual.abs()<=10).all()),
        }
    out=pd.DataFrame(rows)
    csv=root/cfg['paths']['tables_directory']/f"{slug}__radar_holdout_predictions.csv"; out.to_csv(csv,index=False)
    sy=model_summaries.get('M_SY',{}); my=model_summaries.get('M_Y',{})
    result={'target_id':args.target,'protocol_version':cfg['protocol']['frozen_protocol_version'],'fallback_sigma_arcsec':args.fallback_sigma,'epoch_semantics':'UTC epoch of echo reception','models':model_summaries,'M_SY_better_delay_rms_than_M_Y':bool(sy and my and sy['delay_rms_us']<my['delay_rms_us']),'M_SY_better_doppler_rms_than_M_Y':bool(sy and my and sy['doppler_rms_hz']<my['doppler_rms_hz']),'holdout_gate_pass':bool(sy and sy['within_10sigma_all']),'claim_boundary':'Prediction-only external hold-out audit; radar observations were not used to estimate the optical orbit parameters.'}
    js=root/cfg['paths']['tables_directory']/f"{slug}__radar_holdout_summary.json"; dump_json(js,result)
    report=root/cfg['paths']['reports_directory']/f"{slug}__radar_holdout_report.md"
    report.write_text(f"# {args.target} optical-only radar hold-out audit\n\n- Gate: {result['holdout_gate_pass']}\n- M_SY: {sy}\n- M_Y: {my}\n- Radar data were not used in parameter estimation.\n",encoding='utf-8')
    print(json.dumps(result,indent=2)); print(f"Saved: {csv}\nSaved: {js}\nSaved: {report}")
    if not result['holdout_gate_pass']: raise SystemExit(2)
if __name__=='__main__': main()
