from __future__ import annotations

import argparse
from pathlib import Path

from _robustness_common import TARGET, dump_json, load_json, project_root, require_project_files, run_python


def main() -> int:
    parser = argparse.ArgumentParser(description="Run and validate the five-cluster M_Y leave-one-cluster-out audit.")
    parser.add_argument("--target", default=TARGET)
    parser.add_argument("--fallback-sigma", type=float, default=1.0)
    args = parser.parse_args()

    root = project_root()
    require_project_files(root, [
        "scripts/03_run_model_family.py",
        "scripts/06_run_cluster_loo.py",
        "scripts/07_summarize_loo.py",
        "config/stage2b.yaml",
        "data/input/2020_GE_ades.csv",
    ])

    fallback = f"{args.fallback_sigma:g}"
    run_python(root, "scripts/06_run_cluster_loo.py", [
        "--target", args.target, "--model", "M_Y", "--fallback-sigma", fallback,
    ])

    summary_json = root / "results" / "loo" / f"2020_GE__M_Y__fallback_{fallback}__loo_summary.json"
    summary_csv = root / "results" / "loo" / f"2020_GE__M_Y__fallback_{fallback}__loo_summary.csv"
    if not summary_json.exists() or not summary_csv.exists():
        proc = run_python(root, "scripts/07_summarize_loo.py", [
            "--target", args.target, "--model", "M_Y", "--fallback-sigma", fallback,
        ], check=False)
        if proc.returncode != 0:
            run_python(root, "scripts/07_summarize_loo.py", [])

    missing = []
    rows = []
    for cluster in range(5):
        path = root / "results" / "models" / f"2020_GE__M_Y__fallback_{fallback}__exclude_cluster_{cluster}__summary.json"
        if not path.exists():
            missing.append(str(path.relative_to(root)))
            continue
        data = load_json(path)
        rows.append({
            "cluster": cluster,
            "n_observations": data.get("n_observations"),
            "fit_valid": bool(data.get("fit_valid")),
            "A2_estimated_au_d2": data.get("A2_estimated_au_d2"),
            "A2_sigma_overdispersion_scaled_au_d2": data.get("A2_sigma_overdispersion_scaled_au_d2"),
            "A2_z": data.get("A2_z"),
            "rms_residual_arcsec": data.get("rms_residual_arcsec"),
        })
    gate = (
        not missing
        and len(rows) == 5
        and all(r["fit_valid"] for r in rows)
        and all(float(r["A2_estimated_au_d2"]) < 0 for r in rows)
        and all(abs(float(r["A2_z"])) >= 3.5 for r in rows)
    )
    audit = {
        "protocol_version": "0.6.1",
        "target_id": args.target,
        "model": "M_Y",
        "fallback_sigma_arcsec": args.fallback_sigma,
        "n_expected_clusters": 5,
        "n_completed_clusters": len(rows),
        "missing_outputs": missing,
        "rows": rows,
        "MY_temporal_transport_gate_pass": gate,
    }
    dump_json(root / "results" / "publication" / "2020_GE__M_Y__loo_validation.json", audit)
    if not gate:
        raise RuntimeError("M_Y five-cluster LOO gate failed; see results/publication/2020_GE__M_Y__loo_validation.json")
    print("M_Y five-cluster LOO gate: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
