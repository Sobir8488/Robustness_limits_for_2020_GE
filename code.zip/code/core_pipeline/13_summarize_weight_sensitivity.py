from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

import argparse
import json

import pandas as pd

from darkcomet_stage2b.common import dump_json, load_config, project_root, safe_slug
from darkcomet_stage2b.weight_sensitivity import build_weight_sensitivity_summary


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--target", choices=["2020 GE", "2021 VH2"], default="2020 GE")
    args = parser.parse_args()

    cfg = load_config()
    root = project_root()
    slug = safe_slug(args.target)
    sigmas = [float(x) for x in cfg["weighting"]["sensitivity_fallback_sigmas_arcsec"]]
    baseline = float(cfg["weighting"]["fallback_sigma_arcsec"])
    rows = []
    missing = []
    for sigma in sigmas:
        for model in ("M_SY", "M_Y"):
            path = root / cfg["paths"]["models_directory"] / f"{slug}__{model}__fallback_{sigma:g}__summary.json"
            if not path.exists():
                missing.append(str(path.relative_to(root)))
                continue
            rows.append(json.loads(path.read_text(encoding="utf-8")))
    if missing:
        raise FileNotFoundError("Missing weight-sensitivity model summaries:\n" + "\n".join(missing))

    frame = pd.DataFrame(rows)
    gates = cfg["claim_gates"]
    summary = build_weight_sensitivity_summary(
        frame,
        target_id=args.target,
        required_sigmas=sigmas,
        baseline_sigma=baseline,
        min_abs_ratio=float(gates["weight_sensitivity_min_abs_A2_ratio_to_baseline"]),
        max_abs_ratio=float(gates["weight_sensitivity_max_abs_A2_ratio_to_baseline"]),
        min_abs_z=float(gates["parameter_abs_z_min"]),
        min_delta_bic=float(gates["weight_sensitivity_min_delta_bic_M_Y_minus_M_SY"]),
        min_delta_profile_bic=float(gates["weight_sensitivity_min_delta_profile_bic_M_Y_minus_M_SY"]),
    )
    summary["protocol_version"] = cfg["protocol"]["frozen_protocol_version"]

    tables = root / cfg["paths"]["tables_directory"]
    reports = root / cfg["paths"]["reports_directory"]
    json_out = tables / f"{slug}__weight_sensitivity_summary.json"
    csv_out = tables / f"{slug}__weight_sensitivity_summary.csv"
    report_out = reports / f"{slug}__weight_sensitivity_report.md"
    dump_json(json_out, summary)

    flat_rows = []
    for model, claim in summary["model_claims"].items():
        for row in claim["rows"]:
            flat_rows.append({"target_id": args.target, "model": model, **row})
    pd.DataFrame(flat_rows).to_csv(csv_out, index=False)

    lines = [
        f"# {args.target} fallback-weight sensitivity",
        "",
        f"- Protocol: {summary['protocol_version']}",
        f"- Tested fallback sigmas: {', '.join(f'{s:g}' for s in sigmas)} arcsec",
        f"- Overall gate: {summary['weight_sensitivity_gate_pass']}",
        f"- M_SY A2 gate: {summary['model_claims']['M_SY']['A2_weight_sensitivity_gate_pass']}",
        f"- M_Y A2 gate: {summary['model_claims']['M_Y']['A2_weight_sensitivity_gate_pass']}",
        f"- M_SY/M_Y ordering gate: {summary['model_ordering_gate_pass']}",
        "",
        "## A2 estimates",
        "",
        pd.DataFrame(flat_rows)[[
            "model", "fallback_sigma_arcsec", "fit_valid", "A2_estimated_au_d2",
            "A2_sigma_overdispersion_scaled_au_d2", "A2_z", "A2_ratio_to_baseline",
            "A2_sign_consistent_with_baseline", "rms_residual_arcsec", "reduced_chi2",
        ]].to_markdown(index=False),
        "",
        "## M_SY versus M_Y ordering",
        "",
        pd.DataFrame(summary["ordering_rows"]).to_markdown(index=False),
        "",
        "## Claim boundary",
        "",
        summary["claim_boundary"],
    ]
    report_out.write_text("\n".join(lines) + "\n", encoding="utf-8")

    print(json.dumps({
        "json": str(json_out),
        "csv": str(csv_out),
        "report": str(report_out),
        "weight_sensitivity_gate_pass": summary["weight_sensitivity_gate_pass"],
        "M_SY_A2_gate": summary["model_claims"]["M_SY"]["A2_weight_sensitivity_gate_pass"],
        "M_Y_A2_gate": summary["model_claims"]["M_Y"]["A2_weight_sensitivity_gate_pass"],
        "model_ordering_gate": summary["model_ordering_gate_pass"],
    }, indent=2))


if __name__ == "__main__":
    main()
