from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

import argparse
import json
import numpy as np
import pandas as pd

from darkcomet_stage2b.common import dump_json, load_config, project_root, safe_slug
from darkcomet_stage2b.horizons_identity import angular_separation_deg, exact_horizons_query_id
from darkcomet_stage2b.tudat_compat import jd_utc_to_tdb_seconds_since_j2000


def _query_group(HorizonsQuery, target_cfg, station, group):
    epochs_tdb = group["epoch_tdb_s_j2000"].astype(float).tolist()
    query = HorizonsQuery(
        query_id=exact_horizons_query_id(target_cfg),
        query_type="designation",
        location=str(station),
        epoch_list=epochs_tdb,
        extended_query=True,
    )
    predicted = np.asarray(
        query.interpolated_observations(
            degrees=True,
            reference_system="J2000",
            extra_precision=True,
        ),
        dtype=float,
    )
    if predicted.ndim != 2 or predicted.shape[0] != len(group) or predicted.shape[1] < 3:
        raise RuntimeError(
            f"Horizons returned shape {predicted.shape} for station {station}, expected ({len(group)}, >=3)"
        )
    rows = []
    for (_, obs), pred in zip(group.iterrows(), predicted):
        pred_ra = float(pred[1])
        pred_dec = float(pred[2])
        sep_deg = angular_separation_deg(float(obs["RA"]), float(obs["DEC"]), pred_ra, pred_dec)
        dra_deg = ((float(obs["RA"]) - pred_ra + 180.0) % 360.0) - 180.0
        rows.append({
            "target_id": str(obs["number"]),
            "observation_index": int(obs["observation_index"]),
            "station_code": str(station),
            "epoch_jd_utc": float(obs["epoch_jd_utc"]),
            "epoch_tdb_s_j2000": float(obs["epoch_tdb_s_j2000"]),
            "observed_ra_deg": float(obs["RA"]),
            "observed_dec_deg": float(obs["DEC"]),
            "horizons_ra_deg": pred_ra,
            "horizons_dec_deg": pred_dec,
            "delta_ra_wrapped_arcsec": dra_deg * 3600.0,
            "delta_dec_arcsec": (float(obs["DEC"]) - pred_dec) * 3600.0,
            "angular_separation_arcsec": sep_deg * 3600.0,
        })
    return rows


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--target", required=True, choices=["2020 GE", "2021 VH2"])
    parser.add_argument("--fallback-sigma", type=float, default=1.0)
    parser.add_argument("--gate-max-separation-arcsec", type=float, default=300.0)
    args = parser.parse_args()

    from tudatpy.data.horizons import HorizonsQuery

    cfg = load_config()
    root = project_root()
    slug = safe_slug(args.target)
    suffix = f"fallback_{args.fallback_sigma:g}"
    batch_path = root / cfg["paths"]["processed_directory"] / f"{slug}_batchmpc_{suffix}.csv"
    prepared_path = root / cfg["paths"]["processed_directory"] / f"{slug}_prepared_{suffix}.csv"
    if not batch_path.exists() or not prepared_path.exists():
        raise FileNotFoundError("Run 01_prepare_tudat_inputs.py first")

    batch = pd.read_csv(batch_path).reset_index(drop=True)
    prepared = pd.read_csv(prepared_path).reset_index(drop=True)
    if len(batch) != len(prepared):
        raise RuntimeError("Prepared and BatchMPC tables have different lengths")

    jd = pd.to_numeric(batch["epoch"], errors="raise").to_numpy(dtype=np.float64)
    tdb_seconds = jd_utc_to_tdb_seconds_since_j2000(jd)
    if jd.min() > 2_455_000.0 and np.any(tdb_seconds <= 0.0):
        raise RuntimeError("Post-2010 UTC Julian dates converted to non-positive J2000 TDB seconds")

    batch["observation_index"] = np.arange(len(batch), dtype=int)
    batch["cluster_id"] = prepared["cluster_id"].astype(int).to_numpy()
    batch["epoch_jd_utc"] = jd
    batch["epoch_tdb_s_j2000"] = tdb_seconds

    all_rows = []
    for station, group in batch.groupby("observatory", sort=True):
        group = group.sort_values("epoch_tdb_s_j2000").reset_index(drop=True)
        all_rows.extend(_query_group(HorizonsQuery, cfg["targets"][args.target], station, group))

    audit = pd.DataFrame(all_rows).sort_values("observation_index").reset_index(drop=True)
    audit["cluster_id"] = batch.loc[audit["observation_index"], "cluster_id"].to_numpy()
    audit["gate_max_separation_arcsec"] = float(args.gate_max_separation_arcsec)
    audit["gate_pass"] = audit["angular_separation_arcsec"] <= float(args.gate_max_separation_arcsec)

    table_path = root / cfg["paths"]["tables_directory"] / f"{slug}__horizons_all_epoch_audit.csv"
    audit.to_csv(table_path, index=False)

    cluster = audit.groupby("cluster_id", as_index=False).agg(
        n_observations=("observation_index", "size"),
        median_separation_arcsec=("angular_separation_arcsec", "median"),
        p95_separation_arcsec=("angular_separation_arcsec", lambda x: float(np.quantile(x, 0.95))),
        max_separation_arcsec=("angular_separation_arcsec", "max"),
        n_gate_fail=("gate_pass", lambda x: int((~x).sum())),
    )
    cluster_path = root / cfg["paths"]["tables_directory"] / f"{slug}__horizons_cluster_audit.csv"
    cluster.to_csv(cluster_path, index=False)

    worst = audit.nlargest(min(10, len(audit)), "angular_separation_arcsec")
    summary = {
        "target_id": args.target,
        "jpl_spkid": int(cfg["targets"][args.target]["jpl_spkid"]),
        "epoch_input_unit": "UTC Julian Day",
        "horizons_epoch_unit": "TDB seconds since J2000",
        "epoch_tdb_min": float(tdb_seconds.min()),
        "epoch_tdb_max": float(tdb_seconds.max()),
        "n_observations": int(len(audit)),
        "n_stations": int(audit["station_code"].nunique()),
        "n_clusters": int(audit["cluster_id"].nunique()),
        "median_separation_arcsec": float(audit["angular_separation_arcsec"].median()),
        "p95_separation_arcsec": float(audit["angular_separation_arcsec"].quantile(0.95)),
        "max_separation_arcsec": float(audit["angular_separation_arcsec"].max()),
        "gate_max_separation_arcsec": float(args.gate_max_separation_arcsec),
        "n_gate_fail": int((~audit["gate_pass"]).sum()),
        "all_epochs_identity_gate_pass": bool(audit["gate_pass"].all()),
        "worst_observations": worst[[
            "observation_index", "station_code", "cluster_id", "epoch_jd_utc",
            "epoch_tdb_s_j2000", "angular_separation_arcsec",
            "delta_ra_wrapped_arcsec", "delta_dec_arcsec"
        ]].to_dict(orient="records"),
        "interpretation": (
            "This audit converts the BatchMPC UTC Julian-day column to TDB seconds since J2000 before querying Horizons. "
            "If all epochs pass but Tudat global M0 fails, investigate dynamical transport/estimation. "
            "If only specific epochs or clusters fail, quarantine those observations before orbit refitting."
        ),
    }
    summary_path = root / cfg["paths"]["tables_directory"] / f"{slug}__horizons_all_epoch_audit_summary.json"
    dump_json(summary_path, summary)
    print(json.dumps(summary, indent=2))
    print("\nCluster summary:\n" + cluster.to_string(index=False))


if __name__ == "__main__":
    main()
