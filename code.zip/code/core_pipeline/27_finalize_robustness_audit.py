from __future__ import annotations

import argparse
from pathlib import Path

from _robustness_common import TARGET, dump_json, load_json, project_root


def optional_json(path: Path) -> dict:
    return load_json(path) if path.exists() else {}


def main() -> int:
    parser = argparse.ArgumentParser(description="Aggregate all robustness gates into a publication disposition.")
    parser.add_argument("--target", default=TARGET)
    args = parser.parse_args()
    root = project_root()
    loo = optional_json(root / "results/publication/2020_GE__M_Y__loo_validation.json")
    syst = optional_json(root / "results/systematics/2020_GE__M_Y__A2_systematic_uncertainty.json")
    nested = optional_json(root / "results/nested_audit/2020_GE__M_SRP__nested_restart_audit.json")
    weight = optional_json(root / "results/weighting_standard/2020_GE__standard_weighting_audit.json")
    radar = optional_json(root / "results/publication/2020_GE__radar_publication_disposition.json")

    gates = {
        "MY_five_cluster_LOO": bool(loo.get("MY_temporal_transport_gate_pass")),
        "MY_systematic_uncertainty_final": bool(syst) and not bool(syst.get("provisional_due_to_MSY_LOO_substitution")),
        "M_SRP_nested_ordering": bool(nested.get("nested_ordering_gate_pass")),
        "standard_weighting_transport": bool(weight.get("standard_weighting_transport_gate_pass")),
        "radar_disposition_generated": bool(radar),
    }
    optical_publication_ready = all(gates[k] for k in (
        "MY_five_cluster_LOO", "MY_systematic_uncertainty_final", "M_SRP_nested_ordering", "standard_weighting_transport"
    ))
    result = {
        "protocol_version": "0.6.0",
        "target_id": args.target,
        "gates": gates,
        "optical_publication_ready": optical_publication_ready,
        "radar_formal_closure_pass": bool(radar.get("formal_radar_closure_pass")),
        "radar_publication_disposition": radar.get("publication_disposition", "not_evaluated"),
        "overall_status": (
            "publication_ready_optical_with_formal_radar" if optical_publication_ready and radar.get("formal_radar_closure_pass")
            else "publication_ready_optical_radar_appendix_only" if optical_publication_ready and radar
            else "not_publication_ready"
        ),
        "claim_rule": "A2 may be called transport-valid only if the M_Y LOO and standard-weighting gates pass. Its formal covariance must be reported separately from temporal/model sensitivity. A1 may be ranked only after nested ordering is recovered. Radar is independent confirmation only after formal multiplier-1 closure.",
    }
    outdir = root / "results/publication"
    dump_json(outdir / "2020_GE__robustness_final_disposition_v0_6_0.json", result)
    lines = ["# 2020 GE robustness final disposition — v0.6.0", ""]
    lines.extend(f"- {name}: **{'PASS' if value else 'FAIL'}**" for name, value in gates.items())
    lines += ["", f"Overall status: **{result['overall_status']}**", "", result["claim_rule"]]
    (outdir / "2020_GE__robustness_final_disposition_v0_6_0.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    if not optical_publication_ready:
        raise RuntimeError("One or more optical publication gates failed. See final disposition report.")
    print("Optical publication robustness gates: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
