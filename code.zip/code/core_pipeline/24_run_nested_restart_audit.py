from __future__ import annotations

import argparse
import shutil
from pathlib import Path

from _robustness_common import (
    TARGET, copy_if_exists, dump_json, dump_yaml, load_json, load_yaml,
    model_parameters_path, model_summary_path, project_root, remove_glob,
    require_project_files, residual_path, run_python, write_csv,
)

SCENARIOS = [
    {"name": "zero_seed_iter8", "force_seed_policy": "zero", "maximum_iterations": 8},
    {"name": "zero_seed_iter16", "force_seed_policy": "zero", "maximum_iterations": 16},
    {"name": "catalogue_seed_iter16", "force_seed_policy": "catalogue_priors", "maximum_iterations": 16},
]


def main() -> int:
    parser = argparse.ArgumentParser(description="Repair and audit nested M_SRP convergence using frozen multi-start/restart scenarios.")
    parser.add_argument("--target", default=TARGET)
    args = parser.parse_args()
    root = project_root()
    require_project_files(root, ["scripts/03_run_model_family.py", "config/stage2b.yaml", "data/input/2020_GE_ades.csv"])

    config_path = root / "config/stage2b.yaml"
    original_bytes = config_path.read_bytes()
    canonical = {
        "summary": model_summary_path(root, "M_SRP"),
        "parameters": model_parameters_path(root, "M_SRP"),
        "residuals": residual_path(root, "M_SRP"),
    }
    original_outputs = {k: (p.read_bytes() if p.exists() else None) for k, p in canonical.items()}
    rows = []
    best = None
    try:
        for scenario in SCENARIOS:
            cfg = load_yaml(config_path)
            cfg["protocol"]["frozen_protocol_version"] = "0.6.0-nested-audit"
            cfg["targets"][args.target]["force_seed_policy"] = scenario["force_seed_policy"]
            cfg["dynamics"]["maximum_iterations"] = scenario["maximum_iterations"]
            dump_yaml(config_path, cfg)

            remove_glob(root / "results/models", "2020_GE__M_SRP__fallback_1__*")
            remove_glob(root / "results/residuals", "2020_GE__M_SRP__fallback_1__*")
            proc = run_python(root, "scripts/03_run_model_family.py", [
                "--target", args.target, "--model", "M_SRP", "--fallback-sigma", "1.0",
            ], check=False)
            outdir = root / "results/nested_audit" / scenario["name"]
            outdir.mkdir(parents=True, exist_ok=True)
            for key, path in canonical.items():
                copy_if_exists(path, outdir / path.name)
            summary = load_json(canonical["summary"]) if canonical["summary"].exists() else {}
            row = {
                **scenario,
                "process_returncode": proc.returncode,
                "summary_present": bool(summary),
                "fit_valid": bool(summary.get("fit_valid")),
                "best_iteration": summary.get("best_iteration"),
                "chi2": summary.get("chi2"),
                "reduced_chi2": summary.get("reduced_chi2"),
                "rms_residual_arcsec": summary.get("rms_residual_arcsec"),
                "srp_parallel_scale": summary.get("srp_parallel_scale"),
                "warm_start_source": summary.get("warm_start_source"),
                "configured_force_seed_policy": summary.get("configured_force_seed_policy"),
            }
            rows.append(row)
            if row["fit_valid"] and row["chi2"] is not None:
                if best is None or float(row["chi2"]) < float(best["chi2"]):
                    best = {**row, "directory": outdir}
    finally:
        config_path.write_bytes(original_bytes)

    m0 = load_json(model_summary_path(root, "M0"))
    my = load_json(model_summary_path(root, "M_Y"))
    msy = load_json(model_summary_path(root, "M_SY"))
    tol = float(load_yaml(config_path).get("dynamics", {}).get("nested_chi2_tolerance", 1e-6))
    nested_gate = bool(best) and (
        float(best["chi2"]) <= float(m0["chi2"]) + tol
        and float(msy["chi2"]) <= float(my["chi2"]) + tol
        and float(msy["chi2"]) <= float(best["chi2"]) + tol
    )

    if nested_gate and best is not None:
        for key, path in canonical.items():
            candidate = Path(best["directory"]) / path.name
            if candidate.exists():
                shutil.copy2(candidate, path)
    else:
        for key, path in canonical.items():
            payload = original_outputs[key]
            if payload is None:
                if path.exists():
                    path.unlink()
            else:
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(payload)

    result = {
        "protocol_version": "0.6.0",
        "target_id": args.target,
        "scenarios": rows,
        "best_scenario": None if best is None else {k: v for k, v in best.items() if k != "directory"},
        "M0_chi2": m0.get("chi2"),
        "M_Y_chi2": my.get("chi2"),
        "M_SY_chi2": msy.get("chi2"),
        "nested_chi2_tolerance": tol,
        "nested_ordering_gate_pass": nested_gate,
        "canonical_M_SRP_replaced_with_best_valid_restart": nested_gate,
        "failure_disposition": None if nested_gate else "M_SRP remains optimizer-diagnostic only and must be excluded from model ranking.",
    }
    outdir = root / "results/nested_audit"
    dump_json(outdir / "2020_GE__M_SRP__nested_restart_audit.json", result)
    write_csv(outdir / "2020_GE__M_SRP__nested_restart_audit.csv", rows)
    report = ["# 2020 GE M_SRP nested restart audit", "", f"Nested ordering gate: **{'PASS' if nested_gate else 'FAIL'}**", ""]
    for row in rows:
        report.append(f"- `{row['name']}`: return={row['process_returncode']}, fit_valid={row['fit_valid']}, chi2={row['chi2']}, RMS={row['rms_residual_arcsec']}")
    report += ["", result["failure_disposition"] or "The lowest-chi2 valid restart has been promoted to the canonical M_SRP output."]
    (outdir / "2020_GE__M_SRP__nested_restart_audit.md").write_text("\n".join(report) + "\n", encoding="utf-8")
    if not nested_gate:
        raise RuntimeError("M_SRP nested ordering was not recovered; canonical diagnostic output was preserved and ranking remains prohibited.")
    print("M_SRP nested restart gate: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
