from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

import argparse
import json
import subprocess
import sys
import pandas as pd
from darkcomet_stage2b.common import dump_json, load_config, project_root, safe_slug


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--target", required=True, choices=["2020 GE", "2021 VH2"])
    parser.add_argument("--model", required=True, choices=["M_SRP", "M_Y", "M_SY"])
    parser.add_argument("--fallback-sigma", type=float, default=1.0)
    args = parser.parse_args()

    cfg = load_config()
    root = project_root()
    slug = safe_slug(args.target)
    suffix = f"fallback_{args.fallback_sigma:g}"
    prepared = pd.read_csv(
        root / cfg["paths"]["processed_directory"] / f"{slug}_prepared_{suffix}.csv"
    )
    clusters = sorted(prepared["cluster_id"].astype(int).unique())
    rows = []
    for cluster in clusters:
        tag = f"{slug}__{args.model}__{suffix}__exclude_cluster_{cluster}"
        summary_path = root / cfg["paths"]["models_directory"] / f"{tag}__summary.json"
        failure_path = root / cfg["paths"]["models_directory"] / f"{tag}__failure.json"
        for stale in (summary_path, failure_path):
            if stale.exists():
                stale.unlink()
        cmd = [
            sys.executable,
            str(root / "scripts" / "03_run_model_family.py"),
            "--target", args.target,
            "--model", args.model,
            "--fallback-sigma", str(args.fallback_sigma),
            "--exclude-cluster", str(cluster),
        ]
        print("\n>", " ".join(cmd), flush=True)
        proc = subprocess.run(cmd, check=False, cwd=root)
        rows.append({
            "target_id": args.target,
            "model": args.model,
            "fallback_sigma_arcsec": args.fallback_sigma,
            "excluded_cluster": int(cluster),
            "returncode": int(proc.returncode),
            "summary_exists": summary_path.exists(),
            "failure_exists": failure_path.exists(),
            "status": "success" if proc.returncode == 0 and summary_path.exists() else "failed",
            "summary_path": str(summary_path),
            "failure_path": str(failure_path),
        })

    frame = pd.DataFrame(rows).sort_values("excluded_cluster")
    out_csv = root / cfg["paths"]["loo_directory"] / f"{slug}__{args.model}__{suffix}__loo_run_manifest.csv"
    out_json = root / cfg["paths"]["loo_directory"] / f"{slug}__{args.model}__{suffix}__loo_run_manifest.json"
    frame.to_csv(out_csv, index=False)
    dump_json(out_json, {
        "target_id": args.target,
        "model": args.model,
        "fallback_sigma_arcsec": args.fallback_sigma,
        "n_clusters": len(rows),
        "n_success": int((frame["status"] == "success").sum()),
        "n_failed": int((frame["status"] != "success").sum()),
        "rows": rows,
    })
    print("\nLOO run manifest:\n" + frame.to_string(index=False))
    if (frame["status"] != "success").any():
        raise SystemExit(2)


if __name__ == "__main__":
    main()
