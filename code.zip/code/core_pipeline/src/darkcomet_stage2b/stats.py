from __future__ import annotations
import math
import numpy as np


def information_criteria(chi2: float, n_scalar: int, k: int) -> dict[str, float]:
    if n_scalar <= k + 1:
        aicc = float("nan")
    else:
        aicc = chi2 + 2.0 * k + (2.0 * k * (k + 1.0)) / (n_scalar - k - 1.0)
    return {
        "chi2": float(chi2),
        "n_scalar": int(n_scalar),
        "k": int(k),
        "reduced_chi2": float(chi2 / max(n_scalar - k, 1)),
        "aic": float(chi2 + 2.0 * k),
        "aicc": float(aicc),
        "bic": float(chi2 + k * math.log(n_scalar)),
    }


def safe_z(value: float, sigma: float) -> float:
    if not np.isfinite(value) or not np.isfinite(sigma) or sigma <= 0:
        return float("nan")
    return float(value / sigma)
