from __future__ import annotations

import math
from typing import Any

import numpy as np

TWO_PI = 2.0 * math.pi
ARCSEC_PER_RAD = 206_264.80624709636


def wrap_to_pi(values: np.ndarray) -> np.ndarray:
    array = np.asarray(values, dtype=float)
    return (array + math.pi) % TWO_PI - math.pi


def normalize_ra_observation_branches(
    observations: np.ndarray,
    residuals: np.ndarray,
) -> tuple[np.ndarray, dict[str, Any]]:
    """Shift RA observations by integer multiples of 2π to the local model branch.

    Angular-position observations are stored as [RA, DEC] pairs.  Right ascension
    is periodic, while declination is not.  TudatPy 1.0 can return an unwrapped
    observed-minus-computed RA residual close to ±2π for a physically tiny angular
    difference.  This function changes only the numerical representation of RA,
    never the physical direction: each corrected RA differs from the input by an
    integer multiple of 2π.
    """
    observed = np.asarray(observations, dtype=float).reshape(-1)
    raw_residual = np.asarray(residuals, dtype=float).reshape(-1)
    if observed.size == 0 or observed.size != raw_residual.size:
        raise ValueError("observations and residuals must be non-empty vectors of equal size")
    if observed.size % 2 != 0:
        raise ValueError("angular-position vector must contain [RA, DEC] pairs")
    if not np.isfinite(observed).all() or not np.isfinite(raw_residual).all():
        raise ValueError("observations and residuals must be finite")

    corrected = observed.copy()
    ra_indices = np.arange(0, observed.size, 2, dtype=int)
    ra_residuals = raw_residual[ra_indices]
    branch_integers = np.rint(ra_residuals / TWO_PI).astype(int)
    shifts = -TWO_PI * branch_integers.astype(float)
    corrected[ra_indices] += shifts

    wrapped_residual = raw_residual.copy()
    wrapped_residual[ra_indices] = wrap_to_pi(ra_residuals)
    expected_after_shift = raw_residual.copy()
    expected_after_shift[ra_indices] += shifts

    changed_mask = branch_integers != 0
    changed_ra_indices = ra_indices[changed_mask]
    max_equivalence_error = float(
        np.max(np.abs(expected_after_shift[ra_indices] - wrapped_residual[ra_indices]))
    )
    if max_equivalence_error > 1.0e-12:
        raise RuntimeError(
            f"RA branch normalization equivalence error is too large: {max_equivalence_error} rad"
        )

    return corrected, {
        "method": "prefit_observed_minus_computed_nearest_2pi_branch",
        "n_scalar_observations": int(observed.size),
        "n_vector_observations": int(observed.size // 2),
        "n_ra_branch_shifts": int(np.count_nonzero(changed_mask)),
        "shifted_ra_scalar_indices": changed_ra_indices.tolist(),
        "shifted_vector_indices": (changed_ra_indices // 2).tolist(),
        "branch_integers": branch_integers[changed_mask].tolist(),
        "ra_shifts_rad": shifts[changed_mask].tolist(),
        "ra_shifts_deg": np.degrees(shifts[changed_mask]).tolist(),
        "raw_prefit_rms_arcsec": float(
            np.sqrt(np.mean(raw_residual**2)) * ARCSEC_PER_RAD
        ),
        "periodic_prefit_rms_arcsec": float(
            np.sqrt(np.mean(wrapped_residual**2)) * ARCSEC_PER_RAD
        ),
        "raw_prefit_max_abs_arcsec": float(
            np.max(np.abs(raw_residual)) * ARCSEC_PER_RAD
        ),
        "periodic_prefit_max_abs_arcsec": float(
            np.max(np.abs(wrapped_residual)) * ARCSEC_PER_RAD
        ),
        "max_equivalence_error_rad": max_equivalence_error,
        "physical_angles_unchanged": True,
    }
