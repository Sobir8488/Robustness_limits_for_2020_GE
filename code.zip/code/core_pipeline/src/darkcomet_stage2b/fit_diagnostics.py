from __future__ import annotations

import hashlib
import math
from typing import Any

import numpy as np


def _sha256_float64(values: np.ndarray) -> str:
    array = np.ascontiguousarray(np.asarray(values, dtype=np.float64).reshape(-1))
    return hashlib.sha256(array.tobytes()).hexdigest()


def weighted_fit_statistics(
    residuals: np.ndarray,
    weights: np.ndarray,
    n_parameters: int | None = None,
    parameter_count: int | None = None,
) -> dict[str, Any]:
    if n_parameters is None:
        n_parameters = parameter_count
    if n_parameters is None:
        raise TypeError("n_parameters or parameter_count is required")
    residuals = np.asarray(residuals, dtype=np.float64).reshape(-1)
    weights = np.asarray(weights, dtype=np.float64).reshape(-1)
    if residuals.size == 0 or residuals.size != weights.size:
        raise ValueError("Residual and weight vectors must be non-empty and equal length")
    if not np.isfinite(residuals).all():
        raise ValueError("Residual vector contains non-finite values")
    if not np.isfinite(weights).all() or np.any(weights <= 0.0):
        raise ValueError("Weights must be finite and strictly positive")

    normalized = residuals * np.sqrt(weights)
    chi2 = float(np.dot(normalized, normalized))
    dof = max(int(residuals.size) - int(n_parameters), 1)
    reduced_chi2 = float(chi2 / dof)
    profile_bic = float(
        residuals.size * math.log(max(chi2 / residuals.size, 1.0e-300))
        + int(n_parameters) * math.log(residuals.size)
    )
    return {
        "chi2": chi2,
        "n_scalar": int(residuals.size),
        "k": int(n_parameters),
        "reduced_chi2": reduced_chi2,
        "normalized_residual_rms": float(np.sqrt(np.mean(normalized ** 2))),
        "profile_scale_bic": profile_bic,
        "weight_vector_sha256": _sha256_float64(weights),
        "residual_vector_sha256": _sha256_float64(residuals),
    }
