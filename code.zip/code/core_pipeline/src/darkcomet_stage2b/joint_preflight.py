from __future__ import annotations

import math
from typing import Any

import numpy as np


def finite_rms(values) -> float:
    arr = np.asarray(values, dtype=float).reshape(-1)
    if arr.size == 0 or not np.isfinite(arr).all():
        return float("nan")
    return float(np.sqrt(np.mean(np.square(arr))))


def normalized_rms(residuals, weights) -> float:
    r = np.asarray(residuals, dtype=float).reshape(-1)
    w = np.asarray(weights, dtype=float).reshape(-1)
    if r.size == 0 or r.size != w.size or not np.isfinite(r).all() or not np.isfinite(w).all() or np.any(w <= 0):
        return float("nan")
    return float(np.sqrt(np.mean(np.square(r) * w)))


def parameter_update_diagnostics(initial, final) -> dict[str, Any]:
    a = np.asarray(initial, dtype=float).reshape(-1)
    b = np.asarray(final, dtype=float).reshape(-1)
    if a.size != b.size:
        raise ValueError("Initial and final parameter vectors must have the same length")
    delta = b - a
    return {
        "parameter_count": int(a.size),
        "update_finite": bool(np.isfinite(delta).all()),
        "state_position_update_norm_m": float(np.linalg.norm(delta[:3])) if a.size >= 3 else None,
        "state_velocity_update_norm_m_s": float(np.linalg.norm(delta[3:6])) if a.size >= 6 else None,
        "full_parameter_update_norm": float(np.linalg.norm(delta)),
        "parameter_update_vector": [float(x) for x in delta],
    }


def preflight_gate(summary: dict[str, Any]) -> bool:
    return bool(
        summary.get("runtime_success", False)
        and summary.get("observation_partition_gate_pass", False)
        and summary.get("parameter_update", {}).get("update_finite", False)
        and summary.get("all_final_residuals_finite", False)
        and summary.get("radar_postfit_nrms_improved", False)
    )
