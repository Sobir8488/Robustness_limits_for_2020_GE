from __future__ import annotations

from bisect import bisect_right
import math
from typing import Callable
import numpy as np

C_M_S = 299_792_458.0
WGS84_A_M = 6_378_137.0
WGS84_F = 1.0 / 298.257223563


def geodetic_to_ecef_m(longitude_deg: float, latitude_deg: float, altitude: float, altitude_units: str) -> np.ndarray:
    units = str(altitude_units).strip().lower()
    scale = {"m": 1.0, "km": 1000.0, "ft": 0.3048}.get(units)
    if scale is None:
        raise ValueError(f"Unsupported altitude units: {altitude_units!r}")
    h = float(altitude) * scale
    lon = math.radians(float(longitude_deg))
    lat = math.radians(float(latitude_deg))
    e2 = WGS84_F * (2.0 - WGS84_F)
    n = WGS84_A_M / math.sqrt(1.0 - e2 * math.sin(lat) ** 2)
    return np.array([
        (n + h) * math.cos(lat) * math.cos(lon),
        (n + h) * math.cos(lat) * math.sin(lon),
        (n * (1.0 - e2) + h) * math.sin(lat),
    ], dtype=float)


class HermiteStateInterpolator:
    def __init__(self, state_history: dict[float, np.ndarray]):
        if len(state_history) < 2:
            raise ValueError("State history requires at least two epochs")
        self.times = np.array(sorted(float(t) for t in state_history), dtype=float)
        self.states = np.vstack([np.asarray(state_history[float(t)], dtype=float).reshape(-1)[:6] for t in self.times])
        if self.states.shape[1] != 6 or not np.isfinite(self.states).all():
            raise ValueError("State history must contain finite Cartesian 6-vectors")

    def __call__(self, epoch: float) -> np.ndarray:
        t = float(epoch)
        if t < self.times[0] or t > self.times[-1]:
            raise ValueError(f"Epoch {t} outside state-history bounds {self.times[0]}..{self.times[-1]}")
        j = min(max(bisect_right(self.times, t) - 1, 0), len(self.times) - 2)
        t0, t1 = self.times[j], self.times[j + 1]
        y0, y1 = self.states[j], self.states[j + 1]
        h = t1 - t0
        u = (t - t0) / h
        h00 = 2*u**3 - 3*u**2 + 1
        h10 = u**3 - 2*u**2 + u
        h01 = -2*u**3 + 3*u**2
        h11 = u**3 - u**2
        pos = h00*y0[:3] + h10*h*y0[3:] + h01*y1[:3] + h11*h*y1[3:]
        dh00 = (6*u**2 - 6*u)/h
        dh10 = 3*u**2 - 4*u + 1
        dh01 = (-6*u**2 + 6*u)/h
        dh11 = 3*u**2 - 2*u
        vel = dh00*y0[:3] + dh10*y0[3:] + dh01*y1[:3] + dh11*y1[3:]
        return np.concatenate([pos, vel])


def solve_two_way_light_time(
    receive_epoch: float,
    receiver_position: Callable[[float], np.ndarray],
    transmitter_position: Callable[[float], np.ndarray],
    target_position: Callable[[float], np.ndarray],
    *,
    tolerance_s: float = 1.0e-10,
    max_iterations: int = 50,
) -> tuple[float, float, float]:
    tr = float(receive_epoch)
    rr = np.asarray(receiver_position(tr), dtype=float)
    tb = tr - np.linalg.norm(rr - target_position(tr)) / C_M_S
    for _ in range(max_iterations):
        new = tr - np.linalg.norm(rr - target_position(tb)) / C_M_S
        if abs(new - tb) <= tolerance_s:
            tb = new; break
        tb = new
    else:
        raise RuntimeError("Downlink light-time iteration did not converge")
    rt = np.asarray(target_position(tb), dtype=float)
    tt = tb - np.linalg.norm(rt - transmitter_position(tb)) / C_M_S
    for _ in range(max_iterations):
        new = tb - np.linalg.norm(rt - transmitter_position(tt)) / C_M_S
        if abs(new - tt) <= tolerance_s:
            tt = new; break
        tt = new
    else:
        raise RuntimeError("Uplink light-time iteration did not converge")
    return tt, tb, tr


def predict_delay_seconds(receive_epoch: float, receiver_position, transmitter_position, target_position) -> float:
    tt, _, tr = solve_two_way_light_time(receive_epoch, receiver_position, transmitter_position, target_position)
    return tr - tt


def predict_doppler_hz(receive_epoch: float, transmit_frequency_hz: float, delay_function: Callable[[float], float], derivative_step_s: float = 1.0) -> float:
    h = float(derivative_step_s)
    if h <= 0:
        raise ValueError("Derivative step must be positive")
    ddt = (delay_function(receive_epoch + h) - delay_function(receive_epoch - h)) / (2.0*h)
    return -float(transmit_frequency_hz) * ddt
