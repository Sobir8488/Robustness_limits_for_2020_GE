from __future__ import annotations

from typing import Any
import math
import numpy as np


def _finite(value: Any) -> bool:
    try:
        return math.isfinite(float(value))
    except (TypeError, ValueError):
        return False



def weighted_constant_bias_profile(
    residuals: Any,
    weights: Any,
    groups: dict[str, slice],
) -> dict[str, Any]:
    """Return the exact WLS profile for one additive constant per group."""
    r = np.asarray(residuals, dtype=float).reshape(-1)
    w = np.asarray(weights, dtype=float).reshape(-1)
    if r.size != w.size or r.size == 0:
        raise ValueError("Residual and weight vectors must have equal non-zero size")
    if not np.isfinite(r).all() or not np.isfinite(w).all() or np.any(w <= 0.0):
        raise ValueError("Residuals and positive weights must be finite")
    profiled = r.copy()
    biases: dict[str, float] = {}
    for name, group in groups.items():
        rg = r[group]
        wg = w[group]
        if rg.size == 0:
            raise ValueError(f"Empty profile group: {name}")
        bias = float(np.average(rg, weights=wg))
        biases[name] = bias
        profiled[group] -= bias
    return {"biases": biases, "profiled_residuals": profiled}

def classify_dynamic_increment(
    bias_only: dict[str, Any],
    dynamic_bias: dict[str, Any],
    *,
    minimum_fractional_radar_nrms_gain: float,
) -> dict[str, Any]:
    bo = float(bias_only['fit_radar_postfit_nrms'])
    db = float(dynamic_bias['fit_radar_postfit_nrms'])
    gain = (bo - db) / bo if bo > 0.0 else float('nan')
    holdout_improved = bool(dynamic_bias.get('holdout_residual_improved', False))
    if _finite(gain) and gain < minimum_fractional_radar_nrms_gain:
        status = 'nuisance_only_sufficient_at_current_weight'
    elif holdout_improved:
        status = 'dynamic_increment_transport_supported'
    else:
        status = 'dynamic_increment_in_sample_only_not_transport_validated'
    return {
        'bias_only_fit_radar_postfit_nrms': bo,
        'dynamic_bias_fit_radar_postfit_nrms': db,
        'dynamic_increment_fractional_radar_nrms_gain': gain,
        'dynamic_bias_holdout_residual_improved': holdout_improved,
        'dynamic_increment_status': status,
    }


def summarize_identifiability(
    bias_only_by_model: dict[str, dict[str, Any]],
    dynamic_bias_by_model: dict[str, dict[str, Any]],
    settings: dict[str, Any],
) -> dict[str, Any]:
    model_results: dict[str, Any] = {}
    threshold = float(settings['minimum_fractional_radar_nrms_gain'])
    for model, bo in bias_only_by_model.items():
        db = dynamic_bias_by_model[model]
        row = classify_dynamic_increment(
            bo, db, minimum_fractional_radar_nrms_gain=threshold
        )
        force = db.get('force_parameter_diagnostics', {})
        row.update({
            'bias_only_gate_pass': bool(bo.get('bias_only_gate_pass', False)),
            'dynamic_bias_gate_pass': bool(db.get('bias_control_gate_pass', False)),
            'dynamic_bias_optical_postfit_rms_arcsec': db.get('optical_postfit_rms_arcsec'),
            'dynamic_bias_holdout_postfit_abs_residual_hz': db.get('holdout_postfit_abs_residual_hz'),
            'A2_abs_ratio_to_optical_baseline': force.get('A2_abs_ratio_to_optical_baseline'),
            'srp_scale_final': force.get('srp_scale_final'),
            'range_bias_final_m': db.get('bias_parameter_diagnostics', {}).get('range_bias_final_m'),
            'doppler_bias_final_hz_at_8560MHz': db.get('bias_parameter_diagnostics', {}).get('doppler_bias_final_hz_at_8560MHz'),
        })
        model_results[model] = row

    transport_model = min(
        dynamic_bias_by_model,
        key=lambda m: abs(float(dynamic_bias_by_model[m]['holdout_postfit_residual_hz'])),
    )
    a2_stable = all(
        _finite(model_results[m].get('A2_abs_ratio_to_optical_baseline'))
        and abs(float(model_results[m]['A2_abs_ratio_to_optical_baseline']) - 1.0)
        <= float(settings['max_abs_A2_fractional_drift'])
        for m in model_results
    )
    msy = model_results.get('M_SY', {})
    my = model_results.get('M_Y', {})
    msy_holdout_worse = (
        'M_SY' in dynamic_bias_by_model and 'M_Y' in dynamic_bias_by_model
        and abs(float(dynamic_bias_by_model['M_SY']['holdout_postfit_residual_hz']))
        > abs(float(dynamic_bias_by_model['M_Y']['holdout_postfit_residual_hz']))
    )
    srp_unstable = _finite(msy.get('srp_scale_final')) and abs(float(msy['srp_scale_final'])) > float(settings['max_abs_srp_scale_for_external_support'])

    return {
        'model_results': model_results,
        'transport_preferred_model': transport_model,
        'A2_external_status': (
            'stable_under_bias_control_but_not_independently_confirmed'
            if a2_stable else 'bias_control_sensitive'
        ),
        'A1_external_support_status': (
            'not_supported_by_bias_identifiability_and_holdout'
            if msy_holdout_worse and srp_unstable
            else 'mixed_or_inconclusive'
        ),
        'publication_joint_radar_claim_ready': False,
        'claim_boundary': (
            'Bias-only and dynamic-plus-bias fits diagnose identifiability at the softened x30 radar weight. '
            'In-sample radar improvement without holdout transport does not validate a physical force parameter.'
        ),
    }
