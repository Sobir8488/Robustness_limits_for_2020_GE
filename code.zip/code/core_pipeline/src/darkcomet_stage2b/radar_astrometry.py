from __future__ import annotations

import json
import math
from collections import Counter
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib.parse import urlencode
from urllib.request import Request, urlopen
from time import sleep

import pandas as pd

from .common import dump_json, sha256_file

API_BASE = "https://ssd-api.jpl.nasa.gov/sb_radar.api"
EXPECTED_API_MAJOR = "1"
REQUIRED_FIELDS = ("des", "epoch", "value", "sigma", "units", "freq", "rcvr", "xmit", "bp")
ALLOWED_UNITS = {"us", "Hz"}
ALLOWED_BOUNCE_POINTS = {"P", "C"}


@dataclass(frozen=True)
class RadarPaths:
    raw_json: Path
    normalized_csv: Path
    coordinates_json: Path
    summary_json: Path
    report_md: Path


def build_query_url(*, spk_id: str | int) -> str:
    query = urlencode(
        {
            "spk": str(spk_id),
            "observer": "1",
            "notes": "1",
            "ref": "1",
            "fullname": "1",
            "modified": "1",
            "coords": "1",
        }
    )
    return f"{API_BASE}?{query}"


def download_json(url: str, *, timeout_s: float = 60.0, attempts: int = 3) -> dict[str, Any]:
    request = Request(
        url,
        headers={
            "User-Agent": "darkcomet-stage2b-radar-audit/0.4.7",
            "Accept": "application/json",
        },
    )
    last_error: Exception | None = None
    for attempt in range(1, max(1, int(attempts)) + 1):
        try:
            with urlopen(request, timeout=timeout_s) as response:  # nosec B310 - frozen NASA/JPL HTTPS endpoint
                payload = response.read()
            decoded = json.loads(payload.decode("utf-8"))
            if not isinstance(decoded, dict):
                raise ValueError("JPL radar API payload is not a JSON object")
            return decoded
        except Exception as exc:  # network/HTTP/JSON failures are retried and then surfaced
            last_error = exc
            if attempt < max(1, int(attempts)):
                sleep(float(attempt))
    raise RuntimeError(f"JPL radar API download failed after {attempts} attempts: {last_error}") from last_error


def payload_to_frame(payload: dict[str, Any]) -> pd.DataFrame:
    fields = payload.get("fields") or []
    data = payload.get("data") or []
    if not isinstance(fields, list) or not isinstance(data, list):
        raise ValueError("JPL radar API fields/data are malformed")
    frame = pd.DataFrame(data, columns=fields)
    for field in REQUIRED_FIELDS:
        if field not in frame.columns:
            frame[field] = pd.NA
    return frame


def _to_float(value: Any) -> float | None:
    try:
        out = float(value)
    except (TypeError, ValueError):
        return None
    return out if math.isfinite(out) else None


def normalize_frame(frame: pd.DataFrame) -> pd.DataFrame:
    out = frame.copy()
    for col in ("value", "sigma", "freq"):
        out[col] = pd.to_numeric(out[col], errors="coerce")
    out["epoch_utc"] = pd.to_datetime(out["epoch"], utc=True, errors="coerce")
    out["measurement_type"] = out["units"].map({"us": "delay", "Hz": "doppler"}).fillna("unknown")
    out["station_pair"] = out["xmit"].astype(str) + "->" + out["rcvr"].astype(str)
    out["is_center_of_mass"] = out["bp"].eq("C")
    out["is_peak_power"] = out["bp"].eq("P")
    preferred = [
        "des",
        "fullname",
        "epoch",
        "epoch_utc",
        "measurement_type",
        "value",
        "sigma",
        "units",
        "freq",
        "xmit",
        "rcvr",
        "station_pair",
        "bp",
        "is_center_of_mass",
        "is_peak_power",
        "observer",
        "notes",
        "ref",
        "modified",
    ]
    return out[[c for c in preferred if c in out.columns] + [c for c in out.columns if c not in preferred]]


def summarize_payload(
    *,
    payload: dict[str, Any],
    frame: pd.DataFrame,
    target_id: str,
    spk_id: str | int,
    query_url: str,
    raw_json_path: Path | None = None,
) -> dict[str, Any]:
    normalized = normalize_frame(frame)
    api_version = str((payload.get("signature") or {}).get("version") or "")
    declared_count_raw = payload.get("count", 0)
    try:
        declared_count = int(declared_count_raw)
    except (TypeError, ValueError):
        declared_count = -1

    units = [str(x) for x in normalized.get("units", pd.Series(dtype=object)).dropna().tolist()]
    bps = [str(x) for x in normalized.get("bp", pd.Series(dtype=object)).dropna().tolist()]
    designations = sorted({str(x) for x in normalized.get("des", pd.Series(dtype=object)).dropna().tolist()})
    station_pairs = Counter(str(x) for x in normalized.get("station_pair", pd.Series(dtype=object)).dropna().tolist())
    transmitters = Counter(str(x) for x in normalized.get("xmit", pd.Series(dtype=object)).dropna().tolist())
    receivers = Counter(str(x) for x in normalized.get("rcvr", pd.Series(dtype=object)).dropna().tolist())

    epochs = normalized.get("epoch_utc", pd.Series(dtype="datetime64[ns, UTC]"))
    valid_epochs = epochs.dropna() if hasattr(epochs, "dropna") else []
    epoch_min = valid_epochs.min().isoformat() if len(valid_epochs) else None
    epoch_max = valid_epochs.max().isoformat() if len(valid_epochs) else None

    sigma = pd.to_numeric(normalized.get("sigma", pd.Series(dtype=float)), errors="coerce")
    value = pd.to_numeric(normalized.get("value", pd.Series(dtype=float)), errors="coerce")
    freq = pd.to_numeric(normalized.get("freq", pd.Series(dtype=float)), errors="coerce")

    count = int(len(normalized))
    delay_count = int((normalized.get("units", pd.Series(dtype=object)) == "us").sum())
    doppler_count = int((normalized.get("units", pd.Series(dtype=object)) == "Hz").sum())
    com_count = int((normalized.get("bp", pd.Series(dtype=object)) == "C").sum())
    peak_count = int((normalized.get("bp", pd.Series(dtype=object)) == "P").sum())
    unknown_bp_count = int((~normalized.get("bp", pd.Series(dtype=object)).isin(ALLOWED_BOUNCE_POINTS)).sum()) if count else 0

    api_version_gate = bool(api_version and api_version.split(".")[0] == EXPECTED_API_MAJOR)
    count_gate = count > 0 and declared_count == count
    schema_gate = all(field in (payload.get("fields") or []) for field in REQUIRED_FIELDS)
    epoch_gate = count > 0 and int(pd.isna(epochs).sum()) == 0
    numeric_gate = count > 0 and int(value.isna().sum()) == 0 and int(sigma.isna().sum()) == 0 and int(freq.isna().sum()) == 0
    positive_sigma_gate = count > 0 and bool((sigma > 0).all())
    positive_frequency_gate = count > 0 and bool((freq > 0).all())
    unit_gate = count > 0 and set(units).issubset(ALLOWED_UNITS)
    station_gate = count > 0 and bool(normalized["xmit"].notna().all()) and bool(normalized["rcvr"].notna().all())
    bounce_point_gate = count > 0 and unknown_bp_count == 0
    designation_gate = count > 0 and len(designations) == 1
    coordinates = payload.get("coords") or {}
    station_codes = set(str(x) for x in normalized.get("xmit", pd.Series(dtype=object)).dropna()) | set(
        str(x) for x in normalized.get("rcvr", pd.Series(dtype=object)).dropna()
    )
    coordinate_gate = bool(station_codes) and station_codes.issubset(set(str(k) for k in coordinates.keys()))

    acquisition_gate_pass = all(
        [
            api_version_gate,
            count_gate,
            schema_gate,
            epoch_gate,
            numeric_gate,
            positive_sigma_gate,
            positive_frequency_gate,
            unit_gate,
            station_gate,
            bounce_point_gate,
            designation_gate,
        ]
    )
    dual_observable_available = delay_count > 0 and doppler_count > 0
    direct_center_of_mass_fit_ready = acquisition_gate_pass and dual_observable_available and peak_count == 0 and coordinate_gate
    requires_bounce_point_model = peak_count > 0

    if direct_center_of_mass_fit_ready:
        fit_readiness = "direct_center_of_mass_joint_fit_ready"
    elif acquisition_gate_pass and dual_observable_available and requires_bounce_point_model:
        fit_readiness = "audit_ready_but_peak_power_records_require_bounce_point_model"
    elif acquisition_gate_pass:
        fit_readiness = "audit_ready_but_dual_delay_doppler_layer_incomplete"
    else:
        fit_readiness = "radar_acquisition_or_integrity_gate_failed"

    return {
        "target_id": target_id,
        "requested_spk_id": str(spk_id),
        "query_url": query_url,
        "retrieved_utc": datetime.now(timezone.utc).isoformat(),
        "api_signature": payload.get("signature"),
        "api_version_gate_pass": api_version_gate,
        "declared_count": declared_count,
        "parsed_count": count,
        "count_gate_pass": count_gate,
        "schema_gate_pass": schema_gate,
        "designations": designations,
        "designation_gate_pass": designation_gate,
        "epoch_min_utc": epoch_min,
        "epoch_max_utc": epoch_max,
        "epoch_gate_pass": epoch_gate,
        "delay_count": delay_count,
        "doppler_count": doppler_count,
        "dual_observable_available": dual_observable_available,
        "center_of_mass_count": com_count,
        "peak_power_count": peak_count,
        "unknown_bounce_point_count": unknown_bp_count,
        "requires_bounce_point_model": requires_bounce_point_model,
        "units_counts": dict(Counter(units)),
        "bounce_point_counts": dict(Counter(bps)),
        "transmitter_counts": dict(transmitters),
        "receiver_counts": dict(receivers),
        "station_pair_counts": dict(station_pairs),
        "station_codes": sorted(station_codes),
        "coordinate_codes": sorted(str(k) for k in coordinates.keys()),
        "coordinate_gate_pass": coordinate_gate,
        "numeric_gate_pass": numeric_gate,
        "positive_sigma_gate_pass": positive_sigma_gate,
        "positive_frequency_gate_pass": positive_frequency_gate,
        "unit_gate_pass": unit_gate,
        "station_gate_pass": station_gate,
        "bounce_point_gate_pass": bounce_point_gate,
        "acquisition_gate_pass": acquisition_gate_pass,
        "direct_center_of_mass_fit_ready": direct_center_of_mass_fit_ready,
        "fit_readiness": fit_readiness,
        "raw_json_sha256": sha256_file(raw_json_path) if raw_json_path and raw_json_path.exists() else None,
        "claim_boundary": (
            "Radar records are external validation data only after their delay/Doppler observable models, "
            "transmitter/receiver geometry, time scales, and bounce-point semantics are implemented. "
            "Peak-power delay must not be silently treated as center-of-mass range."
        ),
    }


def write_radar_products(
    *,
    payload: dict[str, Any],
    paths: RadarPaths,
    target_id: str,
    spk_id: str | int,
    query_url: str,
) -> dict[str, Any]:
    paths.raw_json.parent.mkdir(parents=True, exist_ok=True)
    paths.normalized_csv.parent.mkdir(parents=True, exist_ok=True)
    paths.summary_json.parent.mkdir(parents=True, exist_ok=True)
    paths.report_md.parent.mkdir(parents=True, exist_ok=True)

    paths.raw_json.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    frame = payload_to_frame(payload)
    normalized = normalize_frame(frame)
    normalized.to_csv(paths.normalized_csv, index=False)
    dump_json(paths.coordinates_json, payload.get("coords") or {})
    summary = summarize_payload(
        payload=payload,
        frame=frame,
        target_id=target_id,
        spk_id=spk_id,
        query_url=query_url,
        raw_json_path=paths.raw_json,
    )
    dump_json(paths.summary_json, summary)

    lines = [
        f"# {target_id} JPL radar-astrometry acquisition audit",
        "",
        f"- Requested SPK-ID: `{spk_id}`",
        f"- API records: {summary['parsed_count']}",
        f"- Epoch range: {summary['epoch_min_utc']} to {summary['epoch_max_utc']}",
        f"- Delay records: {summary['delay_count']}",
        f"- Doppler records: {summary['doppler_count']}",
        f"- Center-of-mass records: {summary['center_of_mass_count']}",
        f"- Peak-power records: {summary['peak_power_count']}",
        f"- Acquisition/integrity gate: {summary['acquisition_gate_pass']}",
        f"- Direct center-of-mass fit ready: {summary['direct_center_of_mass_fit_ready']}",
        f"- Readiness classification: `{summary['fit_readiness']}`",
        "",
        "## Station pairs",
        "",
    ]
    for pair, n in summary["station_pair_counts"].items():
        lines.append(f"- `{pair}`: {n}")
    lines.extend(
        [
            "",
            "## Claim boundary",
            "",
            summary["claim_boundary"],
            "",
        ]
    )
    paths.report_md.write_text("\n".join(lines), encoding="utf-8")
    return summary
