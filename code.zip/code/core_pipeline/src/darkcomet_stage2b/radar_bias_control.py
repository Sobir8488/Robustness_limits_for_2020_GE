from __future__ import annotations

from typing import Any
import numpy as np


def bias_control_gate(summary: dict[str, Any], settings: dict[str, Any]) -> tuple[bool, dict[str, bool]]:
    force = summary.get('force_parameter_diagnostics', {})
    biases = summary.get('bias_parameter_diagnostics', {})
    a2_ratio = force.get('A2_abs_ratio_to_optical_baseline')
    optical_rms = float(summary.get('optical_postfit_rms_arcsec', float('nan')))
    range_bias = float(biases.get('range_bias_final_m', float('nan')))
    doppler_bias = float(biases.get('doppler_bias_final_m_s', float('nan')))
    holdout_hz = float(summary.get('holdout_postfit_abs_residual_hz', float('nan')))
    checks = {
        'runtime_success': bool(summary.get('runtime_success', False)),
        'observation_partition_gate_pass': bool(summary.get('observation_partition_gate_pass', False)),
        'all_final_residuals_finite': bool(summary.get('all_final_residuals_finite', False)),
        'total_nrms_nonincreasing': bool(summary.get('total_postfit_nrms_improved', False)),
        'fit_radar_nrms_improved': bool(summary.get('fit_radar_postfit_nrms_improved', False)),
        'optical_rms_within_gate': bool(np.isfinite(optical_rms) and optical_rms <= float(settings['max_optical_postfit_rms_arcsec'])),
        'range_bias_within_gate': bool(np.isfinite(range_bias) and abs(range_bias) <= float(settings['max_abs_range_bias_m'])),
        'doppler_bias_within_gate': bool(np.isfinite(doppler_bias) and abs(doppler_bias) <= float(settings['max_abs_doppler_bias_m_s'])),
        'A2_sign_consistent': bool(force.get('A2_sign_consistent_with_optical_baseline', False)),
        'A2_amplitude_within_gate': bool(
            a2_ratio is not None and np.isfinite(float(a2_ratio))
            and float(settings['min_abs_A2_ratio_to_optical_baseline']) <= float(a2_ratio) <= float(settings['max_abs_A2_ratio_to_optical_baseline'])
        ),
        'holdout_residual_within_coarse_gate': bool(np.isfinite(holdout_hz) and holdout_hz <= float(settings['holdout_abs_residual_limit_hz'])),
    }
    return bool(all(checks.values())), checks
