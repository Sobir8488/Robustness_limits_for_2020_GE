from __future__ import annotations

import math
from typing import Any

import numpy as np

C_M_S = 299_792_458.0
ARCSEC_PER_RAD = 206_264.80624709636


def vector_to_radec_deg(vector: np.ndarray) -> tuple[float, float]:
    vec = np.asarray(vector, dtype=float).reshape(-1)
    if vec.size != 3 or not np.isfinite(vec).all():
        raise ValueError("vector must contain three finite Cartesian components")
    radius = float(np.linalg.norm(vec))
    if radius <= 0.0:
        raise ValueError("vector norm must be positive")
    ra = math.degrees(math.atan2(float(vec[1]), float(vec[0]))) % 360.0
    dec = math.degrees(math.asin(max(-1.0, min(1.0, float(vec[2]) / radius))))
    return ra, dec


def wrapped_angle_difference_rad(left: np.ndarray | float, right: np.ndarray | float) -> np.ndarray:
    a = np.asarray(left, dtype=float)
    b = np.asarray(right, dtype=float)
    return (a - b + math.pi) % (2.0 * math.pi) - math.pi


def angular_separation_arcsec(vector_a: np.ndarray, vector_b: np.ndarray) -> float:
    a = np.asarray(vector_a, dtype=float).reshape(-1)
    b = np.asarray(vector_b, dtype=float).reshape(-1)
    if a.size != 3 or b.size != 3:
        raise ValueError("angular separation requires two 3-vectors")
    na = float(np.linalg.norm(a))
    nb = float(np.linalg.norm(b))
    if na <= 0.0 or nb <= 0.0:
        raise ValueError("vector norms must be positive")
    cosine = float(np.dot(a, b) / (na * nb))
    angle = math.acos(max(-1.0, min(1.0, cosine)))
    return angle * ARCSEC_PER_RAD


def observation_collection_roundtrip(batch: Any, observation_collection: Any) -> dict[str, Any]:
    values = np.asarray(observation_collection.concatenated_observations, dtype=float).reshape(-1)
    times = np.asarray(observation_collection.concatenated_times, dtype=float).reshape(-1)
    if values.size == 0 or values.size % 2 != 0 or times.size != values.size:
        raise RuntimeError(
            f"Unexpected concatenated observation shapes: values={values.shape}, times={times.shape}"
        )
    pairs = values.reshape(-1, 2)
    time_pairs = times.reshape(-1, 2)
    pair_time_mismatch = np.abs(time_pairs[:, 0] - time_pairs[:, 1])

    table = batch._table.copy()
    time_column = (
        "epochJ2000secondsTDB"
        if "epochJ2000secondsTDB" in table.columns
        else "epoch_seconds_TDB"
    )
    raw_times = np.asarray(table[time_column], dtype=float)
    raw_ra = np.asarray(table["RA"], dtype=float)
    raw_dec = np.asarray(table["DEC"], dtype=float)

    standard_errors: list[float] = []
    swapped_errors: list[float] = []
    nearest_time_errors: list[float] = []
    matched_indices: list[int] = []
    for epoch, pair in zip(time_pairs[:, 0], pairs):
        index = int(np.argmin(np.abs(raw_times - epoch)))
        nearest_time_errors.append(float(abs(raw_times[index] - epoch)))
        matched_indices.append(index)
        standard_ra = float(abs(wrapped_angle_difference_rad(pair[0], raw_ra[index])))
        standard_dec = float(abs(pair[1] - raw_dec[index]))
        swapped_first = float(abs(pair[0] - raw_dec[index]))
        swapped_second = float(abs(wrapped_angle_difference_rad(pair[1], raw_ra[index])))
        standard_errors.extend([standard_ra, standard_dec])
        swapped_errors.extend([swapped_first, swapped_second])

    standard = np.asarray(standard_errors, dtype=float) * ARCSEC_PER_RAD
    swapped = np.asarray(swapped_errors, dtype=float) * ARCSEC_PER_RAD
    unique_match_count = len(set(matched_indices))
    standard_max = float(np.max(standard))
    swapped_max = float(np.max(swapped))
    return {
        "n_vector_observations": int(pairs.shape[0]),
        "n_scalar_observations": int(values.size),
        "n_unique_raw_rows_matched": int(unique_match_count),
        "pair_epoch_internal_max_error_s": float(np.max(pair_time_mismatch)),
        "nearest_raw_epoch_max_error_s": float(np.max(nearest_time_errors)),
        "standard_RA_DEC_max_abs_error_arcsec": standard_max,
        "standard_RA_DEC_rms_error_arcsec": float(np.sqrt(np.mean(standard**2))),
        "swapped_DEC_RA_max_abs_error_arcsec": swapped_max,
        "swapped_DEC_RA_rms_error_arcsec": float(np.sqrt(np.mean(swapped**2))),
        "standard_order_preferred": bool(standard_max < swapped_max),
        "roundtrip_gate_pass": bool(
            unique_match_count == pairs.shape[0]
            and float(np.max(pair_time_mismatch)) <= 1.0e-6
            and float(np.max(nearest_time_errors)) <= 1.0e-3
            and standard_max <= 1.0e-3
        ),
    }
