from __future__ import annotations

import numpy as np
import pandas as pd

from .common import ARCSEC_TO_RAD


MANDATORY_ADES_COLUMNS = {
    "obstime", "ra", "dec", "stn", "provid", "band", "mode"
}


def utc_iso_to_jd(series: pd.Series) -> pd.Series:
    times = pd.to_datetime(series, utc=True, errors="raise")
    # Unix epoch JD is 2440587.5.
    return times.astype("int64") / 1.0e9 / 86400.0 + 2440587.5


def assign_temporal_clusters(obstime: pd.Series, gap_days: float = 120.0) -> pd.Series:
    times = pd.to_datetime(obstime, utc=True, errors="raise")
    order = np.argsort(times.values)
    sorted_times = times.iloc[order].reset_index(drop=True)
    cluster_sorted = np.zeros(len(times), dtype=int)
    cluster = 0
    for i in range(1, len(sorted_times)):
        delta_days = (sorted_times.iloc[i] - sorted_times.iloc[i - 1]).total_seconds() / 86400.0
        if delta_days > gap_days:
            cluster += 1
        cluster_sorted[i] = cluster
    clusters = np.empty(len(times), dtype=int)
    clusters[order] = cluster_sorted
    return pd.Series(clusters, index=obstime.index, dtype=int)


def build_sigma_arcsec(
    frame: pd.DataFrame,
    fallback_sigma_arcsec: float,
    minimum_sigma_arcsec: float,
    maximum_sigma_arcsec: float,
    same_night_threshold: int,
) -> pd.DataFrame:
    out = frame.copy()
    rms_ra = pd.to_numeric(out.get("rmsra"), errors="coerce")
    rms_dec = pd.to_numeric(out.get("rmsdec"), errors="coerce")
    both = rms_ra.notna() & rms_dec.notna() & (rms_ra > 0) & (rms_dec > 0)

    sigma = pd.Series(float(fallback_sigma_arcsec), index=out.index, dtype=float)
    sigma.loc[both] = np.sqrt((rms_ra.loc[both] ** 2 + rms_dec.loc[both] ** 2) / 2.0)
    sigma = sigma.clip(lower=float(minimum_sigma_arcsec), upper=float(maximum_sigma_arcsec))

    utc = pd.to_datetime(out["obstime"], utc=True, errors="raise")
    out["utc_night"] = utc.dt.strftime("%Y-%m-%d")
    group_size = out.groupby(["stn", "utc_night"])["stn"].transform("size").astype(int)
    deweight = np.sqrt(np.maximum(group_size / float(same_night_threshold), 1.0))
    sigma_deweighted = sigma * deweight

    out["sigma_base_arcsec"] = sigma
    out["same_night_group_size"] = group_size
    out["same_night_deweight_factor"] = deweight
    out["sigma_effective_arcsec"] = sigma_deweighted
    out["weight_per_coordinate_rad_inverse2"] = 1.0 / (sigma_deweighted * ARCSEC_TO_RAD) ** 2
    out["sigma_source"] = np.where(both, "ADES_RMS", "fallback")
    return out


def prepare_ades(
    raw: pd.DataFrame,
    target_id: str,
    fallback_sigma_arcsec: float,
    minimum_sigma_arcsec: float,
    maximum_sigma_arcsec: float,
    same_night_threshold: int,
    gap_days: float,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    missing = sorted(MANDATORY_ADES_COLUMNS - set(raw.columns))
    if missing:
        raise ValueError(f"Missing mandatory ADES columns: {missing}")

    frame = raw.copy()
    frame = frame.loc[frame["Obstype"].astype(str).str.lower().eq("optical")].copy()
    if frame.empty:
        raise ValueError(f"{target_id}: no optical observations after filtering")

    frame["target_id"] = target_id
    frame["epoch_jd_utc"] = utc_iso_to_jd(frame["obstime"])
    frame["cluster_id"] = assign_temporal_clusters(frame["obstime"], gap_days=gap_days)
    frame = build_sigma_arcsec(
        frame,
        fallback_sigma_arcsec=fallback_sigma_arcsec,
        minimum_sigma_arcsec=minimum_sigma_arcsec,
        maximum_sigma_arcsec=maximum_sigma_arcsec,
        same_night_threshold=same_night_threshold,
    )

    band = frame["band"].fillna("").astype(str)
    batch = pd.DataFrame(
        {
            "number": target_id,
            "epoch": frame["epoch_jd_utc"].astype(float),
            "RA": pd.to_numeric(frame["ra"], errors="raise").astype(float),
            "DEC": pd.to_numeric(frame["dec"], errors="raise").astype(float),
            "band": band,
            "observatory": frame["stn"].astype(str),
        }
    )
    return frame.reset_index(drop=True), batch.reset_index(drop=True)
