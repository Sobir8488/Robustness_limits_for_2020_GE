from __future__ import annotations

from typing import Any

import numpy as np
import pandas as pd


def _component_summary(
    frame: pd.DataFrame,
    *,
    model: str,
    baseline_sigma: float,
    required_sigmas: list[float],
    min_abs_ratio: float,
    max_abs_ratio: float,
    min_abs_z: float,
) -> dict[str, Any]:
    sub = frame.loc[frame["model"].eq(model)].copy()
    sub["fallback_sigma_arcsec"] = sub["fallback_sigma_arcsec"].astype(float)
    by_sigma = {float(r["fallback_sigma_arcsec"]): r for _, r in sub.iterrows()}
    missing = [float(s) for s in required_sigmas if float(s) not in by_sigma]
    baseline = by_sigma.get(float(baseline_sigma))
    baseline_value = float(baseline["A2_estimated_au_d2"]) if baseline is not None else np.nan

    rows: list[dict[str, Any]] = []
    for sigma in required_sigmas:
        row = by_sigma.get(float(sigma))
        if row is None:
            rows.append({"fallback_sigma_arcsec": float(sigma), "available": False})
            continue
        value = float(row.get("A2_estimated_au_d2", np.nan))
        ratio = value / baseline_value if np.isfinite(value) and np.isfinite(baseline_value) and baseline_value != 0 else np.nan
        sign_ok = bool(np.isfinite(value) and np.isfinite(baseline_value) and value * baseline_value > 0)
        z = float(row.get("A2_z_overdispersion_scaled", row.get("A2_z", np.nan)))
        rows.append({
            "fallback_sigma_arcsec": float(sigma),
            "available": True,
            "fit_valid": bool(row.get("fit_valid", False)),
            "model_comparison_eligible": bool(row.get("model_comparison_eligible", False)),
            "A2_estimated_au_d2": value,
            "A2_sigma_overdispersion_scaled_au_d2": float(row.get("A2_sigma_overdispersion_scaled_au_d2", np.nan)),
            "A2_z": z,
            "A2_physically_plausible": bool(row.get("A2_physically_plausible", False)),
            "A2_ratio_to_baseline": ratio,
            "A2_sign_consistent_with_baseline": sign_ok,
            "bic": float(row.get("bic", np.nan)),
            "profile_scale_bic": float(row.get("profile_scale_bic", np.nan)),
            "rms_residual_arcsec": float(row.get("rms_residual_arcsec", np.nan)),
            "reduced_chi2": float(row.get("reduced_chi2", np.nan)),
        })

    available_rows = [r for r in rows if r.get("available")]
    ratios = [abs(float(r["A2_ratio_to_baseline"])) for r in available_rows if np.isfinite(r.get("A2_ratio_to_baseline", np.nan))]
    z_values = [abs(float(r["A2_z"])) for r in available_rows if np.isfinite(r.get("A2_z", np.nan))]
    all_available = not missing and len(available_rows) == len(required_sigmas)
    all_valid = all_available and all(bool(r["fit_valid"]) for r in available_rows)
    all_eligible = all_available and all(bool(r["model_comparison_eligible"]) for r in available_rows)
    sign_gate = all_available and all(bool(r["A2_sign_consistent_with_baseline"]) for r in available_rows)
    amplitude_gate = bool(
        all_available and ratios and min(ratios) >= float(min_abs_ratio) and max(ratios) <= float(max_abs_ratio)
    )
    significance_gate = bool(all_available and z_values and min(z_values) >= float(min_abs_z))
    plausibility_gate = all_available and all(bool(r["A2_physically_plausible"]) for r in available_rows)

    return {
        "model": model,
        "required_sigmas_arcsec": [float(s) for s in required_sigmas],
        "missing_sigmas_arcsec": missing,
        "baseline_sigma_arcsec": float(baseline_sigma),
        "baseline_A2_au_d2": baseline_value,
        "all_results_available": all_available,
        "all_fits_valid": all_valid,
        "all_model_comparison_eligible": all_eligible,
        "all_A2_sign_consistent_with_baseline": sign_gate,
        "min_abs_A2_ratio_to_baseline": min(ratios) if ratios else None,
        "max_abs_A2_ratio_to_baseline": max(ratios) if ratios else None,
        "max_fractional_A2_deviation_from_baseline": max((abs(r - 1.0) for r in ratios), default=None),
        "A2_amplitude_gate_pass": amplitude_gate,
        "min_abs_A2_z": min(z_values) if z_values else None,
        "A2_significance_gate_pass": significance_gate,
        "all_A2_physically_plausible": plausibility_gate,
        "A2_weight_sensitivity_gate_pass": bool(
            all_valid and all_eligible and sign_gate and amplitude_gate and significance_gate and plausibility_gate
        ),
        "rows": rows,
    }


def build_weight_sensitivity_summary(
    frame: pd.DataFrame,
    *,
    target_id: str,
    required_sigmas: list[float],
    baseline_sigma: float,
    min_abs_ratio: float,
    max_abs_ratio: float,
    min_abs_z: float,
    min_delta_bic: float,
    min_delta_profile_bic: float,
) -> dict[str, Any]:
    if frame.empty:
        raise ValueError("No weight-sensitivity model summaries were supplied")

    sub = frame.loc[frame["target_id"].eq(target_id) & frame["model"].isin(["M_SY", "M_Y"])].copy()
    model_claims = {
        model: _component_summary(
            sub,
            model=model,
            baseline_sigma=baseline_sigma,
            required_sigmas=required_sigmas,
            min_abs_ratio=min_abs_ratio,
            max_abs_ratio=max_abs_ratio,
            min_abs_z=min_abs_z,
        )
        for model in ("M_SY", "M_Y")
    }

    ordering_rows: list[dict[str, Any]] = []
    for sigma in required_sigmas:
        s = sub.loc[np.isclose(sub["fallback_sigma_arcsec"].astype(float), float(sigma))]
        sy = s.loc[s["model"].eq("M_SY")]
        y = s.loc[s["model"].eq("M_Y")]
        if len(sy) != 1 or len(y) != 1:
            ordering_rows.append({"fallback_sigma_arcsec": float(sigma), "available": False})
            continue
        sy_row = sy.iloc[0]
        y_row = y.iloc[0]
        delta_bic = float(y_row["bic"] - sy_row["bic"])
        delta_profile = float(y_row["profile_scale_bic"] - sy_row["profile_scale_bic"])
        both_valid = bool(sy_row.get("fit_valid", False) and y_row.get("fit_valid", False))
        both_eligible = bool(
            sy_row.get("model_comparison_eligible", False) and y_row.get("model_comparison_eligible", False)
        )
        ordering_rows.append({
            "fallback_sigma_arcsec": float(sigma),
            "available": True,
            "both_fits_valid": both_valid,
            "both_model_comparison_eligible": both_eligible,
            "delta_bic_M_Y_minus_M_SY": delta_bic,
            "delta_profile_bic_M_Y_minus_M_SY": delta_profile,
            "M_SY_preferred_by_BIC": bool(delta_bic > 0),
            "M_SY_strongly_preferred_by_BIC": bool(delta_bic >= float(min_delta_bic)),
            "M_SY_preferred_by_profile_BIC": bool(delta_profile > 0),
            "M_SY_strongly_preferred_by_profile_BIC": bool(delta_profile >= float(min_delta_profile_bic)),
        })

    ordering_available = all(r.get("available") for r in ordering_rows)
    ordering_gate = bool(
        ordering_available
        and all(r["both_fits_valid"] for r in ordering_rows)
        and all(r["both_model_comparison_eligible"] for r in ordering_rows)
        and all(r["M_SY_strongly_preferred_by_BIC"] for r in ordering_rows)
        and all(r["M_SY_strongly_preferred_by_profile_BIC"] for r in ordering_rows)
    )

    overall = bool(
        model_claims["M_SY"]["A2_weight_sensitivity_gate_pass"]
        and model_claims["M_Y"]["A2_weight_sensitivity_gate_pass"]
        and ordering_gate
    )

    return {
        "target_id": target_id,
        "required_sigmas_arcsec": [float(s) for s in required_sigmas],
        "baseline_sigma_arcsec": float(baseline_sigma),
        "gates": {
            "min_abs_A2_ratio_to_baseline": float(min_abs_ratio),
            "max_abs_A2_ratio_to_baseline": float(max_abs_ratio),
            "min_abs_A2_z": float(min_abs_z),
            "min_delta_bic_M_Y_minus_M_SY": float(min_delta_bic),
            "min_delta_profile_bic_M_Y_minus_M_SY": float(min_delta_profile_bic),
        },
        "model_claims": model_claims,
        "ordering_rows": ordering_rows,
        "model_ordering_gate_pass": ordering_gate,
        "weight_sensitivity_gate_pass": overall,
        "claim_boundary": (
            "This gate tests robustness to the fallback astrometric sigma only. It does not replace temporal LOO, "
            "radar, or independent-software validation."
        ),
    }
