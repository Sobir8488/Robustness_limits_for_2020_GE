from __future__ import annotations
from typing import Any
import math
import numpy as np


def exact_horizons_query_id(target_cfg: dict[str, Any]) -> str:
    spkid = str(target_cfg.get("jpl_spkid", "")).strip()
    if not spkid.isdigit():
        raise ValueError(f"Missing or invalid exact JPL SPK-ID: {spkid!r}")
    return spkid


def _make_query(horizons_query_class: Any, target_id: str, target_cfg: dict[str, Any], location: str, epoch_list: list[float]) -> Any:
    # JPL treats SPK IDs as designations.  Explicit designation mode prevents
    # accidental major-body/general-name resolution.
    return horizons_query_class(
        query_id=exact_horizons_query_id(target_cfg),
        query_type="designation",
        location=location,
        epoch_list=[float(x) for x in epoch_list],
        extended_query=True,
    )


def query_cartesian_state(
    horizons_query_class: Any,
    *,
    target_id: str,
    target_cfg: dict[str, Any],
    location: str,
    epoch: float,
    frame_orientation: str,
) -> tuple[np.ndarray, dict[str, Any]]:
    query_id = exact_horizons_query_id(target_cfg)
    query = _make_query(horizons_query_class, target_id, target_cfg, location, [float(epoch)])
    cartesian = np.asarray(query.cartesian(frame_orientation=frame_orientation), dtype=float)
    if cartesian.ndim != 2 or cartesian.shape[0] < 1 or cartesian.shape[1] != 7:
        raise RuntimeError(f"Horizons returned an invalid Cartesian array for {target_id} / SPK-ID {query_id}")
    returned_epoch = float(cartesian[0, 0])
    state = np.asarray(cartesian[0, 1:], dtype=float)
    if state.shape != (6,) or not np.isfinite(state).all():
        raise RuntimeError(f"Horizons returned an invalid state for {target_id} / SPK-ID {query_id}")
    designation = getattr(query, "designation", None)
    return state, {
        "target_id": target_id,
        "requested_jpl_spkid": query_id,
        "query_id": query_id,
        "query_type": "designation",
        "identity_mode": "exact_spkid_designation",
        "returned_designation": designation,
        "returned_name": getattr(query, "name", None),
        "returned_mpc_number": getattr(query, "MPC_number", None),
        "location": location,
        "epoch_tdb_s_j2000": float(epoch),
        "returned_epoch_tdb_s_j2000": returned_epoch,
        "epoch_roundtrip_error_s": float(returned_epoch - float(epoch)),
        "state_finite": True,
        "state_position_norm_m": float(np.linalg.norm(state[:3])),
        "state_velocity_norm_m_s": float(np.linalg.norm(state[3:])),
    }


def angular_separation_deg(ra1_deg: float, dec1_deg: float, ra2_deg: float, dec2_deg: float) -> float:
    ra1, dec1, ra2, dec2 = map(math.radians, (ra1_deg, dec1_deg, ra2_deg, dec2_deg))
    cosine = math.sin(dec1) * math.sin(dec2) + math.cos(dec1) * math.cos(dec2) * math.cos(ra1 - ra2)
    return math.degrees(math.acos(max(-1.0, min(1.0, cosine))))


def query_first_epoch_sky_check(
    horizons_query_class: Any,
    *,
    target_id: str,
    target_cfg: dict[str, Any],
    station_code: str,
    epoch: float,
    observed_ra_deg: float,
    observed_dec_deg: float,
) -> dict[str, Any]:
    query = _make_query(
        horizons_query_class,
        target_id,
        target_cfg,
        str(station_code),
        [float(epoch)],
    )
    predicted = np.asarray(
        query.interpolated_observations(
            degrees=True,
            reference_system="J2000",
            extra_precision=True,
        ),
        dtype=float,
    )
    if predicted.ndim != 2 or predicted.shape[0] < 1 or predicted.shape[1] < 3:
        raise RuntimeError(f"Horizons observer-angle query returned an invalid array for {target_id}")
    pred_ra = float(predicted[0, 1])
    pred_dec = float(predicted[0, 2])
    return {
        "station_code": str(station_code),
        "epoch_tdb_s_j2000": float(epoch),
        "observed_ra_deg": float(observed_ra_deg),
        "observed_dec_deg": float(observed_dec_deg),
        "horizons_ra_deg": pred_ra,
        "horizons_dec_deg": pred_dec,
        "angular_separation_deg": angular_separation_deg(
            observed_ra_deg,
            observed_dec_deg,
            pred_ra,
            pred_dec,
        ),
    }


def query_anchored_cartesian_state(
    horizons_query_class: Any,
    *,
    bodies: Any,
    target_id: str,
    target_cfg: dict[str, Any],
    epoch: float,
    frame_origin: str,
    frame_orientation: str,
    anchor_mode: str,
) -> tuple[np.ndarray, dict[str, Any]]:
    """Build a target state consistent with the active Tudat body ephemerides.

    ``direct_ssb`` uses a canonical Horizons SSB centre (``@0``).
    ``earth_rebased`` and ``sun_rebased`` query a target-relative state from
    Horizons, then add the corresponding Tudat body state expressed in the
    configured global frame.  Re-basing is useful for close NEOs, for which a
    small mismatch between external and runtime planetary ephemerides can map
    into a large sky-plane offset.
    """
    if str(frame_origin).upper() != "SSB":
        raise ValueError("The frozen Stage 2B anchor ladder currently requires global_frame_origin=SSB")
    modes = {
        "direct_ssb": ("@0", None),
        "earth_rebased": ("@399", "Earth"),
        "sun_rebased": ("@10", "Sun"),
    }
    if anchor_mode not in modes:
        raise ValueError(f"Unknown initial-state anchor mode: {anchor_mode!r}")
    location, anchor_body = modes[anchor_mode]
    relative_state, horizons_meta = query_cartesian_state(
        horizons_query_class,
        target_id=target_id,
        target_cfg=target_cfg,
        location=location,
        epoch=epoch,
        frame_orientation=frame_orientation,
    )
    if anchor_body is None:
        anchor_state = np.zeros(6, dtype=float)
        combined_state = relative_state.copy()
    else:
        anchor_state = np.asarray(
            bodies.get(anchor_body).ephemeris.cartesian_state(float(epoch)),
            dtype=float,
        ).reshape(-1)
        if anchor_state.shape != (6,) or not np.isfinite(anchor_state).all():
            raise RuntimeError(f"Invalid Tudat {anchor_body} anchor state at epoch {epoch}")
        combined_state = anchor_state + relative_state
    meta = {
        **horizons_meta,
        "initial_state_anchor_mode": anchor_mode,
        "anchor_body": anchor_body,
        "horizons_relative_location": location,
        "relative_state_position_norm_m": float(np.linalg.norm(relative_state[:3])),
        "relative_state_velocity_norm_m_s": float(np.linalg.norm(relative_state[3:])),
        "anchor_state_position_norm_m": float(np.linalg.norm(anchor_state[:3])),
        "anchor_state_velocity_norm_m_s": float(np.linalg.norm(anchor_state[3:])),
        "combined_state_position_norm_m": float(np.linalg.norm(combined_state[:3])),
        "combined_state_velocity_norm_m_s": float(np.linalg.norm(combined_state[3:])),
        "runtime_ephemeris_rebased": bool(anchor_body is not None),
    }
    return combined_state, meta
