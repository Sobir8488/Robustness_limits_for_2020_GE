from __future__ import annotations

from typing import Any

import numpy as np


def homotopy_stage_gate(summary: dict[str, Any], settings: dict[str, Any]) -> tuple[bool, dict[str, bool]]:
    update = summary.get("parameter_update", {})
    force = summary.get("force_parameter_diagnostics", {})
    optical_rms = float(summary.get("optical_postfit_rms_arcsec", float("nan")))
    position_update = float(update.get("state_position_update_norm_m", float("nan")))
    velocity_update = float(update.get("state_velocity_update_norm_m_s", float("nan")))
    a2_ratio = force.get("A2_abs_ratio_to_optical_baseline")

    checks = {
        "joint_preflight_gate_pass": bool(summary.get("joint_preflight_gate_pass", False)),
        "total_nrms_nonincreasing": bool(summary.get("total_postfit_nrms_improved", False)),
        "optical_rms_within_gate": bool(
            np.isfinite(optical_rms)
            and optical_rms <= float(settings["max_optical_postfit_rms_arcsec"])
        ),
        "position_increment_within_gate": bool(
            np.isfinite(position_update)
            and position_update <= float(settings["max_stage_position_update_m"])
        ),
        "velocity_increment_within_gate": bool(
            np.isfinite(velocity_update)
            and velocity_update <= float(settings["max_stage_velocity_update_m_s"])
        ),
        "A2_sign_consistent": bool(force.get("A2_sign_consistent_with_optical_baseline", False)),
        "A2_amplitude_within_gate": bool(
            a2_ratio is not None
            and np.isfinite(float(a2_ratio))
            and float(settings["min_abs_A2_ratio_to_optical_baseline"])
            <= float(a2_ratio)
            <= float(settings["max_abs_A2_ratio_to_optical_baseline"])
        ),
    }
    return bool(all(checks.values())), checks


def compact_stage_row(summary: dict[str, Any], *, reused_seed: bool = False) -> dict[str, Any]:
    update = summary.get("parameter_update", {})
    force = summary.get("force_parameter_diagnostics", {})
    return {
        "model": summary.get("model"),
        "radar_sigma_multiplier": summary.get("radar_sigma_multiplier"),
        "maximum_iterations": summary.get("maximum_iterations"),
        "warm_start_source": summary.get("warm_start_source"),
        "reused_seed": bool(reused_seed),
        "runtime_success": summary.get("runtime_success"),
        "joint_preflight_gate_pass": summary.get("joint_preflight_gate_pass"),
        "homotopy_stage_gate_pass": summary.get("homotopy_stage_gate_pass"),
        "total_prefit_nrms": summary.get("total_prefit_nrms"),
        "total_postfit_nrms": summary.get("total_postfit_nrms"),
        "radar_prefit_nrms": summary.get("radar_prefit_nrms"),
        "radar_postfit_nrms": summary.get("radar_postfit_nrms"),
        "optical_postfit_rms_arcsec": summary.get("optical_postfit_rms_arcsec"),
        "state_position_update_norm_m": update.get("state_position_update_norm_m"),
        "state_velocity_update_norm_m_s": update.get("state_velocity_update_norm_m_s"),
        "A2_final_m_s2": force.get("A2_final_m_s2"),
        "A2_abs_ratio_to_optical_baseline": force.get("A2_abs_ratio_to_optical_baseline"),
        "A2_sign_consistent_with_optical_baseline": force.get("A2_sign_consistent_with_optical_baseline"),
        "srp_scale_final": force.get("srp_scale_final"),
    }
