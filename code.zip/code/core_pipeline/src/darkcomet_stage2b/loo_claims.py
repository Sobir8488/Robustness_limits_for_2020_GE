from __future__ import annotations

from typing import Any
import numpy as np
import pandas as pd

COMPONENT_SPECS = {
    "A1": {
        "value_col": "A1_equivalent_au_d2",
        "sign_col": "A1_loo_sign_consistent_with_full",
        "ratio_col": "A1_ratio_to_full",
        "z_col": "srp_parallel_scale_z",
        "plausible_col": "srp_parallel_scale_physically_plausible",
    },
    "A2": {
        "value_col": "A2_estimated_au_d2",
        "sign_col": "A2_loo_sign_consistent_with_full",
        "ratio_col": "A2_ratio_to_full",
        "z_col": "A2_z",
        "plausible_col": "A2_physically_plausible",
    },
}

REQUIRED_COMPONENTS = {
    "M_SRP": ["A1"],
    "M_Y": ["A2"],
    "M_SY": ["A1", "A2"],
}


def evaluate_component_gate(
    success: pd.DataFrame,
    component: str,
    full_value: float | None,
    *,
    all_fits_success: bool,
    all_successful_fits_valid: bool,
    min_abs_z_gate: float,
    max_abs_ratio_gate: float,
) -> dict[str, Any]:
    spec = COMPONENT_SPECS[component]
    available = bool(
        full_value is not None
        and len(success)
        and spec["sign_col"] in success.columns
        and spec["ratio_col"] in success.columns
        and spec["z_col"] in success.columns
    )
    if not available:
        return {
            "component": component,
            "available": False,
            "full_sample_value": full_value,
            "all_sign_consistent_with_full": False,
            "min_abs_z_successful": None,
            "max_abs_ratio_to_full": None,
            "all_successful_physically_plausible": None,
            "claim_gate_pass": False,
        }

    sign_ok = bool(success[spec["sign_col"]].fillna(False).all())
    z_values = pd.to_numeric(success[spec["z_col"]], errors="coerce").abs()
    ratio_values = pd.to_numeric(success[spec["ratio_col"]], errors="coerce").abs()
    min_abs_z = float(z_values.min()) if z_values.notna().all() else None
    max_abs_ratio = float(ratio_values.max()) if ratio_values.notna().all() else None

    plausible = None
    if spec["plausible_col"] in success.columns:
        plausible = bool(success[spec["plausible_col"]].fillna(False).all())

    gate = bool(
        all_fits_success
        and all_successful_fits_valid
        and sign_ok
        and min_abs_z is not None
        and min_abs_z >= min_abs_z_gate
        and max_abs_ratio is not None
        and max_abs_ratio <= max_abs_ratio_gate
        and plausible is not False
    )
    return {
        "component": component,
        "available": True,
        "full_sample_value": float(full_value),
        "all_sign_consistent_with_full": sign_ok,
        "min_abs_z_successful": min_abs_z,
        "max_abs_ratio_to_full": max_abs_ratio,
        "all_successful_physically_plausible": plausible,
        "claim_gate_pass": gate,
    }


def build_loo_claim_summary(
    frame: pd.DataFrame,
    *,
    model: str,
    full_a1: float | None,
    full_a2: float | None,
    min_abs_z_gate: float,
    max_abs_ratio_gate: float,
) -> dict[str, Any]:
    success = frame[frame["loo_status"] == "success"]
    all_fits_success = bool(len(success) == len(frame) and len(frame) > 0)
    all_successful_fits_valid = bool(success["fit_valid"].fillna(False).all()) if len(success) else False

    components = {
        "A1": evaluate_component_gate(
            success,
            "A1",
            full_a1,
            all_fits_success=all_fits_success,
            all_successful_fits_valid=all_successful_fits_valid,
            min_abs_z_gate=min_abs_z_gate,
            max_abs_ratio_gate=max_abs_ratio_gate,
        ),
        "A2": evaluate_component_gate(
            success,
            "A2",
            full_a2,
            all_fits_success=all_fits_success,
            all_successful_fits_valid=all_successful_fits_valid,
            min_abs_z_gate=min_abs_z_gate,
            max_abs_ratio_gate=max_abs_ratio_gate,
        ),
    }
    required = REQUIRED_COMPONENTS[model]
    required_claims = [components[name] for name in required]
    joint_pass = bool(required_claims and all(item["claim_gate_pass"] for item in required_claims))
    sign_consistent = bool(required_claims and all(item["all_sign_consistent_with_full"] for item in required_claims))
    mins = [item["min_abs_z_successful"] for item in required_claims if item["min_abs_z_successful"] is not None]
    ratios = [item["max_abs_ratio_to_full"] for item in required_claims if item["max_abs_ratio_to_full"] is not None]

    return {
        "n_clusters": int(len(frame)),
        "n_success": int(len(success)),
        "n_failed": int((frame["loo_status"] != "success").sum()),
        "all_fits_success": all_fits_success,
        "all_successful_fits_valid": all_successful_fits_valid,
        "required_components": required,
        "component_claims": components,
        "A1_claim_gate_pass": bool(components["A1"]["claim_gate_pass"]),
        "A2_claim_gate_pass": bool(components["A2"]["claim_gate_pass"]),
        "joint_component_claim_gate_pass": joint_pass,
        # Backward-compatible fields now represent all required components, not A2 alone.
        "sign_consistent_with_full": sign_consistent,
        "min_abs_z_successful": float(min(mins)) if mins else None,
        "max_abs_ratio_to_full": float(max(ratios)) if ratios else None,
        "max_abs_ratio_gate": float(max_abs_ratio_gate),
        "claim_gate_pass": joint_pass,
        "note": (
            "Component gates are evaluated separately. For M_SY, claim_gate_pass requires both A1 and A2 "
            "to pass all-fit, validity, sign, significance, amplitude-stability, and physical-plausibility gates."
        ),
    }
