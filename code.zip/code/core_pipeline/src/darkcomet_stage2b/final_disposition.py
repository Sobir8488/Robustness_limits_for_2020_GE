from __future__ import annotations

from typing import Any


def _bool(mapping: dict[str, Any] | None, key: str) -> bool:
    return bool((mapping or {}).get(key, False))


def build_final_disposition(
    *,
    protocol_version: str,
    ge_loo: dict[str, Any],
    weight_sensitivity: dict[str, Any],
    radar_acquisition: dict[str, Any],
    radar_conversion: dict[str, Any],
    radar_prediction: dict[str, Any],
    radar_identifiability: dict[str, Any],
    homotopy: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Build the publication-safe Stage 2B disposition for 2020 GE.

    Full-sample optical information-criterion preference and transport-valid
    physical interpretation are intentionally stored as separate fields.
    """
    model_results = radar_identifiability.get("model_results", {})
    msy = model_results.get("M_SY", {})
    my = model_results.get("M_Y", {})

    a2_loo = _bool(ge_loo, "A2_claim_gate_pass")
    a1_loo = _bool(ge_loo, "A1_claim_gate_pass")
    ws_models = weight_sensitivity.get("model_claims", {})
    a2_weight = (
        _bool(weight_sensitivity, "weight_sensitivity_gate_pass")
        and _bool(ws_models.get("M_SY", {}), "A2_weight_sensitivity_gate_pass")
        and _bool(ws_models.get("M_Y", {}), "A2_weight_sensitivity_gate_pass")
    )
    radar_integrity = (
        _bool(radar_acquisition, "acquisition_gate_pass")
        and _bool(radar_conversion, "conversion_gate_pass")
        and _bool(radar_prediction, "all_coarse_closure_gates_pass")
    )
    identifiability_complete = (
        _bool(radar_identifiability, "all_runs_success")
        and radar_identifiability.get("transport_preferred_model") == "M_Y"
        and radar_identifiability.get("A2_external_status")
        == "stable_under_bias_control_but_not_independently_confirmed"
        and msy.get("dynamic_increment_status")
        == "dynamic_increment_in_sample_only_not_transport_validated"
        and my.get("dynamic_increment_status")
        == "nuisance_only_sufficient_at_current_weight"
    )

    formal_weight_reached = bool((homotopy or {}).get("all_models_reached_formal_weight", False))
    joint_radar_ready = bool(radar_identifiability.get("publication_joint_radar_claim_ready", False))

    required_artifact_gate = bool(
        a2_loo
        and not a1_loo
        and a2_weight
        and radar_integrity
        and identifiability_complete
        and not joint_radar_ready
    )

    return {
        "target_id": "2020 GE",
        "protocol_version": protocol_version,
        "finalization_gate_pass": required_artifact_gate,
        "optical_full_sample_descriptive_model": "M_SY",
        "publication_transport_baseline_model": "M_Y",
        "secondary_descriptive_model": "M_SY",
        "A2": {
            "temporal_loo_gate_pass": a2_loo,
            "fallback_weight_gate_pass": a2_weight,
            "radar_integrity_and_coarse_consistency_pass": radar_integrity,
            "bias_control_status": radar_identifiability.get("A2_external_status"),
            "M_SY_ratio_to_optical_baseline": msy.get("A2_abs_ratio_to_optical_baseline"),
            "M_Y_ratio_to_optical_baseline": my.get("A2_abs_ratio_to_optical_baseline"),
            "independent_radar_confirmation": False,
            "publication_status": (
                "secure_optical_detection_with_radar_compatibility_not_independent_radar_confirmation"
                if required_artifact_gate
                else "incomplete_finalization"
            ),
        },
        "A1": {
            "temporal_loo_gate_pass": a1_loo,
            "radar_identifiability_status": radar_identifiability.get("A1_external_support_status"),
            "dynamic_increment_status": msy.get("dynamic_increment_status"),
            "holdout_transport_supported": bool(msy.get("dynamic_bias_holdout_residual_improved", False)),
            "srp_scale_final_soft_weight_control": msy.get("srp_scale_final"),
            "publication_status": (
                "not_secure_cluster_sensitive_and_not_holdout_transport_validated"
                if not a1_loo and not bool(msy.get("dynamic_bias_holdout_residual_improved", False))
                else "incomplete_finalization"
            ),
        },
        "radar_joint_solution": {
            "formal_weight_stage_reached": formal_weight_reached,
            "publication_claim_ready": joint_radar_ready,
            "status": "diagnostic_only_not_publication_grade",
        },
        "transport_diagnostics": {
            "preferred_model": radar_identifiability.get("transport_preferred_model"),
            "M_SY_dynamic_increment_fractional_radar_nrms_gain": msy.get(
                "dynamic_increment_fractional_radar_nrms_gain"
            ),
            "M_Y_dynamic_increment_fractional_radar_nrms_gain": my.get(
                "dynamic_increment_fractional_radar_nrms_gain"
            ),
            "M_SY_holdout_postfit_abs_residual_hz": msy.get(
                "dynamic_bias_holdout_postfit_abs_residual_hz"
            ),
            "M_Y_holdout_postfit_abs_residual_hz": my.get(
                "dynamic_bias_holdout_postfit_abs_residual_hz"
            ),
        },
        "publication_safe_claims": {
            "A2": (
                "The optical astrometry of 2020 GE supports a transverse A2 term whose sign and order of magnitude "
                "survive all temporal-cluster exclusions and the frozen fallback-weight audit. Radar acquisition, "
                "observable conversion, coarse prediction, and nuisance-control tests are compatible with this "
                "optical result, but the available radar data do not provide an independent publication-grade "
                "confirmation of A2."
            ),
            "A1": (
                "The radial/SRP-like component improves the full-sample optical M_SY fit but fails its component-specific "
                "temporal leave-one-cluster-out gate. Its additional Goldstone in-sample gain does not improve the "
                "independent Canberra-ATCA holdout, so it is retained only as cluster-sensitive descriptive structure "
                "and not as a secure radial detection."
            ),
            "model_baseline": (
                "M_SY remains the descriptive full-sample optical fit, whereas M_Y is the publication transport baseline "
                "for physical interpretation because its A2 solution is stable under nuisance control and requires no "
                "transport-unsupported radial component."
            ),
        },
        "claim_boundary": (
            "This disposition separates full-sample optical information-criterion preference from transport-valid "
            "physical inference. The radar analyses remain diagnostic because the formal-weight homotopy did not reach "
            "a publication-grade joint solution and the single independent holdout was not improved."
        ),
    }
