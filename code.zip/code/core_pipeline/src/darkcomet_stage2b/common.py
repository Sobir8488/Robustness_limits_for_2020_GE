from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path
from typing import Any

import yaml

AU_M = 149_597_870_700.0
DAY_S = 86_400.0
ARCSEC_TO_RAD = 3.141592653589793 / (180.0 * 3600.0)
SOLAR_IRRADIANCE_W_M2 = 1361.0
SPEED_OF_LIGHT_M_S = 299_792_458.0
SOLAR_PRESSURE_1AU_N_M2 = SOLAR_IRRADIANCE_W_M2 / SPEED_OF_LIGHT_M_S


def project_root() -> Path:
    return Path(__file__).resolve().parents[2]


def load_config() -> dict[str, Any]:
    path = project_root() / "config" / "stage2b.yaml"
    with path.open("r", encoding="utf-8") as handle:
        return yaml.safe_load(handle)


def ensure_directories(cfg: dict[str, Any]) -> None:
    root = project_root()
    for key in (
        "processed_directory",
        "tables_directory",
        "reports_directory",
        "models_directory",
        "residuals_directory",
        "loo_directory",
        "radar_directory",
    ):
        (root / cfg["paths"][key]).mkdir(parents=True, exist_ok=True)


def safe_slug(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9]+", "_", value).strip("_")


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def dump_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, default=str), encoding="utf-8")


def au_d2_to_m_s2(value: float) -> float:
    return float(value) * AU_M / (DAY_S * DAY_S)


def m_s2_to_au_d2(value: float) -> float:
    return float(value) * (DAY_S * DAY_S) / AU_M
