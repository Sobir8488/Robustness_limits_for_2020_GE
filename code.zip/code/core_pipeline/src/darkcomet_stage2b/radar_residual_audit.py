from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

import numpy as np
import pandas as pd

SPEED_OF_LIGHT_M_S = 299_792_458.0


@dataclass(frozen=True)
class BiasProfile:
    measurement_type: str
    n: int
    weighted_bias_native: float
    raw_chi2: float
    profiled_chi2: float
    informative: bool

    def to_dict(self) -> dict:
        return {
            "measurement_type": self.measurement_type,
            "n": self.n,
            "weighted_bias_native": self.weighted_bias_native,
            "raw_chi2": self.raw_chi2,
            "profiled_chi2": self.profiled_chi2,
            "informative": self.informative,
        }


def _as_float_array(values: Iterable[float]) -> np.ndarray:
    arr = np.asarray(list(values), dtype=float)
    if arr.ndim != 1:
        raise ValueError("Expected a one-dimensional array")
    if not np.isfinite(arr).all():
        raise ValueError("Non-finite values encountered")
    return arr


def weighted_bias_profile(
    residual_native: Iterable[float], sigma_native: Iterable[float], measurement_type: str
) -> BiasProfile:
    residual = _as_float_array(residual_native)
    sigma = _as_float_array(sigma_native)
    if residual.size != sigma.size:
        raise ValueError("Residual and sigma arrays must have the same size")
    if residual.size == 0:
        raise ValueError("Cannot profile an empty group")
    if np.any(sigma <= 0.0):
        raise ValueError("All sigma values must be positive")
    weight = 1.0 / np.square(sigma)
    bias = float(np.sum(weight * residual) / np.sum(weight))
    raw_chi2 = float(np.sum(np.square(residual / sigma)))
    profiled = residual - bias
    profiled_chi2 = float(np.sum(np.square(profiled / sigma)))
    return BiasProfile(
        measurement_type=str(measurement_type),
        n=int(residual.size),
        weighted_bias_native=bias,
        raw_chi2=raw_chi2,
        profiled_chi2=profiled_chi2,
        informative=bool(residual.size >= 2),
    )


def validate_prediction_frame(frame: pd.DataFrame) -> None:
    required = {
        "epoch_utc",
        "measurement_type",
        "value",
        "sigma",
        "freq",
        "station_pair",
        "residual_native_observed_minus_predicted",
        "normalized_residual",
    }
    missing = sorted(required - set(frame.columns))
    if missing:
        raise ValueError(f"Missing radar prediction columns: {missing}")
    if frame.empty:
        raise ValueError("Radar prediction frame is empty")
    if not np.isfinite(frame["sigma"].to_numpy(float)).all():
        raise ValueError("Non-finite radar sigma values")
    if np.any(frame["sigma"].to_numpy(float) <= 0.0):
        raise ValueError("Radar sigma values must be positive")
    allowed = {"delay", "doppler"}
    kinds = set(frame["measurement_type"].astype(str).str.lower())
    if not kinds.issubset(allowed):
        raise ValueError(f"Unsupported measurement types: {sorted(kinds - allowed)}")


def _linear_trend_per_day(group: pd.DataFrame) -> float | None:
    if len(group) < 2:
        return None
    epoch = pd.to_datetime(group["epoch_utc"], utc=True, errors="raise")
    x = (epoch - epoch.min()).dt.total_seconds().to_numpy(float) / 86400.0
    y = group["residual_native_observed_minus_predicted"].to_numpy(float)
    if np.allclose(x, x[0]):
        return None
    slope = np.polyfit(x, y, deg=1)[0]
    return float(slope)


def summarize_model_prediction(
    frame: pd.DataFrame,
    *,
    model: str,
    formal_nrms_limit: float = 5.0,
    profile_nrms_limit: float = 5.0,
    coarse_gate_pass: bool | None = None,
    doppler_sign_gate_pass: bool | None = None,
) -> dict:
    validate_prediction_frame(frame)
    work = frame.copy()
    work["measurement_type"] = work["measurement_type"].astype(str).str.lower()
    residual = work["residual_native_observed_minus_predicted"].to_numpy(float)
    sigma = work["sigma"].to_numpy(float)
    raw_chi2 = float(np.sum(np.square(residual / sigma)))
    raw_nrms = float(np.sqrt(np.mean(np.square(residual / sigma))))

    type_profiles: dict[str, dict] = {}
    profiled_chi2 = 0.0
    profiled_dof = int(len(work))
    for kind in ("delay", "doppler"):
        subset = work[work["measurement_type"].eq(kind)]
        if subset.empty:
            continue
        prof = weighted_bias_profile(
            subset["residual_native_observed_minus_predicted"], subset["sigma"], kind
        )
        type_profiles[kind] = prof.to_dict()
        profiled_chi2 += prof.profiled_chi2
        if prof.informative:
            profiled_dof -= 1
    profile_nrms = float(np.sqrt(profiled_chi2 / max(profiled_dof, 1)))

    delay = work[work["measurement_type"].eq("delay")]
    doppler = work[work["measurement_type"].eq("doppler")]

    delay_residual_us = delay["residual_native_observed_minus_predicted"].to_numpy(float)
    doppler_residual_hz = doppler["residual_native_observed_minus_predicted"].to_numpy(float)
    doppler_freq_hz = doppler["freq"].to_numpy(float) * 1.0e6
    doppler_velocity_m_s = (
        doppler_residual_hz * SPEED_OF_LIGHT_M_S / doppler_freq_hz
        if len(doppler)
        else np.asarray([], dtype=float)
    )

    station_profiles = []
    for (kind, pair), subset in work.groupby(["measurement_type", "station_pair"], sort=True):
        prof = weighted_bias_profile(
            subset["residual_native_observed_minus_predicted"], subset["sigma"], f"{kind}:{pair}"
        )
        row = prof.to_dict()
        row.update({"measurement_type": str(kind), "station_pair": str(pair)})
        station_profiles.append(row)

    summary = {
        "model": str(model),
        "n_records": int(len(work)),
        "n_delay": int(len(delay)),
        "n_doppler": int(len(doppler)),
        "raw_radar_chi2": raw_chi2,
        "raw_radar_normalized_residual_rms": raw_nrms,
        "formal_radar_closure_nrms_limit": float(formal_nrms_limit),
        "formal_radar_closure_gate_pass": bool(raw_nrms <= formal_nrms_limit),
        "global_measurement_type_bias_profiles": type_profiles,
        "global_bias_profile_chi2": float(profiled_chi2),
        "global_bias_profile_dof": int(profiled_dof),
        "global_bias_profile_normalized_residual_rms": profile_nrms,
        "profile_radar_closure_nrms_limit": float(profile_nrms_limit),
        "profile_radar_closure_gate_pass": bool(profile_nrms <= profile_nrms_limit),
        "station_pair_bias_profiles_diagnostic_only": station_profiles,
        "delay_weighted_bias_us": (
            type_profiles.get("delay", {}).get("weighted_bias_native")
        ),
        "doppler_weighted_bias_hz": (
            type_profiles.get("doppler", {}).get("weighted_bias_native")
        ),
        "max_abs_delay_residual_us": (
            float(np.max(np.abs(delay_residual_us))) if len(delay_residual_us) else None
        ),
        "delay_rms_residual_us": (
            float(np.sqrt(np.mean(np.square(delay_residual_us)))) if len(delay_residual_us) else None
        ),
        "max_abs_delay_one_way_range_equivalent_km": (
            float(np.max(np.abs(delay_residual_us)) * SPEED_OF_LIGHT_M_S * 1.0e-6 / 2.0 / 1000.0)
            if len(delay_residual_us)
            else None
        ),
        "max_abs_doppler_residual_hz": (
            float(np.max(np.abs(doppler_residual_hz))) if len(doppler_residual_hz) else None
        ),
        "doppler_rms_residual_hz": (
            float(np.sqrt(np.mean(np.square(doppler_residual_hz)))) if len(doppler_residual_hz) else None
        ),
        "max_abs_two_way_doppler_velocity_equivalent_m_s": (
            float(np.max(np.abs(doppler_velocity_m_s))) if len(doppler_velocity_m_s) else None
        ),
        "delay_residual_linear_trend_us_per_day": _linear_trend_per_day(delay),
        "doppler_residual_linear_trend_hz_per_day": _linear_trend_per_day(doppler),
        "coarse_geometry_gate_pass": coarse_gate_pass,
        "doppler_sign_convention_gate_pass": doppler_sign_gate_pass,
    }
    summary["prediction_classification"] = (
        "formally_closed"
        if summary["formal_radar_closure_gate_pass"]
        else (
            "gross_geometry_closed_but_formal_radar_not_closed"
            if coarse_gate_pass is True and doppler_sign_gate_pass is True
            else "prediction_model_or_semantics_not_closed"
        )
    )
    return summary


def compare_model_summaries(model_summaries: dict[str, dict]) -> dict:
    if not model_summaries:
        raise ValueError("No model summaries supplied")
    raw_preferred = min(model_summaries, key=lambda m: model_summaries[m]["raw_radar_chi2"])
    profile_preferred = min(
        model_summaries, key=lambda m: model_summaries[m]["global_bias_profile_chi2"]
    )
    concordant = raw_preferred == profile_preferred
    a1_status = "not_evaluable"
    if {"M_SY", "M_Y"}.issubset(model_summaries):
        if raw_preferred == "M_SY" and profile_preferred == "M_SY":
            a1_status = "supported_by_prediction_audit"
        elif raw_preferred == "M_Y" and profile_preferred == "M_Y":
            a1_status = "not_supported_by_prediction_audit"
        else:
            a1_status = "mixed_prediction_evidence"
    all_coarse = all(s.get("coarse_geometry_gate_pass") is True for s in model_summaries.values())
    all_sign = all(s.get("doppler_sign_convention_gate_pass") is True for s in model_summaries.values())
    all_formal = all(s.get("formal_radar_closure_gate_pass") is True for s in model_summaries.values())
    all_profile = all(s.get("profile_radar_closure_gate_pass") is True for s in model_summaries.values())
    return {
        "raw_chi2_preferred_model": raw_preferred,
        "global_bias_profile_chi2_preferred_model": profile_preferred,
        "raw_and_profile_preference_concordant": bool(concordant),
        "A1_external_prediction_support_status": a1_status,
        "all_models_coarse_geometry_closed": bool(all_coarse),
        "all_models_doppler_sign_closed": bool(all_sign),
        "all_models_formally_radar_closed": bool(all_formal),
        "all_models_global_bias_profile_closed": bool(all_profile),
        "joint_optical_radar_fit_readiness_gate_pass": bool(all_coarse and all_sign),
        "A2_external_prediction_status": (
            "formal_prediction_closed"
            if all_formal
            else (
                "grossly_consistent_but_not_formally_closed"
                if all_coarse and all_sign
                else "not_closed"
            )
        ),
    }
