from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd

from .tudat_compat import jd_utc_to_tdb_seconds_since_j2000

SPEED_OF_LIGHT_M_S = 299_792_458.0


@dataclass(frozen=True)
class RadarGateConfig:
    coarse_delay_residual_limit_us: float = 5_000.0
    coarse_doppler_residual_limit_hz: float = 500.0
    sign_preference_factor: float = 10.0


def normalize_longitude_deg(longitude_deg: float) -> float:
    """Normalize longitude to [-180, 180)."""
    return float(((float(longitude_deg) + 180.0) % 360.0) - 180.0)


def delay_us_to_two_way_range_m(delay_us: float | np.ndarray) -> float | np.ndarray:
    return np.asarray(delay_us, dtype=float) * 1.0e-6 * SPEED_OF_LIGHT_M_S


def delay_sigma_us_to_two_way_range_sigma_m(sigma_us: float | np.ndarray) -> float | np.ndarray:
    return delay_us_to_two_way_range_m(sigma_us)


def doppler_hz_to_two_way_doppler_m_s(
    doppler_hz: float | np.ndarray,
    transmitter_frequency_mhz: float | np.ndarray,
) -> float | np.ndarray:
    """Convert frequency shift to Tudat's non-normalized instantaneous Doppler unit.

    Tudat's two-way instantaneous Doppler observable is ``c * (frequency_ratio - 1)``
    in m/s.  JPL radar astrometry supplies the frequency change in Hz and the
    transmitter frequency in MHz.  The conversion therefore preserves the sign
    convention without introducing an arbitrary factor of two.
    """
    doppler = np.asarray(doppler_hz, dtype=float)
    freq_hz = np.asarray(transmitter_frequency_mhz, dtype=float) * 1.0e6
    return SPEED_OF_LIGHT_M_S * doppler / freq_hz


def doppler_sigma_hz_to_two_way_doppler_sigma_m_s(
    sigma_hz: float | np.ndarray,
    transmitter_frequency_mhz: float | np.ndarray,
) -> float | np.ndarray:
    return np.abs(
        doppler_hz_to_two_way_doppler_m_s(sigma_hz, transmitter_frequency_mhz)
    )


def two_way_doppler_m_s_to_hz(
    doppler_m_s: float | np.ndarray,
    transmitter_frequency_mhz: float | np.ndarray,
) -> float | np.ndarray:
    doppler = np.asarray(doppler_m_s, dtype=float)
    freq_hz = np.asarray(transmitter_frequency_mhz, dtype=float) * 1.0e6
    return doppler * freq_hz / SPEED_OF_LIGHT_M_S


def two_way_range_m_to_delay_us(range_m: float | np.ndarray) -> float | np.ndarray:
    return np.asarray(range_m, dtype=float) / SPEED_OF_LIGHT_M_S * 1.0e6


def prepare_radar_observables(frame: pd.DataFrame) -> pd.DataFrame:
    required = {
        "epoch_utc",
        "measurement_type",
        "value",
        "sigma",
        "units",
        "freq",
        "xmit",
        "rcvr",
        "station_pair",
        "bp",
        "is_center_of_mass",
    }
    missing = sorted(required - set(frame.columns))
    if missing:
        raise ValueError(f"Missing radar columns: {missing}")

    out = frame.copy()
    out["epoch_utc"] = pd.to_datetime(out["epoch_utc"], utc=True, errors="raise")
    jd_utc = out["epoch_utc"].map(lambda x: float(x.to_julian_date())).to_numpy(float)
    out["epoch_jd_utc"] = jd_utc
    out["epoch_tdb_s_j2000"] = jd_utc_to_tdb_seconds_since_j2000(jd_utc)
    out["xmit"] = out["xmit"].astype(str)
    out["rcvr"] = out["rcvr"].astype(str)
    out["measurement_type"] = out["measurement_type"].astype(str).str.lower()

    out["tudat_observable_type"] = np.where(
        out["measurement_type"].eq("delay"),
        "two_way_range",
        "two_way_doppler_instantaneous",
    )
    out["observed_tudat_value"] = np.nan
    out["observed_tudat_sigma"] = np.nan
    out["observed_tudat_units"] = ""

    delay_mask = out["measurement_type"].eq("delay")
    doppler_mask = out["measurement_type"].eq("doppler")
    if not bool((delay_mask | doppler_mask).all()):
        bad = sorted(out.loc[~(delay_mask | doppler_mask), "measurement_type"].unique())
        raise ValueError(f"Unsupported radar measurement types: {bad}")

    out.loc[delay_mask, "observed_tudat_value"] = delay_us_to_two_way_range_m(
        out.loc[delay_mask, "value"].to_numpy(float)
    )
    out.loc[delay_mask, "observed_tudat_sigma"] = delay_sigma_us_to_two_way_range_sigma_m(
        out.loc[delay_mask, "sigma"].to_numpy(float)
    )
    out.loc[delay_mask, "observed_tudat_units"] = "m_two_way_path"

    out.loc[doppler_mask, "observed_tudat_value"] = doppler_hz_to_two_way_doppler_m_s(
        out.loc[doppler_mask, "value"].to_numpy(float),
        out.loc[doppler_mask, "freq"].to_numpy(float),
    )
    out.loc[doppler_mask, "observed_tudat_sigma"] = doppler_sigma_hz_to_two_way_doppler_sigma_m_s(
        out.loc[doppler_mask, "sigma"].to_numpy(float),
        out.loc[doppler_mask, "freq"].to_numpy(float),
    )
    out.loc[doppler_mask, "observed_tudat_units"] = "m_per_s_two_way_doppler"

    out["weight_tudat_inverse_variance"] = 1.0 / np.square(
        out["observed_tudat_sigma"].to_numpy(float)
    )
    out["reference_link_end"] = "receiver"
    out["epoch_semantics"] = "UTC echo reception epoch"
    out["direct_fit_eligible"] = (
        out["is_center_of_mass"].astype(bool)
        & np.isfinite(out["observed_tudat_value"].to_numpy(float))
        & np.isfinite(out["observed_tudat_sigma"].to_numpy(float))
        & (out["observed_tudat_sigma"].to_numpy(float) > 0.0)
    )
    return out


def summarize_prepared_radar(frame: pd.DataFrame) -> dict:
    delay = frame[frame["measurement_type"].eq("delay")]
    doppler = frame[frame["measurement_type"].eq("doppler")]
    return {
        "n_records": int(len(frame)),
        "n_delay": int(len(delay)),
        "n_doppler": int(len(doppler)),
        "all_center_of_mass": bool(frame["is_center_of_mass"].astype(bool).all()),
        "all_direct_fit_eligible": bool(frame["direct_fit_eligible"].astype(bool).all()),
        "epoch_min_utc": frame["epoch_utc"].min().isoformat(),
        "epoch_max_utc": frame["epoch_utc"].max().isoformat(),
        "epoch_min_tdb_s_j2000": float(frame["epoch_tdb_s_j2000"].min()),
        "epoch_max_tdb_s_j2000": float(frame["epoch_tdb_s_j2000"].max()),
        "delay_two_way_range_m_min": float(delay["observed_tudat_value"].min()) if len(delay) else None,
        "delay_two_way_range_m_max": float(delay["observed_tudat_value"].max()) if len(delay) else None,
        "delay_sigma_m_min": float(delay["observed_tudat_sigma"].min()) if len(delay) else None,
        "delay_sigma_m_max": float(delay["observed_tudat_sigma"].max()) if len(delay) else None,
        "doppler_m_s_min": float(doppler["observed_tudat_value"].min()) if len(doppler) else None,
        "doppler_m_s_max": float(doppler["observed_tudat_value"].max()) if len(doppler) else None,
        "doppler_sigma_m_s_min": float(doppler["observed_tudat_sigma"].min()) if len(doppler) else None,
        "doppler_sigma_m_s_max": float(doppler["observed_tudat_sigma"].max()) if len(doppler) else None,
        "station_pairs": sorted(frame["station_pair"].astype(str).unique().tolist()),
        "reference_link_end": "receiver",
        "epoch_semantics": "UTC echo reception epoch",
        "conversion_gate_pass": bool(
            frame["direct_fit_eligible"].astype(bool).all()
            and np.isfinite(frame["weight_tudat_inverse_variance"].to_numpy(float)).all()
        ),
    }
