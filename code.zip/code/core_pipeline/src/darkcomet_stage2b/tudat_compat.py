from __future__ import annotations

import inspect
from importlib import metadata
from pathlib import Path
from typing import Any, Iterable

import numpy as np
import pandas as pd


_REQUIRED_COLUMNS = ("Code", "Longitude", "cos", "sin", "Name")


def _as_dataframe(value: Any) -> pd.DataFrame:
    """Convert common mpc-obscodes return types to a pandas DataFrame."""
    if isinstance(value, pd.DataFrame):
        return value.copy()
    if isinstance(value, dict):
        return pd.DataFrame.from_dict(value, orient="index")
    if hasattr(value, "to_pandas"):
        return value.to_pandas()
    if isinstance(value, (str, Path)):
        return pd.read_json(value, orient="index")
    raise TypeError(f"Unsupported observatory-data type: {type(value).__name__}")


def normalize_observatory_table(raw: pd.DataFrame) -> pd.DataFrame:
    """Normalize the mpc-obscodes mirror to Tudat BatchMPC's internal schema."""
    frame = raw.copy()
    if "Code" not in frame.columns:
        frame = frame.reset_index().rename(columns={frame.index.name or "index": "Code"})

    # Accept capitalization variants without silently accepting ambiguous duplicates.
    aliases = {
        "code": "Code",
        "longitude": "Longitude",
        "cos": "cos",
        "sin": "sin",
        "name": "Name",
    }
    rename: dict[str, str] = {}
    for column in frame.columns:
        key = str(column).strip().lower()
        if key in aliases and column != aliases[key]:
            rename[column] = aliases[key]
    frame = frame.rename(columns=rename)

    missing = [column for column in _REQUIRED_COLUMNS if column not in frame.columns]
    if missing:
        raise ValueError(f"Observatory table is missing columns: {missing}")

    frame = frame.loc[:, list(_REQUIRED_COLUMNS)].copy()
    frame["Code"] = frame["Code"].astype(str).str.strip().str.zfill(3)
    for column in ("Longitude", "cos", "sin"):
        frame[column] = pd.to_numeric(frame[column], errors="coerce")
    frame["Name"] = frame["Name"].fillna("").astype(str)
    frame = frame.drop_duplicates(subset=["Code"], keep="last").sort_values("Code")
    return frame.reset_index(drop=True)


def _load_from_mpc_obscodes_package() -> tuple[pd.DataFrame, str]:
    errors: list[str] = []

    # Current data-package interface.
    try:
        from mpc_obscodes import obscodes  # type: ignore

        loaded = obscodes.load()
        version = metadata.version("mpc-obscodes")
        return normalize_observatory_table(_as_dataframe(loaded)), f"mpc-obscodes:{version}:obscodes.load"
    except Exception as exc:  # pragma: no cover - depends on installed package version
        errors.append(f"obscodes.load: {type(exc).__name__}: {exc}")

    # Legacy interface documented by the package itself.
    try:
        from mpc_obscodes import mpc_obscodes  # type: ignore

        version = metadata.version("mpc-obscodes")
        return normalize_observatory_table(pd.read_json(mpc_obscodes, orient="index")), (
            f"mpc-obscodes:{version}:mpc_obscodes"
        )
    except Exception as exc:  # pragma: no cover - depends on installed package version
        errors.append(f"mpc_obscodes: {type(exc).__name__}: {exc}")

    detail = " | ".join(errors)
    raise RuntimeError(
        "Offline MPC observatory data are unavailable. Install the pinned data package with: "
        "python -m pip install mpc-obscodes==2026.5.7. Details: " + detail
    )


def load_observatory_table(
    cache_path: Path,
    required_codes: Iterable[str] | None = None,
    refresh: bool = False,
) -> tuple[pd.DataFrame, dict[str, Any]]:
    """Load a frozen local cache, creating it from mpc-obscodes when necessary."""
    cache_path = Path(cache_path)
    if cache_path.exists() and not refresh:
        frame = normalize_observatory_table(pd.read_csv(cache_path, dtype={"Code": str}))
        source = "local_cache"
    else:
        frame, source = _load_from_mpc_obscodes_package()
        cache_path.parent.mkdir(parents=True, exist_ok=True)
        frame.to_csv(cache_path, index=False)

    required = sorted({str(code).strip().zfill(3) for code in (required_codes or [])})
    available = set(frame["Code"].astype(str))
    missing = sorted(set(required) - available)
    if missing:
        raise ValueError(
            "The offline observatory table does not cover all observations. Missing MPC codes: "
            + ", ".join(missing)
        )

    metadata_payload = {
        "source": source,
        "cache_path": str(cache_path),
        "rows": int(len(frame)),
        "required_codes": required,
        "missing_codes": missing,
    }
    return frame, metadata_payload


def _expected_tdb_seconds_from_jd_utc(julian_days: np.ndarray) -> np.ndarray:
    """Convert UTC Julian days to Tudat TDB seconds since J2000.

    The explicit NumPy conversion is intentional.  TudatPy 1.0.0's legacy
    BatchMPC implementation passes a pandas Series directly to Astropy.  With
    pandas 3.x this can silently produce a datetime64 unit mismatch and dates
    close to January 1970.
    """
    from astropy.time import Time

    jd = np.asarray(julian_days, dtype=np.float64)
    if jd.ndim != 1 or jd.size == 0 or not np.isfinite(jd).all():
        raise ValueError("Julian-day input must be a finite non-empty vector")
    if float(jd.min()) < 2_400_000.0 or float(jd.max()) > 2_600_000.0:
        raise ValueError(f"Julian-day range is implausible: {jd.min()} .. {jd.max()}")
    tdb_jd = np.asarray(Time(jd, format="jd", scale="utc").tdb.jd, dtype=np.float64)
    return (tdb_jd - 2_451_545.0) * 86_400.0


def jd_utc_to_tdb_seconds_since_j2000(julian_days: np.ndarray) -> np.ndarray:
    """Public, version-stable UTC-JD to TDB-seconds-since-J2000 converter."""
    return _expected_tdb_seconds_from_jd_utc(julian_days)


def _repair_and_validate_batch_time_axis(batch: Any) -> dict[str, Any]:
    """Overwrite legacy BatchMPC time columns with a version-stable conversion."""
    if not hasattr(batch, "_table") or "epoch" not in batch._table.columns:
        raise RuntimeError("BatchMPC internal table is unavailable or lacks the epoch column")

    table = batch._table.copy()
    jd = pd.to_numeric(table["epoch"], errors="raise").to_numpy(dtype=np.float64)
    expected_tdb = _expected_tdb_seconds_from_jd_utc(jd)
    raw_start = float(getattr(batch, "epoch_start", float("nan")))
    raw_end = float(getattr(batch, "epoch_end", float("nan")))

    # Support both the stable 1.0.0 column names and the newer development names.
    table["epochJ2000secondsTDB"] = expected_tdb
    table["epoch_seconds_TDB"] = expected_tdb

    from astropy.time import Time
    utc_datetimes = Time(jd, format="jd", scale="utc").to_datetime()
    table["epochUTC"] = list(utc_datetimes)

    batch._table = table
    if not hasattr(batch, "_refresh_metadata"):
        raise RuntimeError("BatchMPC build does not expose _refresh_metadata")
    batch._refresh_metadata()

    corrected_start = float(batch.epoch_start)
    corrected_end = float(batch.epoch_end)
    expected_start = float(expected_tdb.min())
    expected_end = float(expected_tdb.max())
    max_error_s = max(abs(corrected_start - expected_start), abs(corrected_end - expected_end))
    if max_error_s > 1.0e-3:
        raise RuntimeError(f"Batch time-axis repair failed; maximum endpoint error={max_error_s} s")
    if float(jd.min()) > 2_455_000.0 and corrected_start <= 0.0:
        raise RuntimeError(
            "Post-2010 observations mapped to a non-positive J2000 epoch; refusing orbit fit"
        )
    # Validate like-for-like timescales. corrected_start/end and
    # expected_start/end are all TDB seconds since J2000. The previous
    # implementation compared the TDB span to a UTC-JD span, which differs
    # by the change in TDB-UTC (including leap seconds) across the arc.
    span_from_batch_tdb = corrected_end - corrected_start
    span_from_expected_tdb = expected_end - expected_start
    batch_vs_expected_tdb_span_error_s = abs(
        span_from_batch_tdb - span_from_expected_tdb
    )
    if batch_vs_expected_tdb_span_error_s > 1.0e-3:
        raise RuntimeError(
            "Batch TDB time-span repair failed; "
            f"batch={span_from_batch_tdb}, "
            f"expected_tdb={span_from_expected_tdb}, "
            f"error={batch_vs_expected_tdb_span_error_s} seconds"
        )

    span_from_utc_jd = (float(jd.max()) - float(jd.min())) * 86_400.0
    tdb_minus_utc_span_delta_s = (
        span_from_expected_tdb - span_from_utc_jd
    )
    if not np.isfinite(tdb_minus_utc_span_delta_s):
        raise RuntimeError("Non-finite TDB-minus-UTC span diagnostic")

    return {
        "raw_epoch_start_tdb_s_j2000": raw_start,
        "raw_epoch_end_tdb_s_j2000": raw_end,
        "corrected_epoch_start_tdb_s_j2000": corrected_start,
        "corrected_epoch_end_tdb_s_j2000": corrected_end,
        "epoch_endpoint_max_error_s": max_error_s,
        "time_axis_repair_applied": bool(
            (not np.isfinite(raw_start))
            or (not np.isfinite(raw_end))
            or abs(raw_start - corrected_start) > 1.0e-3
            or abs(raw_end - corrected_end) > 1.0e-3
        ),
        "input_jd_min": float(jd.min()),
        "input_jd_max": float(jd.max()),
        "input_span_days": float(jd.max() - jd.min()),
        "input_span_utc_seconds": span_from_utc_jd,
        "batch_span_tdb_seconds": span_from_batch_tdb,
        "expected_span_tdb_seconds": span_from_expected_tdb,
        "batch_vs_expected_tdb_span_error_s":
            batch_vs_expected_tdb_span_error_s,
        "tdb_minus_utc_span_delta_s": tdb_minus_utc_span_delta_s,
        "time_span_validation_basis": "TDB batch versus expected TDB",
    }


def _call_from_pandas_compat(batch: Any, table: pd.DataFrame, target_id: str) -> dict[str, Any]:
    """Call BatchMPC.from_pandas across TudatPy 1.0 build-signature variants."""
    payload = table.copy()
    payload["number"] = str(target_id)
    signature = inspect.signature(batch.from_pandas)
    kwargs: dict[str, Any] = {"in_degrees": True, "frame": "J2000"}
    if "custom_name" in signature.parameters:
        kwargs["custom_name"] = str(target_id)
    batch.from_pandas(payload, **kwargs)
    time_meta = _repair_and_validate_batch_time_axis(batch)
    return {
        "from_pandas_signature": str(signature),
        "custom_name_argument_used": "custom_name" in kwargs,
        **time_meta,
    }


def create_offline_batch_mpc(
    table: pd.DataFrame,
    target_id: str,
    observatory_cache_path: Path,
) -> tuple[Any, dict[str, Any]]:
    """Create BatchMPC without making the constructor contact ObsCodes.html."""
    from tudatpy.data.mpc import BatchMPC

    station_codes = sorted(table["observatory"].astype(str).str.strip().str.zfill(3).unique())
    observatory_info, cache_meta = load_observatory_table(
        observatory_cache_path,
        required_codes=station_codes,
        refresh=False,
    )

    # BatchMPC.__init__ calls self._get_station_info(); overriding it prevents the
    # legacy astroquery request while preserving BatchMPC's normal initialization.
    class OfflineBatchMPC(BatchMPC):
        def _get_station_info(self) -> None:  # noqa: N802 - matches Tudat private API
            self._observatory_info = observatory_info.copy()
            self._MPC_space_telescopes = list(
                observatory_info.loc[observatory_info["Longitude"].isna(), "Code"].astype(str)
            )

    batch = OfflineBatchMPC()
    signature_meta = _call_from_pandas_compat(batch, table, target_id)
    metadata_payload = {
        **cache_meta,
        **signature_meta,
        "batch_observatories": list(batch.observatories),
        "batch_size": int(batch.size),
    }
    return batch, metadata_payload


def make_rkf78_integrator(integrator_module: Any, dynamics_config: dict[str, Any]) -> Any:
    """Create a variable-step RKF7(8) integrator using the TudatPy 1.0 API."""
    initial_step = float(dynamics_config.get("integrator_initial_step_hours", 1.0)) * 3600.0
    minimum_step = float(dynamics_config.get("integrator_min_step_seconds", 1.0))
    maximum_step = float(
        dynamics_config.get(
            "integrator_max_step_hours",
            dynamics_config.get("integrator_step_hours", 12.0),
        )
    ) * 3600.0
    relative_tolerance = float(dynamics_config.get("integrator_relative_tolerance", 1.0e-12))
    absolute_tolerance = float(dynamics_config.get("integrator_absolute_tolerance", 1.0e-3))

    control = integrator_module.step_size_control_elementwise_scalar_tolerance(
        relative_tolerance,
        absolute_tolerance,
    )
    validation = integrator_module.step_size_validation(minimum_step, maximum_step)
    return integrator_module.runge_kutta_variable_step(
        initial_time_step=initial_step,
        coefficient_set=integrator_module.CoefficientSets.rkf_78,
        step_size_control_settings=control,
        step_size_validation_settings=validation,
    )
