from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

import argparse
import json
import math
import traceback
import inspect
from pathlib import Path

import numpy as np
import pandas as pd

from darkcomet_stage2b.common import (
    ARCSEC_TO_RAD,
    SOLAR_PRESSURE_1AU_N_M2,
    au_d2_to_m_s2,
    dump_json,
    ensure_directories,
    load_config,
    m_s2_to_au_d2,
    project_root,
    safe_slug,
)
from darkcomet_stage2b.stats import information_criteria, safe_z
from darkcomet_stage2b.fit_diagnostics import weighted_fit_statistics
from darkcomet_stage2b.horizons_identity import query_anchored_cartesian_state
from darkcomet_stage2b.tudat_compat import create_offline_batch_mpc, make_rkf78_integrator
from darkcomet_stage2b.ra_branch import normalize_ra_observation_branches, wrap_to_pi


def safe_callable_signature(callable_obj):
    """Return non-fatal API provenance for Python and pybind11 callables.

    Some TudatPy functions are pybind11 builtins without ``__text_signature__``.
    ``inspect.signature`` then raises ``ValueError`` even though the callable is
    valid.  Provenance collection must never block orbit estimation.
    """
    try:
        return str(inspect.signature(callable_obj)), "inspect.signature", True
    except (TypeError, ValueError) as exc:
        doc = str(getattr(callable_obj, "__doc__", "") or "")
        first_line = next((line.strip() for line in doc.splitlines() if line.strip()), "")
        if first_line:
            return first_line, "pybind11_docstring", False
        return (
            f"<signature unavailable: {type(exc).__name__}>",
            "unavailable",
            False,
        )


def parameter_labels(model_name: str) -> list[str]:
    labels = [
        "initial_state_x_m", "initial_state_y_m", "initial_state_z_m",
        "initial_state_vx_m_s", "initial_state_vy_m_s", "initial_state_vz_m_s",
    ]
    if model_name in {"M_SRP", "M_SY"}:
        labels.append("srp_parallel_scale")
    if model_name in {"M_Y", "M_SY"}:
        labels.append("A2_m_s2")
    return labels


def parameter_rows(model_name, values, formal_errors, error_inflation_factor):
    labels = parameter_labels(model_name)
    if len(labels) != len(values):
        labels = labels[:len(values)] + [f"unnamed_parameter_{i}" for i in range(len(labels), len(values))]
    rows = []
    for i, (label, value) in enumerate(zip(labels, values)):
        raw_error = float(formal_errors[i]) if i < len(formal_errors) else float("nan")
        scaled_error = raw_error * float(error_inflation_factor)
        rows.append({
            "parameter_index": i,
            "parameter_name": label,
            "value": float(value),
            "formal_error_raw": raw_error,
            "formal_error_overdispersion_scaled": scaled_error,
            "z_formal": safe_z(float(value), raw_error),
            "z_overdispersion_scaled": safe_z(float(value), scaled_error),
        })
    return rows


def run_fit(
    target_id: str,
    model_name: str,
    fallback_sigma: float,
    exclude_cluster: int | None,
    initial_state_lead_days_override: float | None = None,
    initial_state_anchor_override: str | None = None,
    force_seed_policy_override: str | None = None,
):
    from tudatpy.interface import spice
    from tudatpy import estimation
    from tudatpy.dynamics import environment_setup, propagation_setup, parameters_setup
    from tudatpy.estimation import observable_models_setup, estimation_analysis, observations as tudat_observations
    from tudatpy.data.horizons import HorizonsQuery

    cfg = load_config()
    ensure_directories(cfg)
    root = project_root()
    tcfg = cfg["targets"][target_id]
    mcfg = cfg["models"][model_name]
    slug = safe_slug(target_id)
    suffix = f"fallback_{fallback_sigma:g}"

    prepared_path = root / cfg["paths"]["processed_directory"] / f"{slug}_prepared_{suffix}.csv"
    batch_path = root / cfg["paths"]["processed_directory"] / f"{slug}_batchmpc_{suffix}.csv"
    if not prepared_path.exists() or not batch_path.exists():
        raise FileNotFoundError(
            f"Prepared inputs not found for {target_id}, fallback={fallback_sigma}. "
            "Run 01_prepare_tudat_inputs.py with the same fallback sigma."
        )

    full_prepared = pd.read_csv(prepared_path)
    full_batch_table = pd.read_csv(batch_path)
    prepared = full_prepared.copy()
    batch_table = full_batch_table.copy()
    if exclude_cluster is not None:
        keep = prepared["cluster_id"].astype(int) != int(exclude_cluster)
        prepared = prepared.loc[keep].reset_index(drop=True)
        batch_table = batch_table.loc[keep].reset_index(drop=True)
        if len(prepared) < 10:
            raise RuntimeError("Leave-one-cluster-out sample has fewer than 10 observations")

    spice.load_standard_kernels()

    batch, batch_meta = create_offline_batch_mpc(
        batch_table,
        target_id=target_id,
        observatory_cache_path=root / cfg["paths"]["observatory_cache"],
    )
    full_batch = batch
    full_batch_meta = batch_meta
    if exclude_cluster is not None:
        full_batch, full_batch_meta = create_offline_batch_mpc(
            full_batch_table,
            target_id=target_id,
            observatory_cache_path=root / cfg["paths"]["observatory_cache"],
        )
    weights = prepared["weight_per_coordinate_rad_inverse2"].to_numpy(float)
    batch.set_weights(weights)

    dcfg = cfg["dynamics"]
    global_frame_origin = dcfg["global_frame_origin"]
    global_frame_orientation = dcfg["global_frame_orientation"]
    body_settings = environment_setup.get_default_body_settings(
        dcfg["bodies"], global_frame_origin, global_frame_orientation
    )
    bodies = environment_setup.create_system_of_bodies(body_settings)

    observation_collection = batch.to_tudat(
        bodies=bodies,
        included_satellites=None,
        apply_weights_VFCC17=False,
        apply_star_catalog_debias=False,
    )
    if float(batch.epoch_start) <= 0.0:
        raise RuntimeError(
            f"{target_id}: BatchMPC time axis is invalid ({batch.epoch_start}); "
            "run the v0.3.3 preflight before estimation"
        )
    target_name = str(batch.MPC_objects[0])
    bodies_to_propagate = [target_name]
    central_bodies = [global_frame_origin]

    # The target is normalized to 1 kg. For SRP models, the reference area is chosen
    # from the catalogue A1 prior so that the estimated parallel scaling begins near 1.
    bodies.get(target_name).mass = 1.0
    a1_prior = abs(float(tcfg["jpl_catalogue_A1_au_d2"]))
    a1_prior_si = au_d2_to_m_s2(a1_prior)
    reference_area_m2 = max(a1_prior_si / SOLAR_PRESSURE_1AU_N_M2, 1.0e-8)
    if mcfg["srp"]:
        rp_settings = environment_setup.radiation_pressure.cannonball_radiation_target(
            reference_area_m2,
            1.0,
            {"Sun": ["Earth"]},
        )
        environment_setup.add_radiation_pressure_target_model(
            bodies, target_name, rp_settings
        )

    observation_settings_list = []
    (
        angular_position_signature,
        angular_position_signature_source,
        angular_position_signature_introspection_available,
    ) = safe_callable_signature(
        observable_models_setup.model_settings.angular_position
    )
    # TudatPy 1.0.0 exposes only link/light-time/bias/convergence arguments.
    # The later normalize_right_ascension keyword is not a periodic-wrap switch;
    # in newer builds it changes the observable from alpha to alpha*cos(delta).
    # Keep the native [alpha, delta] observable for cross-version comparability.
    links = observation_collection.get_link_definitions_for_observables(
        observable_type=observable_models_setup.model_settings.angular_position_type
    )
    for link in list(links):
        observation_settings_list.append(
            observable_models_setup.model_settings.angular_position(
                link, bias_settings=None
            )
        )
    angular_position_compatibility = {
        "signature": angular_position_signature,
        "signature_source": angular_position_signature_source,
        "signature_introspection_available": (
            angular_position_signature_introspection_available
        ),
        "normalize_right_ascension_keyword_supported": (
            "normalize_right_ascension" in angular_position_signature
            if angular_position_signature_introspection_available
            else None
        ),
        "normalization_mode": "native_alpha_delta",
        "unsupported_keyword_omitted": True,
        "provenance_introspection_nonfatal": True,
    }

    accelerations = {
        "Sun": [
            propagation_setup.acceleration.point_mass_gravity(),
            propagation_setup.acceleration.relativistic_correction(use_schwarzschild=True),
        ],
        "Mercury": [propagation_setup.acceleration.point_mass_gravity()],
        "Venus": [propagation_setup.acceleration.point_mass_gravity()],
        "Earth": [propagation_setup.acceleration.point_mass_gravity()],
        "Moon": [propagation_setup.acceleration.point_mass_gravity()],
        "Mars": [propagation_setup.acceleration.point_mass_gravity()],
        "Jupiter": [propagation_setup.acceleration.point_mass_gravity()],
        "Saturn": [propagation_setup.acceleration.point_mass_gravity()],
        "Uranus": [propagation_setup.acceleration.point_mass_gravity()],
        "Neptune": [propagation_setup.acceleration.point_mass_gravity()],
    }
    if mcfg["srp"]:
        accelerations["Sun"].append(propagation_setup.acceleration.radiation_pressure())
    if mcfg["yarkovsky"]:
        a2_initial_si = au_d2_to_m_s2(float(tcfg.get("jpl_catalogue_A2_au_d2") or 0.0))
        accelerations["Sun"].append(propagation_setup.acceleration.yarkovsky(a2_initial_si))

    acceleration_models = propagation_setup.create_acceleration_models(
        bodies,
        {target_name: accelerations},
        bodies_to_propagate,
        central_bodies,
    )

    end_buffer_s = float(dcfg["time_buffer_days"]) * 86400.0
    # LOO fits use the full-sample reference epoch and propagation interval.
    # For close-encounter targets, querying the initial state many weeks before
    # the first observation can amplify small force-model differences before the
    # fit sees any data.  Use a target-specific lead time, with a CLI override for
    # a controlled epoch-sensitivity ladder.
    reference_batch = full_batch if exclude_cluster is not None else batch
    configured_lead_days = float(
        tcfg.get("initial_state_lead_days", dcfg["time_buffer_days"])
    )
    initial_state_lead_days = (
        float(initial_state_lead_days_override)
        if initial_state_lead_days_override is not None
        else configured_lead_days
    )
    if not (0.005 <= initial_state_lead_days <= float(dcfg["time_buffer_days"])):
        raise ValueError(
            "initial_state_lead_days must be between 0.005 and "
            f"{float(dcfg['time_buffer_days']):g} days"
        )
    epoch_start = float(reference_batch.epoch_start - initial_state_lead_days * 86400.0)
    epoch_end = float(reference_batch.epoch_end + end_buffer_s)

    configured_anchor_mode = str(tcfg.get("initial_state_anchor", "direct_ssb"))
    initial_state_anchor_mode = (
        str(initial_state_anchor_override)
        if initial_state_anchor_override is not None
        else configured_anchor_mode
    )
    initial_state, horizons_identity = query_anchored_cartesian_state(
        HorizonsQuery,
        bodies=bodies,
        target_id=target_id,
        target_cfg=tcfg,
        epoch=epoch_start,
        frame_origin=global_frame_origin,
        frame_orientation=global_frame_orientation,
        anchor_mode=initial_state_anchor_mode,
    )

    integrator_settings = make_rkf78_integrator(
        propagation_setup.integrator,
        dcfg,
    )
    termination = propagation_setup.propagator.time_termination(epoch_end)
    propagator_settings = propagation_setup.propagator.translational(
        central_bodies=central_bodies,
        acceleration_models=acceleration_models,
        bodies_to_integrate=bodies_to_propagate,
        initial_states=initial_state,
        initial_time=epoch_start,
        integrator_settings=integrator_settings,
        termination_settings=termination,
    )

    parameter_settings = parameters_setup.initial_states(propagator_settings, bodies)
    if mcfg["srp"]:
        parameter_settings.append(
            parameters_setup.radiation_pressure_target_direction_scaling(target_name, "Sun")
        )
    if mcfg["yarkovsky"]:
        parameter_settings.append(parameters_setup.yarkovsky_parameter(target_name, "Sun"))

    parameters_to_estimate = parameters_setup.create_parameter_set(
        parameter_settings, bodies, propagator_settings
    )

    # Preserve nesting in the optimizer. Extended full-sample models start
    # from M0. LOO models use the corresponding full-sample best-fit vector at
    # the same fixed reference epoch; this is essential for sparse subsets.
    warm_start_source = "exact_spkid_horizons"
    initial_parameter_vector = np.asarray(parameters_to_estimate.parameter_vector, dtype=float).copy()
    if exclude_cluster is not None:
        full_model_path = root / cfg["paths"]["models_directory"] / f"{slug}__{model_name}__{suffix}__summary.json"
        if full_model_path.exists():
            full_model_summary = json.loads(full_model_path.read_text(encoding="utf-8"))
            full_model_vector = np.asarray(full_model_summary.get("final_parameter_vector", []), dtype=float)
            if (
                bool(full_model_summary.get("fit_valid", False))
                and full_model_vector.size == initial_parameter_vector.size
                and np.isfinite(full_model_vector).all()
            ):
                initial_parameter_vector[:] = full_model_vector
                warm_start_source = f"full_sample_{model_name}_best_iteration_fixed_epoch"
        if warm_start_source == "exact_spkid_horizons":
            m0_path = root / cfg["paths"]["models_directory"] / f"{slug}__M0__{suffix}__summary.json"
            if m0_path.exists():
                m0_summary = json.loads(m0_path.read_text(encoding="utf-8"))
                m0_vector = np.asarray(m0_summary.get("final_parameter_vector", []), dtype=float)
                if (
                    bool(m0_summary.get("fit_valid", False))
                    and m0_vector.size >= 6
                    and np.isfinite(m0_vector[:6]).all()
                ):
                    initial_parameter_vector[:6] = m0_vector[:6]
                    warm_start_source = "full_sample_M0_best_iteration_fixed_epoch"
    elif (
        model_name != "M0"
        and cfg["fit_validation"].get("warm_start_extended_models_from_M0", True)
    ):
        m0_path = root / cfg["paths"]["models_directory"] / f"{slug}__M0__{suffix}__summary.json"
        if m0_path.exists():
            m0_summary = json.loads(m0_path.read_text(encoding="utf-8"))
            m0_vector = np.asarray(m0_summary.get("final_parameter_vector", []), dtype=float)
            if (
                bool(m0_summary.get("fit_valid", False))
                and m0_vector.size >= 6
                and np.isfinite(m0_vector[:6]).all()
            ):
                initial_parameter_vector[:6] = m0_vector[:6]
                warm_start_source = "M0_best_iteration_state"
    preserve_full_model_force_amplitudes = bool(
        exclude_cluster is not None
        and warm_start_source == f"full_sample_{model_name}_best_iteration_fixed_epoch"
    )
    configured_force_seed_policy = str(tcfg.get("force_seed_policy", "zero"))
    force_seed_policy = (
        str(force_seed_policy_override)
        if force_seed_policy_override is not None
        else configured_force_seed_policy
    )
    if force_seed_policy not in {"zero", "catalogue_priors"}:
        raise ValueError(f"Unknown force seed policy: {force_seed_policy!r}")
    initial_srp_scale_seed = None
    initial_a2_seed_si = None
    if not preserve_full_model_force_amplitudes:
        extra_index = 6
        if mcfg["srp"] and extra_index < initial_parameter_vector.size:
            initial_srp_scale_seed = 1.0 if force_seed_policy == "catalogue_priors" else 0.0
            initial_parameter_vector[extra_index] = initial_srp_scale_seed
            extra_index += 1
        if mcfg["yarkovsky"] and extra_index < initial_parameter_vector.size:
            initial_a2_seed_si = (
                au_d2_to_m_s2(float(tcfg.get("jpl_catalogue_A2_au_d2") or 0.0))
                if force_seed_policy == "catalogue_priors"
                else 0.0
            )
            initial_parameter_vector[extra_index] = initial_a2_seed_si
    parameters_to_estimate.parameter_vector = initial_parameter_vector

    estimator = estimation_analysis.Estimator(
        bodies=bodies,
        estimated_parameters=parameters_to_estimate,
        observation_settings=observation_settings_list,
        propagator_settings=propagator_settings,
        integrate_on_creation=True,
    )

    # TudatPy 1.0 may retain an observed-minus-computed RA residual close to
    # ±2π for a physically tiny angle difference.  A single such branch jump
    # dominates the least-squares norm and drives the state update away from
    # the valid local solution.  Compute the prefit observables once, then
    # shift only RA values by integer multiples of 2π to the nearest simulated
    # branch.  This is a representation change, not a data or physics change.
    tudat_observations.compute_residuals_and_dependent_variables(
        observation_collection, estimator.observation_simulators, bodies
    )
    prefit_raw_residuals_before_branch = np.asarray(
        observation_collection.get_concatenated_residuals(), dtype=float
    ).reshape(-1)
    original_observation_values = np.asarray(
        observation_collection.concatenated_observations, dtype=float
    ).reshape(-1)
    branch_adjusted_observations, ra_branch_normalization = (
        normalize_ra_observation_branches(
            original_observation_values, prefit_raw_residuals_before_branch
        )
    )
    if ra_branch_normalization["n_ra_branch_shifts"] > 0:
        observation_collection.set_observations(branch_adjusted_observations)
        tudat_observations.compute_residuals_and_dependent_variables(
            observation_collection, estimator.observation_simulators, bodies
        )
    prefit_residuals_after_branch = np.asarray(
        observation_collection.get_concatenated_residuals(), dtype=float
    ).reshape(-1)
    expected_prefit_after_branch = prefit_raw_residuals_before_branch.copy()
    expected_prefit_after_branch[0::2] = wrap_to_pi(
        expected_prefit_after_branch[0::2]
    )
    branch_verification_error = float(
        np.max(np.abs(prefit_residuals_after_branch - expected_prefit_after_branch))
    )
    ra_branch_normalization.update({
        "applied": bool(ra_branch_normalization["n_ra_branch_shifts"] > 0),
        "post_reset_prefit_rms_arcsec": float(
            np.sqrt(np.mean(prefit_residuals_after_branch**2)) / ARCSEC_TO_RAD
        ),
        "post_reset_prefit_max_abs_arcsec": float(
            np.max(np.abs(prefit_residuals_after_branch)) / ARCSEC_TO_RAD
        ),
        "post_reset_verification_max_error_rad": branch_verification_error,
        "post_reset_verification_pass": bool(branch_verification_error <= 1.0e-9),
    })
    if not ra_branch_normalization["post_reset_verification_pass"]:
        raise RuntimeError(
            "RA branch-normalization verification failed: "
            f"max error={branch_verification_error} rad"
        )

    pod_input = estimation_analysis.EstimationInput(
        observations_and_times=observation_collection,
        convergence_checker=estimation_analysis.estimation_convergence_checker(
            maximum_iterations=int(dcfg["maximum_iterations"])
        ),
    )
    pod_input.set_weights_from_observation_collection()
    pod_input.define_estimation_settings(reintegrate_variational_equations=True)
    pod_output = estimator.perform_estimation(pod_input)

    # Tudat documents final_parameters/final_residuals as the iteration with the
    # lowest RMS.  The last history column is not necessarily the best iteration.
    final_values = np.asarray(pod_output.final_parameters, dtype=float).reshape(-1)
    formal_errors = np.asarray(pod_output.formal_errors, dtype=float).reshape(-1)
    descriptions = list(parameters_to_estimate.get_parameter_descriptions())
    residuals = np.asarray(pod_output.final_residuals, dtype=float).reshape(-1)
    residual_history = np.asarray(pod_output.residual_history, dtype=float)
    prefit_residuals = residual_history[:, 0].reshape(-1)
    prefit_rms_arcsec = float(np.sqrt(np.mean(prefit_residuals ** 2)) / ARCSEC_TO_RAD)
    prefit_periodic_wrapped_residuals = prefit_residuals.copy()
    prefit_periodic_wrapped_residuals[0::2] = wrap_to_pi(
        prefit_periodic_wrapped_residuals[0::2]
    )
    prefit_periodic_wrapped_rms_arcsec = float(
        np.sqrt(np.mean(prefit_periodic_wrapped_residuals ** 2)) / ARCSEC_TO_RAD
    )

    # Use Tudat's concatenated native weights in exactly the same ordering as the
    # residual vector.  The ObservationCollection reorders data by observable/link,
    # so repeating sigmas in the input CSV order produces a false chi-square.
    collection_weights = np.asarray(observation_collection.concatenated_weights, dtype=float).reshape(-1)
    if len(residuals) != len(collection_weights):
        raise RuntimeError(
            f"Residual length {len(residuals)} != native weight length {len(collection_weights)}"
        )
    native_stats = weighted_fit_statistics(residuals, collection_weights, len(final_values))
    criteria = information_criteria(float(native_stats["chi2"]), len(residuals), len(final_values))
    criteria["profile_scale_bic"] = float(native_stats["profile_scale_bic"])
    error_inflation_factor = (
        max(1.0, math.sqrt(float(criteria["reduced_chi2"])))
        if cfg["fit_validation"].get("inflate_formal_errors_when_reduced_chi2_gt_1", True)
        else 1.0
    )
    scalar_sigmas = 1.0 / np.sqrt(collection_weights)
    rms_residual_arcsec = float(np.sqrt(np.mean(residuals ** 2)) / ARCSEC_TO_RAD)
    max_abs_residual_arcsec = float(np.max(np.abs(residuals)) / ARCSEC_TO_RAD)
    periodic_wrapped_residuals = residuals.copy()
    periodic_wrapped_residuals[0::2] = wrap_to_pi(periodic_wrapped_residuals[0::2])
    periodic_wrapped_rms_arcsec = float(
        np.sqrt(np.mean(periodic_wrapped_residuals ** 2)) / ARCSEC_TO_RAD
    )
    periodic_wrapped_max_abs_arcsec = float(
        np.max(np.abs(periodic_wrapped_residuals)) / ARCSEC_TO_RAD
    )
    fit_valid = bool(
        np.isfinite(residuals).all()
        and np.isfinite(final_values).all()
        and np.isfinite(formal_errors).all()
        and prefit_rms_arcsec <= float(dcfg.get("prefit_rms_gate_arcsec", 600.0))
        and rms_residual_arcsec <= float(cfg["fit_validation"]["max_rms_residual_arcsec"])
        and max_abs_residual_arcsec <= float(cfg["fit_validation"]["max_abs_residual_arcsec"])
    )

    tag = f"{slug}__{model_name}__{suffix}"
    if exclude_cluster is not None:
        tag += f"__exclude_cluster_{int(exclude_cluster)}"

    p_rows = parameter_rows(model_name, final_values, formal_errors, error_inflation_factor)
    parameter_df = pd.DataFrame(p_rows)
    parameter_df.to_csv(
        root / cfg["paths"]["models_directory"] / f"{tag}__parameters.csv", index=False
    )

    times = np.asarray(observation_collection.concatenated_times, dtype=float)
    components = np.where(np.arange(len(residuals)) % 2 == 0, "RA", "DEC")
    residual_df = pd.DataFrame({
        "scalar_index": np.arange(len(residuals)),
        "epoch_tdb_s_j2000": times,
        "component": components,
        "residual_rad": residuals,
        "residual_arcsec": residuals / ARCSEC_TO_RAD,
        "sigma_arcsec": scalar_sigmas / ARCSEC_TO_RAD,
        "normalized_residual": residuals / scalar_sigmas,
    })
    residual_df.to_csv(
        root / cfg["paths"]["residuals_directory"] / f"{tag}__residuals.csv", index=False
    )

    summary = {
        "target_id": target_id,
        "model": model_name,
        "fallback_sigma_arcsec": fallback_sigma,
        "excluded_cluster": exclude_cluster,
        "n_observations": int(len(prepared)),
        "n_temporal_clusters": int(prepared["cluster_id"].nunique()),
        "reference_area_m2_per_1kg": reference_area_m2 if mcfg["srp"] else None,
        "initial_A1_prior_au_d2": float(tcfg["jpl_catalogue_A1_au_d2"]) if mcfg["srp"] else None,
        "initial_A2_prior_au_d2": float(tcfg.get("jpl_catalogue_A2_au_d2") or 0.0) if mcfg["yarkovsky"] else None,
        "parameter_descriptions": descriptions,
        "formal_errors_finite": bool(np.isfinite(formal_errors).all()),
        "warm_start_source": warm_start_source,
        "force_seed_policy": force_seed_policy,
        "configured_force_seed_policy": configured_force_seed_policy,
        "force_seed_override_used": bool(force_seed_policy_override is not None),
        "initial_srp_scale_seed": initial_srp_scale_seed,
        "initial_A2_seed_m_s2": initial_a2_seed_si,
        "initial_A2_seed_au_d2": (
            m_s2_to_au_d2(initial_a2_seed_si) if initial_a2_seed_si is not None else None
        ),
        "reference_epoch_policy": "full_sample_fixed" if exclude_cluster is not None else "full_sample",
        "subset_epoch_start_tdb_s_j2000": float(batch.epoch_start),
        "subset_epoch_end_tdb_s_j2000": float(batch.epoch_end),
        "full_sample_epoch_start_tdb_s_j2000": float(full_batch.epoch_start),
        "full_sample_epoch_end_tdb_s_j2000": float(full_batch.epoch_end),
        "initial_parameter_vector": initial_parameter_vector.tolist(),
        "final_parameter_vector": final_values.tolist(),
        "best_iteration": int(getattr(pod_output, "best_iteration", -1)),
        "n_estimation_iterations": int(residual_history.shape[1]),
        "prefit_rms_arcsec": prefit_rms_arcsec,
        "prefit_periodic_wrapped_rms_arcsec": prefit_periodic_wrapped_rms_arcsec,
        "ra_branch_normalization": ra_branch_normalization,
        "best_iteration_output_used": True,
        "native_observation_weights_used_for_statistics": True,
        "angular_position_compatibility": angular_position_compatibility,
        "right_ascension_normalization_enabled": False,
        "right_ascension_normalization_note": (
            "TudatPy 1.0 native alpha-delta observable; later "
            "normalize_right_ascension means alpha*cos(delta), not periodic wrapping"
        ),
        "error_inflation_factor": float(error_inflation_factor),
        "rms_residual_arcsec": rms_residual_arcsec,
        "max_abs_residual_arcsec": max_abs_residual_arcsec,
        "fit_valid": fit_valid,
        "model_comparison_eligible": fit_valid,
        "weight_vector_sha256": native_stats["weight_vector_sha256"],
        "residual_vector_sha256": native_stats["residual_vector_sha256"],
        "normalized_residual_rms": native_stats["normalized_residual_rms"],
        "horizons_identity": horizons_identity,
        "batchmpc_compatibility": batch_meta,
        "full_sample_batchmpc_compatibility": full_batch_meta if exclude_cluster is not None else batch_meta,
        "initial_state_lead_days": float(initial_state_lead_days),
        "configured_initial_state_lead_days": float(configured_lead_days),
        "initial_state_lead_override_used": bool(initial_state_lead_days_override is not None),
        "initial_state_anchor_mode": initial_state_anchor_mode,
        "configured_initial_state_anchor_mode": configured_anchor_mode,
        "initial_state_anchor_override_used": bool(initial_state_anchor_override is not None),
        "periodic_wrapped_rms_arcsec_diagnostic": periodic_wrapped_rms_arcsec,
        "periodic_wrapped_max_abs_arcsec_diagnostic": periodic_wrapped_max_abs_arcsec,
        "observation_start_minus_propagation_start_s": float(reference_batch.epoch_start - epoch_start),
        "propagation_epoch_start_tdb_s_j2000": epoch_start,
        "propagation_epoch_end_tdb_s_j2000": epoch_end,
        "initial_state_norm_m": float(np.linalg.norm(initial_state[:3])),
        "initial_velocity_norm_m_s": float(np.linalg.norm(initial_state[3:])),
        **criteria,
    }

    # Extract the final extra parameters by position. Initial state occupies first six values.
    extra_cursor = 6
    if mcfg["srp"] and extra_cursor < len(final_values):
        scale = float(final_values[extra_cursor])
        sigma_scale_raw = float(formal_errors[extra_cursor])
        sigma_scale_scaled = sigma_scale_raw * error_inflation_factor
        summary.update({
            "srp_parallel_scale": scale,
            "srp_parallel_scale_sigma_raw": sigma_scale_raw,
            "srp_parallel_scale_sigma_overdispersion_scaled": sigma_scale_scaled,
            "srp_parallel_scale_z_formal": safe_z(scale, sigma_scale_raw),
            "srp_parallel_scale_z_overdispersion_scaled": safe_z(scale, sigma_scale_scaled),
            "srp_parallel_scale_z": safe_z(scale, sigma_scale_scaled),
            "srp_parallel_scale_physically_plausible": bool(np.isfinite(scale) and 0.0 <= scale <= 10.0),
            "A1_equivalent_au_d2": scale * float(tcfg["jpl_catalogue_A1_au_d2"]),
            "A1_equivalent_sigma_raw_au_d2": abs(float(tcfg["jpl_catalogue_A1_au_d2"])) * sigma_scale_raw,
            "A1_equivalent_sigma_overdispersion_scaled_au_d2": abs(float(tcfg["jpl_catalogue_A1_au_d2"])) * sigma_scale_scaled,
        })
        extra_cursor += 1
    if mcfg["yarkovsky"] and extra_cursor < len(final_values):
        a2_si = float(final_values[extra_cursor])
        a2_sigma_raw_si = float(formal_errors[extra_cursor])
        a2_sigma_scaled_si = a2_sigma_raw_si * error_inflation_factor
        summary.update({
            "A2_estimated_m_s2": a2_si,
            "A2_sigma_raw_m_s2": a2_sigma_raw_si,
            "A2_sigma_overdispersion_scaled_m_s2": a2_sigma_scaled_si,
            "A2_estimated_au_d2": m_s2_to_au_d2(a2_si),
            "A2_sigma_raw_au_d2": abs(m_s2_to_au_d2(a2_sigma_raw_si)),
            "A2_sigma_overdispersion_scaled_au_d2": abs(m_s2_to_au_d2(a2_sigma_scaled_si)),
            "A2_z_formal": safe_z(a2_si, a2_sigma_raw_si),
            "A2_z_overdispersion_scaled": safe_z(a2_si, a2_sigma_scaled_si),
            "A2_z": safe_z(a2_si, a2_sigma_scaled_si),
            "A2_physically_plausible": bool(abs(m_s2_to_au_d2(a2_si)) <= 1.0e-8),
        })

    dump_json(root / cfg["paths"]["models_directory"] / f"{tag}__summary.json", summary)
    print(json.dumps(summary, indent=2))
    if not fit_valid:
        raise RuntimeError(
            f"{target_id} {model_name}: fit failed residual sanity gates: "
            f"RMS={rms_residual_arcsec:.6g} arcsec, max={max_abs_residual_arcsec:.6g} arcsec"
        )
    return summary


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--target", required=True, choices=["2020 GE", "2021 VH2"])
    parser.add_argument("--model", required=True, choices=["M0", "M_SRP", "M_Y", "M_SY"])
    parser.add_argument("--fallback-sigma", type=float, default=1.0)
    parser.add_argument("--exclude-cluster", type=int, default=None)
    parser.add_argument("--initial-state-lead-days", type=float, default=None)
    parser.add_argument("--initial-state-anchor", choices=["direct_ssb", "earth_rebased", "sun_rebased"], default=None)
    parser.add_argument("--force-seed-policy", choices=["zero", "catalogue_priors"], default=None)
    args = parser.parse_args()

    cfg = load_config()
    root = project_root()
    slug = safe_slug(args.target)
    tag = f"{slug}__{args.model}__fallback_{args.fallback_sigma:g}"
    if args.exclude_cluster is not None:
        tag += f"__exclude_cluster_{args.exclude_cluster}"
    failure_path = root / cfg["paths"]["models_directory"] / f"{tag}__failure.json"
    try:
        run_fit(
            args.target,
            args.model,
            args.fallback_sigma,
            args.exclude_cluster,
            args.initial_state_lead_days,
            args.initial_state_anchor,
            args.force_seed_policy,
        )
        if failure_path.exists():
            failure_path.unlink()
    except Exception as exc:
        dump_json(failure_path, {
            "target_id": args.target,
            "model": args.model,
            "fallback_sigma_arcsec": args.fallback_sigma,
            "excluded_cluster": args.exclude_cluster,
            "initial_state_lead_days_override": args.initial_state_lead_days,
            "initial_state_anchor_override": args.initial_state_anchor,
            "force_seed_policy_override": args.force_seed_policy,
            "error_type": type(exc).__name__,
            "error": str(exc),
            "traceback": traceback.format_exc(),
        })
        raise


if __name__ == "__main__":
    main()
