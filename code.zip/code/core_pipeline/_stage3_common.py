from __future__ import annotations

import csv
import hashlib
import json
import math
import os
import shutil
import tempfile
import zipfile
from pathlib import Path
from typing import Any, Iterable

TARGET = "2020 GE"
PROTOCOL = "0.7.0"
EXPECTED_INPUT_SHA256 = "63b6f69bfe79a723dcd389d594c589a1d3a0db68f7c9c04bcafde6af3d82e91b"
EXPECTED_ROWS = 51
EXPECTED_FIRST_UTC = "2020-03-29T12:13:07.190Z"
EXPECTED_LAST_UTC = "2024-11-22T04:51:43.04Z"


def project_root() -> Path:
    return Path(__file__).resolve().parents[1]


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def dump_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="\n") as f:
        json.dump(data, f, indent=2, ensure_ascii=False, sort_keys=False)
        f.write("\n")


def load_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def write_csv(path: Path, rows: list[dict[str, Any]], fieldnames: list[str] | None = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if fieldnames is None:
        fieldnames = list(rows[0]) if rows else []
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def normalize_key(value: str) -> str:
    return "".join(ch for ch in value.lower() if ch.isalnum())


def find_column(columns: Iterable[str], candidates: Iterable[str], *, required: bool = True) -> str | None:
    mapping = {normalize_key(c): c for c in columns}
    for candidate in candidates:
        key = normalize_key(candidate)
        if key in mapping:
            return mapping[key]
    if required:
        raise KeyError(f"Required column not found. Tried: {list(candidates)}; available: {list(columns)}")
    return None


def finite_number(value: Any) -> bool:
    try:
        return math.isfinite(float(value))
    except (TypeError, ValueError):
        return False


def atomic_zip(source_root: Path, output_zip: Path, relative_files: list[Path]) -> dict[str, Any]:
    output_zip.parent.mkdir(parents=True, exist_ok=True)
    tmp_fd, tmp_name = tempfile.mkstemp(prefix=output_zip.stem + "_", suffix=".tmp.zip", dir=output_zip.parent)
    os.close(tmp_fd)
    tmp_path = Path(tmp_name)
    try:
        names: list[str] = []
        with zipfile.ZipFile(tmp_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
            for rel in relative_files:
                src = source_root / rel
                if not src.is_file():
                    raise FileNotFoundError(src)
                arcname = rel.as_posix()
                if arcname in names:
                    raise RuntimeError(f"Duplicate archive entry: {arcname}")
                names.append(arcname)
                zf.write(src, arcname)
        with zipfile.ZipFile(tmp_path, "r") as zf:
            bad = zf.testzip()
            if bad:
                raise RuntimeError(f"ZIP CRC failure at {bad}")
            archived_names = zf.namelist()
            if len(archived_names) != len(set(archived_names)):
                raise RuntimeError("Duplicate entries found after archive creation")
        os.replace(tmp_path, output_zip)
    finally:
        if tmp_path.exists():
            tmp_path.unlink()
    return {
        "path": str(output_zip),
        "entries": len(relative_files),
        "sha256": sha256(output_zip),
        "crc_clean": True,
    }
