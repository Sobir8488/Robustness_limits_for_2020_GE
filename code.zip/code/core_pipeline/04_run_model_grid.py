from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

import argparse
import subprocess
import sys
from darkcomet_stage2b.common import load_config, project_root


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--target", choices=["2020 GE", "2021 VH2"])
    parser.add_argument("--fallback-sigma", type=float, default=1.0)
    parser.add_argument("--continue-on-error", action="store_true")
    parser.add_argument("--initial-state-lead-days", type=float, default=None)
    parser.add_argument("--initial-state-anchor", choices=["direct_ssb", "earth_rebased", "sun_rebased"], default=None)
    parser.add_argument("--force-seed-policy", choices=["zero", "catalogue_priors"], default=None)
    args = parser.parse_args()

    cfg = load_config()
    root = project_root()
    targets = [args.target] if args.target else list(cfg["targets"])
    failures = []
    for target in targets:
        model_order = cfg["targets"][target].get("model_run_order", list(cfg["models"]))
        for model in model_order:
            cmd = [
                sys.executable,
                str(root / "scripts" / "03_run_model_family.py"),
                "--target", target,
                "--model", model,
                "--fallback-sigma", str(args.fallback_sigma),
            ]
            if args.initial_state_lead_days is not None:
                cmd += ["--initial-state-lead-days", str(args.initial_state_lead_days)]
            if args.initial_state_anchor is not None:
                cmd += ["--initial-state-anchor", str(args.initial_state_anchor)]
            if args.force_seed_policy is not None:
                cmd += ["--force-seed-policy", str(args.force_seed_policy)]
            print("\n>", " ".join(cmd), flush=True)
            completed = subprocess.run(cmd, cwd=root)
            if completed.returncode:
                failures.append((target, model))
                if not args.continue_on_error:
                    raise SystemExit(completed.returncode)
    if failures:
        print("Failures:", failures)
        raise SystemExit(1)


if __name__ == "__main__":
    main()
