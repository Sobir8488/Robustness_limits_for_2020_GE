from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

import argparse
import subprocess

from darkcomet_stage2b.common import load_config, project_root, safe_slug


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--target", choices=["2020 GE", "2021 VH2"], default="2020 GE")
    parser.add_argument("--rerun-existing", action="store_true")
    parser.add_argument("--continue-on-error", action="store_true")
    args = parser.parse_args()

    cfg = load_config()
    root = project_root()
    sigmas = [float(x) for x in cfg["weighting"]["sensitivity_fallback_sigmas_arcsec"]]
    models = ["M_SY", "M_Y"]
    failures = []
    slug = safe_slug(args.target)

    for sigma in sigmas:
        prep_cmd = [
            sys.executable, str(root / "scripts" / "01_prepare_tudat_inputs.py"),
            "--target", args.target, "--fallback-sigma", str(sigma),
        ]
        print("\n>", " ".join(prep_cmd), flush=True)
        completed = subprocess.run(prep_cmd, cwd=root)
        if completed.returncode:
            failures.append((sigma, "prepare"))
            if not args.continue_on_error:
                raise SystemExit(completed.returncode)
            continue

        for model in models:
            summary = root / cfg["paths"]["models_directory"] / f"{slug}__{model}__fallback_{sigma:g}__summary.json"
            if summary.exists() and not args.rerun_existing:
                print(f"SKIP existing {summary.relative_to(root)}", flush=True)
                continue
            cmd = [
                sys.executable, str(root / "scripts" / "03_run_model_family.py"),
                "--target", args.target, "--model", model,
                "--fallback-sigma", str(sigma),
            ]
            print("\n>", " ".join(cmd), flush=True)
            completed = subprocess.run(cmd, cwd=root)
            if completed.returncode:
                failures.append((sigma, model))
                if not args.continue_on_error:
                    raise SystemExit(completed.returncode)

        compare_cmd = [
            sys.executable, str(root / "scripts" / "05_compare_models.py"),
            "--fallback-sigma", str(sigma),
        ]
        print("\n>", " ".join(compare_cmd), flush=True)
        completed = subprocess.run(compare_cmd, cwd=root)
        if completed.returncode:
            failures.append((sigma, "compare"))
            if not args.continue_on_error:
                raise SystemExit(completed.returncode)

    summarize_cmd = [
        sys.executable, str(root / "scripts" / "13_summarize_weight_sensitivity.py"),
        "--target", args.target,
    ]
    print("\n>", " ".join(summarize_cmd), flush=True)
    completed = subprocess.run(summarize_cmd, cwd=root)
    if completed.returncode:
        failures.append(("all", "summarize"))

    if failures:
        print("Failures:", failures)
        raise SystemExit(1)


if __name__ == "__main__":
    main()
