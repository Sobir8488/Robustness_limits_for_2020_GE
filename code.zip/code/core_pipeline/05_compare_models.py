from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

import argparse
import json
import numpy as np
import pandas as pd
from darkcomet_stage2b.common import load_config, project_root, safe_slug


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--fallback-sigma", type=float, default=1.0)
    args = parser.parse_args()
    cfg = load_config()
    root = project_root()
    rows = []
    for target in cfg["targets"]:
        slug = safe_slug(target)
        for model in cfg["models"]:
            path = root / cfg["paths"]["models_directory"] / f"{slug}__{model}__fallback_{args.fallback_sigma:g}__summary.json"
            if path.exists():
                rows.append(json.loads(path.read_text(encoding="utf-8")))
    if not rows:
        raise FileNotFoundError("No model summary JSON files found")

    frame = pd.DataFrame(rows)
    if "fit_valid" not in frame:
        frame["fit_valid"] = False
    frame["model_comparison_eligible"] = frame["fit_valid"].fillna(False).astype(bool)
    frame["nested_chi2_violation"] = False
    frame["delta_bic_within_target"] = np.nan
    frame["delta_profile_bic_within_target"] = np.nan
    frame["best_bic_model"] = False
    frame["claim_eligible"] = False
    tolerance = float(cfg["fit_validation"].get("nested_chi2_tolerance", 1.0e-6))

    # First pass: enforce common data/weights and the nesting sanity condition.
    for target, idx in frame.groupby("target_id").groups.items():
        sub = frame.loc[idx]
        valid = sub.loc[sub["model_comparison_eligible"]]
        if valid.empty:
            continue
        if valid["weight_vector_sha256"].nunique(dropna=False) != 1 or valid["n_scalar"].nunique() != 1:
            frame.loc[valid.index, "model_comparison_eligible"] = False
            continue
        m0 = valid.loc[valid["model"].eq("M0"), "chi2"]
        if len(m0) == 1:
            violating = valid.index[(~valid["model"].eq("M0")) & (valid["chi2"] > float(m0.iloc[0]) + tolerance)]
            frame.loc[violating, "nested_chi2_violation"] = True
            frame.loc[violating, "model_comparison_eligible"] = False

    # Second pass: compute IC deltas only over valid, nested-consistent fits.
    for target, idx in frame.groupby("target_id").groups.items():
        valid = frame.loc[idx].loc[lambda x: x["model_comparison_eligible"]]
        if valid.empty:
            continue
        frame.loc[valid.index, "delta_bic_within_target"] = valid["bic"] - valid["bic"].min()
        if "profile_scale_bic" in valid:
            frame.loc[valid.index, "delta_profile_bic_within_target"] = (
                valid["profile_scale_bic"] - valid["profile_scale_bic"].min()
            )
        frame.loc[valid.index, "best_bic_model"] = valid["bic"].eq(valid["bic"].min())

        m0_bic = valid.loc[valid["model"].eq("M0"), "bic"]
        if len(m0_bic) == 1:
            for i, row in valid.iterrows():
                if row["model"] == "M0":
                    continue
                improvement = float(m0_bic.iloc[0] - row["bic"])
                if row["model"] == "M_SRP":
                    z = abs(float(row.get("srp_parallel_scale_z_overdispersion_scaled", np.nan)))
                    plausible = bool(row.get("srp_parallel_scale_physically_plausible", False))
                elif row["model"] == "M_Y":
                    z = abs(float(row.get("A2_z_overdispersion_scaled", np.nan)))
                    plausible = bool(row.get("A2_physically_plausible", False))
                else:
                    z = max(
                        abs(float(row.get("srp_parallel_scale_z_overdispersion_scaled", np.nan))),
                        abs(float(row.get("A2_z_overdispersion_scaled", np.nan))),
                    )
                    plausible = bool(row.get("srp_parallel_scale_physically_plausible", False)) and bool(row.get("A2_physically_plausible", False))
                frame.loc[i, "claim_eligible"] = bool(
                    np.isfinite(z)
                    and z >= float(cfg["claim_gates"]["parameter_abs_z_min"])
                    and improvement >= float(cfg["claim_gates"]["delta_bic_strong"])
                    and plausible
                )

    frame = frame.sort_values(
        ["target_id", "model_comparison_eligible", "bic"],
        ascending=[True, False, True],
    )
    out = root / cfg["paths"]["tables_directory"] / f"stage2b_model_comparison_fallback_{args.fallback_sigma:g}.csv"
    frame.to_csv(out, index=False)
    cols = [
        "target_id", "model", "fit_valid", "model_comparison_eligible", "nested_chi2_violation",
        "n_observations", "k", "chi2", "reduced_chi2", "rms_residual_arcsec",
        "aicc", "bic", "profile_scale_bic", "delta_bic_within_target",
        "delta_profile_bic_within_target", "best_bic_model", "claim_eligible",
    ]
    print(frame[[c for c in cols if c in frame.columns]].to_string(index=False))


if __name__ == "__main__":
    main()
