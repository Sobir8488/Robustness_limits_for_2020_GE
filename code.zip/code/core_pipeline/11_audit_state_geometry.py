from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

import argparse
import json
import numpy as np
import pandas as pd

from darkcomet_stage2b.common import load_config, project_root, safe_slug, dump_json
from darkcomet_stage2b.geometry_audit import (
    C_M_S,
    angular_separation_arcsec,
    observation_collection_roundtrip,
    vector_to_radec_deg,
)
from darkcomet_stage2b.horizons_identity import (
    query_cartesian_state,
    query_first_epoch_sky_check,
)
from darkcomet_stage2b.tudat_compat import create_offline_batch_mpc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--target", choices=["2020 GE", "2021 VH2"], required=True)
    parser.add_argument("--fallback-sigma", type=float, default=1.0)
    args = parser.parse_args()

    import tudatpy
    from tudatpy.interface import spice
    from tudatpy.data.horizons import HorizonsQuery
    from tudatpy.dynamics import environment_setup

    cfg = load_config()
    root = project_root()
    target_id = args.target
    tcfg = cfg["targets"][target_id]
    dcfg = cfg["dynamics"]
    slug = safe_slug(target_id)
    suffix = f"fallback_{args.fallback_sigma:g}"
    batch_path = root / cfg["paths"]["processed_directory"] / f"{slug}_batchmpc_{suffix}.csv"
    if not batch_path.exists():
        raise FileNotFoundError(f"Prepared BatchMPC input is missing: {batch_path}")

    table = pd.read_csv(batch_path)
    batch, batch_meta = create_offline_batch_mpc(
        table,
        target_id=target_id,
        observatory_cache_path=root / cfg["paths"]["observatory_cache"],
    )
    first = table.iloc[int(np.argmin(pd.to_numeric(table["epoch"], errors="raise").to_numpy(float)))]
    epoch = float(batch.epoch_start)

    spice.load_standard_kernels()
    frame_origin = str(dcfg["global_frame_origin"])
    frame_orientation = str(dcfg["global_frame_orientation"])
    body_settings = environment_setup.get_default_body_settings(
        dcfg["bodies"], frame_origin, frame_orientation
    )
    bodies = environment_setup.create_system_of_bodies(body_settings)
    observation_collection = batch.to_tudat(
        bodies=bodies,
        included_satellites=None,
        apply_weights_VFCC17=False,
        apply_star_catalog_debias=False,
    )
    collection_audit = observation_collection_roundtrip(batch, observation_collection)

    target_ssb_j2000, ssb_meta = query_cartesian_state(
        HorizonsQuery,
        target_id=target_id,
        target_cfg=tcfg,
        location="@0",
        epoch=epoch,
        frame_orientation="J2000",
    )
    target_geo_j2000, geo_meta = query_cartesian_state(
        HorizonsQuery,
        target_id=target_id,
        target_cfg=tcfg,
        location="@399",
        epoch=epoch,
        frame_orientation="J2000",
    )
    target_geo_eclip, eclip_meta = query_cartesian_state(
        HorizonsQuery,
        target_id=target_id,
        target_cfg=tcfg,
        location="@399",
        epoch=epoch,
        frame_orientation="ECLIPJ2000",
    )
    earth_ssb_j2000 = np.asarray(
        spice.get_body_cartesian_state_at_epoch(
            "Earth", "SSB", "J2000", "NONE", epoch
        ),
        dtype=float,
    ).reshape(-1)
    if earth_ssb_j2000.shape != (6,):
        raise RuntimeError(f"Unexpected Earth state shape: {earth_ssb_j2000.shape}")

    ssb_minus_earth = target_ssb_j2000 - earth_ssb_j2000
    position_difference = ssb_minus_earth[:3] - target_geo_j2000[:3]
    velocity_difference = ssb_minus_earth[3:] - target_geo_j2000[3:]
    direct_geo_ra, direct_geo_dec = vector_to_radec_deg(ssb_minus_earth[:3])
    horizons_geo_ra, horizons_geo_dec = vector_to_radec_deg(target_geo_j2000[:3])
    eclip_naive_ra, eclip_naive_dec = vector_to_radec_deg(target_geo_eclip[:3])

    first_sky = query_first_epoch_sky_check(
        HorizonsQuery,
        target_id=target_id,
        target_cfg=tcfg,
        station_code=str(first["observatory"]),
        epoch=epoch,
        observed_ra_deg=float(first["RA"]),
        observed_dec_deg=float(first["DEC"]),
    )

    position_error_m = float(np.linalg.norm(position_difference))
    velocity_error_m_s = float(np.linalg.norm(velocity_difference))
    state_angle_error_arcsec = angular_separation_arcsec(
        ssb_minus_earth[:3], target_geo_j2000[:3]
    )
    direct_distance_m = float(np.linalg.norm(ssb_minus_earth[:3]))
    horizons_distance_m = float(np.linalg.norm(target_geo_j2000[:3]))

    state_frame_gate = bool(
        position_error_m <= 5.0e7
        and velocity_error_m_s <= 100.0
        and state_angle_error_arcsec <= 60.0
        and horizons_distance_m / C_M_S <= 120.0
    )
    result = {
        "target_id": target_id,
        "protocol_version": cfg["protocol"]["frozen_protocol_version"],
        "tudatpy_version": getattr(tudatpy, "__version__", "unknown"),
        "configured_global_frame_origin": frame_origin,
        "configured_global_frame_orientation": frame_orientation,
        "epoch_tdb_s_j2000": epoch,
        "first_observation": {
            "station": str(first["observatory"]),
            "observed_ra_deg": float(first["RA"]),
            "observed_dec_deg": float(first["DEC"]),
            "horizons_station_sky_check": first_sky,
        },
        "batchmpc_compatibility": batch_meta,
        "observation_collection_roundtrip": collection_audit,
        "horizons_ssb_j2000": {
            **ssb_meta,
            "state_vector_si": target_ssb_j2000.tolist(),
        },
        "earth_ssb_j2000": {
            "state_vector_si": earth_ssb_j2000.tolist(),
            "position_norm_m": float(np.linalg.norm(earth_ssb_j2000[:3])),
            "velocity_norm_m_s": float(np.linalg.norm(earth_ssb_j2000[3:])),
        },
        "horizons_geocentric_j2000": {
            **geo_meta,
            "state_vector_si": target_geo_j2000.tolist(),
            "ra_deg_from_vector": horizons_geo_ra,
            "dec_deg_from_vector": horizons_geo_dec,
            "distance_m": horizons_distance_m,
            "one_way_light_time_s": horizons_distance_m / C_M_S,
        },
        "ssb_minus_spice_earth_j2000": {
            "state_vector_si": ssb_minus_earth.tolist(),
            "ra_deg_from_vector": direct_geo_ra,
            "dec_deg_from_vector": direct_geo_dec,
            "distance_m": direct_distance_m,
            "one_way_light_time_s": direct_distance_m / C_M_S,
        },
        "direct_vs_geocentric_consistency": {
            "position_difference_vector_m": position_difference.tolist(),
            "position_difference_norm_m": position_error_m,
            "velocity_difference_vector_m_s": velocity_difference.tolist(),
            "velocity_difference_norm_m_s": velocity_error_m_s,
            "angular_separation_arcsec": state_angle_error_arcsec,
            "state_frame_gate_pass": state_frame_gate,
        },
        "horizons_geocentric_eclipj2000_diagnostic": {
            **eclip_meta,
            "state_vector_si": target_geo_eclip.tolist(),
            "naively_interpreted_ra_deg": eclip_naive_ra,
            "naively_interpreted_dec_deg": eclip_naive_dec,
            "angular_separation_from_j2000_when_naively_compared_arcsec": angular_separation_arcsec(
                target_geo_eclip[:3], target_geo_j2000[:3]
            ),
        },
        "overall_geometry_gate_pass": bool(
            collection_audit["roundtrip_gate_pass"] and state_frame_gate
        ),
    }
    output = root / "results" / "diagnostics" / f"{slug}__state_geometry_audit.json"
    dump_json(output, result)
    print(json.dumps(result, indent=2))
    print(f"Saved: {output}")
    if not result["overall_geometry_gate_pass"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
