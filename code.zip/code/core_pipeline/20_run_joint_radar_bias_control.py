from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / 'src'
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

import argparse
import json
import math
import traceback

import numpy as np
import pandas as pd

from darkcomet_stage2b.common import ARCSEC_TO_RAD, dump_json, ensure_directories, load_config, project_root, safe_slug
from darkcomet_stage2b.joint_preflight import normalized_rms, parameter_update_diagnostics
from darkcomet_stage2b.ra_branch import normalize_ra_observation_branches, wrap_to_pi
from darkcomet_stage2b.radar_bias_control import bias_control_gate
from darkcomet_stage2b.radar_observables import normalize_longitude_deg
from darkcomet_stage2b.tudat_compat import create_offline_batch_mpc, make_rkf78_integrator

C_M_S = 299792458.0


def _load_json(path: Path):
    return json.loads(path.read_text(encoding='utf-8'))


def _station_name(code: str) -> str:
    return 'RADAR_' + str(code).replace('-', 'M').replace('+', 'P')


def _resolve_observable_type(model_settings, candidates):
    for name in candidates:
        if hasattr(model_settings, name):
            return getattr(model_settings, name), name
    raise AttributeError(f'None of the observable type names exist: {candidates}')


def _type_slice(collection, observable_type):
    mapping = collection.observable_type_start_index_and_size
    entry = mapping.get(observable_type) if hasattr(mapping, 'get') else mapping[observable_type]
    if isinstance(entry, (tuple, list, np.ndarray)) and len(entry) == 2:
        return slice(int(entry[0]), int(entry[0]) + int(entry[1]))
    raise RuntimeError(f'Unsupported observable_type_start_index_and_size entry: {entry!r}')


def _make_scalar_collection(row, obs_type, link, estimator, bodies, observations_setup, links_module, multiplier):
    settings = [observations_setup.observations_simulation_settings.tabulated_simulation_settings(
        obs_type,
        link,
        np.asarray([float(row['epoch_tdb_s_j2000'])], dtype=float),
        reference_link_end_type=links_module.receiver,
    )]
    one = observations_setup.observations_wrapper.simulate_observations(settings, estimator.observation_simulators, bodies)
    one.set_observations(np.asarray([float(row['observed_tudat_value'])], dtype=float))
    sigma = float(row['observed_tudat_sigma']) * float(multiplier)
    one.set_tabulated_weights(np.asarray([1.0 / (sigma * sigma)], dtype=float))
    return one


def _merge(collections, tudat_observations):
    merge_function = getattr(tudat_observations, 'merge_observation_collections', None)
    if callable(merge_function):
        return merge_function(collections), 'merge_observation_collections'
    merged = collections[0]
    for one in collections[1:]:
        merged.append(one)
    return merged, 'append_compatibility_fallback'


def _dynamic_seed(root: Path, cfg: dict, slug: str, model: str):
    # Use the last common no-bias accepted stage (x30), preserving a fair model comparison.
    path = root / cfg['paths']['joint_directory'] / f'{slug}__{model}__joint_homotopy_radar_sigma_x30__summary.json'
    if not path.exists():
        raise FileNotFoundError(f'Missing accepted x30 homotopy seed: {path}')
    summary = _load_json(path)
    if not bool(summary.get('homotopy_stage_gate_pass', False)):
        raise RuntimeError(f'x30 seed did not pass for {model}')
    return np.asarray(summary['final_parameter_vector'], dtype=float), str(path.relative_to(root)).replace('\\', '/')


def _build_and_run(target_id: str, model_name: str, cfg: dict) -> dict:
    from tudatpy.interface import spice
    from tudatpy.astro import element_conversion
    from tudatpy.dynamics import environment_setup, propagation_setup, parameters_setup
    from tudatpy.estimation import observable_models_setup, estimation_analysis, observations as tudat_observations, observations_setup

    root = project_root()
    slug = safe_slug(target_id)
    suffix = 'fallback_1'
    settings_cfg = cfg['radar_joint_bias_control']
    fit_pair = str(settings_cfg['fit_station_pair'])
    holdout_pair = str(settings_cfg['holdout_station_pair'])
    multiplier = float(settings_cfg['radar_sigma_multiplier'])

    model_path = root / cfg['paths']['models_directory'] / f'{slug}__{model_name}__{suffix}__summary.json'
    model_summary = _load_json(model_path)
    if not bool(model_summary.get('fit_valid', False)):
        raise RuntimeError(f'Optical {model_name} fit is not valid')

    mcfg = cfg['models'][model_name]
    dynamic_count = len(model_summary['final_parameter_vector'])
    dynamic_seed, dynamic_seed_source = _dynamic_seed(root, cfg, slug, model_name)
    if dynamic_seed.size != dynamic_count:
        raise RuntimeError('Dynamic seed size mismatch')
    dynamic_cursor = 6
    srp_seed = None
    yarkovsky_seed = None
    if mcfg['srp']:
        srp_seed = float(dynamic_seed[dynamic_cursor])
        dynamic_cursor += 1
    if mcfg['yarkovsky']:
        yarkovsky_seed = float(dynamic_seed[dynamic_cursor])
        dynamic_cursor += 1
    if dynamic_cursor != dynamic_count:
        raise RuntimeError(f'Unexpected dynamic parameter layout: consumed={dynamic_cursor}, expected={dynamic_count}')

    prepared = pd.read_csv(root / cfg['paths']['processed_directory'] / f'{slug}_prepared_{suffix}.csv')
    batch_table = pd.read_csv(root / cfg['paths']['processed_directory'] / f'{slug}_batchmpc_{suffix}.csv')
    radar = pd.read_csv(root / cfg['paths']['radar_directory'] / f'{slug}__radar_observables_tudat.csv')
    fit_radar = radar.loc[radar['station_pair'].astype(str) == fit_pair].copy()
    holdout = radar.loc[radar['station_pair'].astype(str) == holdout_pair].copy()
    if len(fit_radar) != 6 or len(holdout) != 1:
        raise RuntimeError(f'Expected 6 fit radar scalars and 1 holdout; got {len(fit_radar)} and {len(holdout)}')
    if set(fit_radar['measurement_type'].str.lower()) != {'delay', 'doppler'}:
        raise RuntimeError('Goldstone fit subset must contain delay and Doppler')

    spice.load_standard_kernels()
    batch, _ = create_offline_batch_mpc(batch_table, target_id=target_id, observatory_cache_path=root / cfg['paths']['observatory_cache'])
    batch.set_weights(prepared['weight_per_coordinate_rad_inverse2'].to_numpy(float))

    dcfg = cfg['dynamics']
    origin = dcfg['global_frame_origin']
    orientation = dcfg['global_frame_orientation']
    body_settings = environment_setup.get_default_body_settings(dcfg['bodies'], origin, orientation)
    bodies = environment_setup.create_system_of_bodies(body_settings)
    optical_collection = batch.to_tudat(bodies=bodies, included_satellites=None, apply_weights_VFCC17=False, apply_star_catalog_debias=False)
    target_name = str(batch.MPC_objects[0])
    bodies.get(target_name).mass = 1.0

    coords = _load_json(root / cfg['paths']['radar_directory'] / f'{slug}__jpl_sb_radar_station_coordinates.json')
    radar_station_map = {}
    for code in sorted(set(radar['xmit'].astype(str)) | set(radar['rcvr'].astype(str))):
        c = coords[code]
        station_name = _station_name(code)
        position = [float(c['altitude']) * 1000.0, math.radians(float(c['latitude'])), math.radians(normalize_longitude_deg(float(c['longitude'])))]
        environment_setup.add_ground_station(bodies.get_body('Earth'), station_name, position, element_conversion.geodetic_position_type)
        radar_station_map[code] = station_name

    if mcfg['srp']:
        rp_settings = environment_setup.radiation_pressure.cannonball_radiation_target(
            float(model_summary['reference_area_m2_per_1kg']), 1.0, {'Sun': ['Earth']})
        environment_setup.add_radiation_pressure_target_model(bodies, target_name, rp_settings)

    accelerations = {
        'Sun': [propagation_setup.acceleration.point_mass_gravity(), propagation_setup.acceleration.relativistic_correction(use_schwarzschild=True)],
        'Mercury': [propagation_setup.acceleration.point_mass_gravity()],
        'Venus': [propagation_setup.acceleration.point_mass_gravity()],
        'Earth': [propagation_setup.acceleration.point_mass_gravity()],
        'Moon': [propagation_setup.acceleration.point_mass_gravity()],
        'Mars': [propagation_setup.acceleration.point_mass_gravity()],
        'Jupiter': [propagation_setup.acceleration.point_mass_gravity()],
        'Saturn': [propagation_setup.acceleration.point_mass_gravity()],
        'Uranus': [propagation_setup.acceleration.point_mass_gravity()],
        'Neptune': [propagation_setup.acceleration.point_mass_gravity()],
    }
    if mcfg['srp']:
        accelerations['Sun'].append(propagation_setup.acceleration.radiation_pressure())
    if mcfg['yarkovsky']:
        accelerations['Sun'].append(propagation_setup.acceleration.yarkovsky(float(yarkovsky_seed)))
    acceleration_models = propagation_setup.create_acceleration_models(bodies, {target_name: accelerations}, [target_name], [origin])
    initial_time = float(model_summary['propagation_epoch_start_tdb_s_j2000'])
    end_time = max(float(model_summary['propagation_epoch_end_tdb_s_j2000']), float(radar['epoch_tdb_s_j2000'].max()) + 2.0 * 86400.0)
    propagator_settings = propagation_setup.propagator.translational(
        central_bodies=[origin], acceleration_models=acceleration_models, bodies_to_integrate=[target_name],
        initial_states=np.asarray(dynamic_seed[:6], dtype=float), initial_time=initial_time,
        integrator_settings=make_rkf78_integrator(propagation_setup.integrator, dcfg),
        termination_settings=propagation_setup.propagator.time_termination(end_time),
    )

    range_type, range_type_name = _resolve_observable_type(observable_models_setup.model_settings, ['n_way_range_type', 'two_way_range_type'])
    doppler_type, doppler_type_name = _resolve_observable_type(observable_models_setup.model_settings, ['two_way_instantaneous_doppler_type', 'two_way_doppler_instantaneous_type'])
    angular_type = observable_models_setup.model_settings.angular_position_type

    observation_settings = []
    for link in list(optical_collection.get_link_definitions_for_observables(angular_type)):
        observation_settings.append(observable_models_setup.model_settings.angular_position(link, bias_settings=None))

    light_time_correction = observable_models_setup.light_time_corrections.first_order_relativistic_light_time_correction(['Sun'])
    links_by_pair = {}
    fit_link = None
    for pair in sorted(radar['station_pair'].astype(str).unique()):
        xmit, rcvr = pair.split('->', 1)
        link_ends = {
            observable_models_setup.links.transmitter: observable_models_setup.links.body_reference_point_link_end_id('Earth', radar_station_map[xmit]),
            observable_models_setup.links.retransmitter: observable_models_setup.links.body_origin_link_end_id(target_name),
            observable_models_setup.links.receiver: observable_models_setup.links.body_reference_point_link_end_id('Earth', radar_station_map[rcvr]),
        }
        link = observable_models_setup.links.LinkDefinition(link_ends)
        links_by_pair[pair] = link
        if pair == fit_pair:
            fit_link = link
            range_bias_settings = observable_models_setup.biases.absolute_bias(np.asarray([0.0], dtype=float))
            doppler_bias_settings = observable_models_setup.biases.absolute_bias(np.asarray([0.0], dtype=float))
            observation_settings.append(observable_models_setup.model_settings.two_way_range(
                link, light_time_correction_settings=[light_time_correction], bias_settings=range_bias_settings))
            observation_settings.append(observable_models_setup.model_settings.two_way_doppler_instantaneous(
                link, light_time_correction_settings=[light_time_correction], bias_settings=doppler_bias_settings,
                normalized_with_speed_of_light=False))
        else:
            # Holdout is simulated but not included in the estimation collection.
            observation_settings.append(observable_models_setup.model_settings.two_way_doppler_instantaneous(
                link, light_time_correction_settings=[light_time_correction], bias_settings=None,
                normalized_with_speed_of_light=False))
    if fit_link is None:
        raise RuntimeError('Missing Goldstone fit link')

    parameter_settings = parameters_setup.initial_states(propagator_settings, bodies)
    if mcfg['srp']:
        parameter_settings.append(parameters_setup.radiation_pressure_target_direction_scaling(target_name, 'Sun'))
    if mcfg['yarkovsky']:
        parameter_settings.append(parameters_setup.yarkovsky_parameter(target_name, 'Sun'))
    parameter_settings.append(parameters_setup.absolute_observation_bias(fit_link, range_type))
    parameter_settings.append(parameters_setup.absolute_observation_bias(fit_link, doppler_type))
    parameters = parameters_setup.create_parameter_set(parameter_settings, bodies, propagator_settings)

    initial_vector = np.r_[dynamic_seed, 0.0, 0.0]
    if initial_vector.size != np.asarray(parameters.parameter_vector).size:
        raise RuntimeError(f'Bias-control parameter size mismatch: {initial_vector.size} != {np.asarray(parameters.parameter_vector).size}')

    # Tudat links estimatable observation-bias parameters to the concrete bias
    # objects while the Estimator creates its observation simulators.  Resetting
    # the full parameter vector before this point raises "parameter not linked to
    # bias object" in TudatPy 1.0.  The dynamic x30 seed has already been placed
    # in the propagator and force-model defaults above, so integrate_on_creation
    # starts from the intended warm state.  Only after the observation models
    # exist do we perform the exact consolidated-vector reset.
    estimator = estimation_analysis.Estimator(
        bodies=bodies, estimated_parameters=parameters, observation_settings=observation_settings,
        propagator_settings=propagator_settings, integrate_on_creation=True)
    parameters.parameter_vector = initial_vector.copy()
    linked_initial_vector = np.asarray(parameters.parameter_vector, dtype=float).reshape(-1)
    if not np.allclose(linked_initial_vector, initial_vector, rtol=0.0, atol=1.0e-18):
        raise RuntimeError('Post-link parameter reset verification failed')

    # Optical RA branch normalization is performed before any merge.
    tudat_observations.compute_residuals_and_dependent_variables(optical_collection, estimator.observation_simulators, bodies)
    raw_prefit = np.asarray(optical_collection.get_concatenated_residuals(), dtype=float).reshape(-1)
    original_values = np.asarray(optical_collection.concatenated_observations, dtype=float).reshape(-1)
    adjusted, branch = normalize_ra_observation_branches(original_values, raw_prefit)
    if branch['n_ra_branch_shifts'] > 0:
        optical_collection.set_observations(adjusted)
        tudat_observations.compute_residuals_and_dependent_variables(optical_collection, estimator.observation_simulators, bodies)
    verified = np.asarray(optical_collection.get_concatenated_residuals(), dtype=float).reshape(-1)
    expected = raw_prefit.copy(); expected[0::2] = wrap_to_pi(expected[0::2])
    branch_error = float(np.max(np.abs(verified - expected)))
    if branch_error > 1.0e-9:
        raise RuntimeError(f'Optical RA branch verification failed: {branch_error}')

    # Build fit and holdout collections.  Holdout remains outside EstimationInput.
    fit_scalar_collections = []
    for _, row in fit_radar.iterrows():
        obs_type = range_type if str(row['measurement_type']).lower() == 'delay' else doppler_type
        fit_scalar_collections.append(_make_scalar_collection(
            row, obs_type, links_by_pair[str(row['station_pair'])], estimator, bodies,
            observations_setup, observable_models_setup.links, multiplier))
    fit_radar_collection, _ = _merge(fit_scalar_collections, tudat_observations)

    holdout_row = holdout.iloc[0]
    holdout_collection = _make_scalar_collection(
        holdout_row, doppler_type, links_by_pair[str(holdout_row['station_pair'])], estimator, bodies,
        observations_setup, observable_models_setup.links, 1.0)
    tudat_observations.compute_residuals_and_dependent_variables(holdout_collection, estimator.observation_simulators, bodies)
    holdout_prefit_m_s = float(np.asarray(holdout_collection.get_concatenated_residuals(), dtype=float).reshape(-1)[0])

    # Initialize two nuisance parameters at weighted mean observed-minus-computed residuals.
    tudat_observations.compute_residuals_and_dependent_variables(fit_radar_collection, estimator.observation_simulators, bodies)
    fit_prefit = np.asarray(fit_radar_collection.get_concatenated_residuals(), dtype=float).reshape(-1)
    fit_weights = np.asarray(fit_radar_collection.concatenated_weights, dtype=float).reshape(-1)
    range_slice_tmp = _type_slice(fit_radar_collection, range_type)
    doppler_slice_tmp = _type_slice(fit_radar_collection, doppler_type)
    range_seed = float(np.average(fit_prefit[range_slice_tmp], weights=fit_weights[range_slice_tmp]))
    doppler_seed = float(np.average(fit_prefit[doppler_slice_tmp], weights=fit_weights[doppler_slice_tmp]))
    initial_vector[-2:] = [range_seed, doppler_seed]
    parameters.parameter_vector = initial_vector.copy()

    joint_collection, merge_method = _merge([optical_collection, fit_radar_collection], tudat_observations)
    all_obs = np.asarray(joint_collection.concatenated_observations, dtype=float).reshape(-1)
    all_weights = np.asarray(joint_collection.concatenated_weights, dtype=float).reshape(-1)
    expected_size = 2 * len(prepared) + len(fit_radar)
    reported_size = int(getattr(joint_collection, 'observation_vector_size', all_obs.size))
    partition_gate = bool(all_obs.size == expected_size and all_weights.size == expected_size and reported_size == expected_size)
    if not partition_gate:
        raise RuntimeError(f'Bias-control observation partition mismatch: obs={all_obs.size}, weights={all_weights.size}, reported={reported_size}, expected={expected_size}')

    pod_input = estimation_analysis.EstimationInput(
        observations_and_times=joint_collection,
        convergence_checker=estimation_analysis.estimation_convergence_checker(maximum_iterations=int(settings_cfg['maximum_iterations'])),
    )
    pod_input.set_weights_from_observation_collection()
    pod_input.define_estimation_settings(reintegrate_variational_equations=True)
    pod_output = estimator.perform_estimation(pod_input)

    final_vector = np.asarray(pod_output.final_parameters, dtype=float).reshape(-1)
    final_residuals = np.asarray(pod_output.final_residuals, dtype=float).reshape(-1)
    residual_history = np.asarray(pod_output.residual_history, dtype=float)
    if residual_history.ndim != 2 or residual_history.shape[0] != expected_size:
        raise RuntimeError(f'Unexpected residual-history shape {residual_history.shape}')
    joint_prefit = residual_history[:, 0].copy()
    final_weights = np.asarray(joint_collection.concatenated_weights, dtype=float).reshape(-1)

    angular_slice = _type_slice(joint_collection, angular_type)
    range_slice = _type_slice(joint_collection, range_type)
    doppler_slice = _type_slice(joint_collection, doppler_type)
    fit_radar_indices = np.r_[np.arange(range_slice.start, range_slice.stop), np.arange(doppler_slice.start, doppler_slice.stop)]
    optical_indices = np.arange(angular_slice.start, angular_slice.stop)
    fit_radar_prefit_nrms = normalized_rms(joint_prefit[fit_radar_indices], all_weights[fit_radar_indices])
    fit_radar_postfit_nrms = normalized_rms(final_residuals[fit_radar_indices], final_weights[fit_radar_indices])
    optical_postfit_rms_arcsec = float(np.sqrt(np.mean(np.square(final_residuals[optical_indices]))) / ARCSEC_TO_RAD)

    # Estimator leaves final parameters active; evaluate the independent holdout now.
    tudat_observations.compute_residuals_and_dependent_variables(holdout_collection, estimator.observation_simulators, bodies)
    holdout_postfit_m_s = float(np.asarray(holdout_collection.get_concatenated_residuals(), dtype=float).reshape(-1)[0])
    holdout_freq_hz = float(holdout_row['freq']) * 1.0e6
    holdout_prefit_hz = holdout_prefit_m_s * holdout_freq_hz / C_M_S
    holdout_postfit_hz = holdout_postfit_m_s * holdout_freq_hz / C_M_S

    optical_baseline_vector = np.asarray(model_summary['final_parameter_vector'], dtype=float)
    final_dynamic = final_vector[:dynamic_count]
    summary = {
        'target_id': target_id,
        'model': model_name,
        'protocol_version': cfg['protocol']['frozen_protocol_version'],
        'scope': 'Goldstone-only nuisance-bias joint-estimator preflight with independent Canberra-ATCA Doppler holdout',
        'runtime_success': True,
        'fit_station_pair': fit_pair,
        'holdout_station_pair': holdout_pair,
        'radar_sigma_multiplier': multiplier,
        'maximum_iterations': int(settings_cfg['maximum_iterations']),
        'n_optical_scalars': int(2 * len(prepared)),
        'n_fit_radar_scalars': int(len(fit_radar)),
        'n_holdout_radar_scalars': int(len(holdout)),
        'n_total_fit_scalars': int(expected_size),
        'n_dynamic_parameters': int(dynamic_count),
        'n_nuisance_bias_parameters': 2,
        'n_total_parameters': int(final_vector.size),
        'observation_partition_gate_pass': partition_gate,
        'collection_merge_method': merge_method,
        'reported_observation_vector_size': reported_size,
        'range_observable_type_name': range_type_name,
        'doppler_observable_type_name': doppler_type_name,
        'reference_link_end': 'receiver',
        'ra_branch_normalization': {'n_ra_branch_shifts': int(branch['n_ra_branch_shifts']), 'verification_max_error_rad': branch_error, 'verification_pass': bool(branch_error <= 1.0e-9)},
        'dynamic_seed_source': dynamic_seed_source,
        'dynamic_seed_applied_to_propagator_defaults': True,
        'srp_reference_coefficient': 1.0 if mcfg['srp'] else None,
        'srp_scaling_parameter_seed': float(srp_seed) if mcfg['srp'] else None,
        'srp_seed_application_mode': 'unit_reference_coefficient_times_single_estimatable_direction_scaling' if mcfg['srp'] else None,
        'bias_parameter_link_sequence': 'estimator_observation_models_created_before_full_parameter_reset',
        'post_link_parameter_reset_verified': True,
        'bias_seed_source': 'weighted_mean_prefit_residual_by_observable_type',
        'all_final_residuals_finite': bool(np.isfinite(final_residuals).all()),
        'total_prefit_nrms': normalized_rms(joint_prefit, all_weights),
        'total_postfit_nrms': normalized_rms(final_residuals, final_weights),
        'total_postfit_nrms_improved': bool(normalized_rms(final_residuals, final_weights) <= normalized_rms(joint_prefit, all_weights)),
        'fit_radar_prefit_nrms': fit_radar_prefit_nrms,
        'fit_radar_postfit_nrms': fit_radar_postfit_nrms,
        'fit_radar_postfit_nrms_improved': bool(fit_radar_postfit_nrms < fit_radar_prefit_nrms),
        'optical_postfit_rms_arcsec': optical_postfit_rms_arcsec,
        'initial_parameter_vector': [float(x) for x in initial_vector],
        'final_parameter_vector': [float(x) for x in final_vector],
        'dynamic_parameter_update': parameter_update_diagnostics(initial_vector[:dynamic_count], final_dynamic),
        'bias_parameter_diagnostics': {
            'range_bias_initial_m': float(initial_vector[-2]),
            'range_bias_final_m': float(final_vector[-2]),
            'range_bias_final_us_two_way': float(final_vector[-2] / C_M_S * 1.0e6),
            'doppler_bias_initial_m_s': float(initial_vector[-1]),
            'doppler_bias_final_m_s': float(final_vector[-1]),
            'doppler_bias_final_hz_at_8560MHz': float(final_vector[-1] * 8560.0e6 / C_M_S),
        },
        'force_parameter_diagnostics': {
            'A2_final_m_s2': float(final_dynamic[-1]) if mcfg['yarkovsky'] else None,
            'A2_optical_baseline_m_s2': float(optical_baseline_vector[-1]) if mcfg['yarkovsky'] else None,
            'A2_sign_consistent_with_optical_baseline': bool((not mcfg['yarkovsky']) or np.sign(final_dynamic[-1]) == np.sign(optical_baseline_vector[-1])),
            'A2_abs_ratio_to_optical_baseline': float(abs(final_dynamic[-1] / optical_baseline_vector[-1])) if mcfg['yarkovsky'] and optical_baseline_vector[-1] != 0.0 else None,
            'srp_scale_final': float(final_dynamic[-2]) if mcfg['srp'] and mcfg['yarkovsky'] else None,
        },
        'holdout_prefit_residual_m_s': holdout_prefit_m_s,
        'holdout_postfit_residual_m_s': holdout_postfit_m_s,
        'holdout_prefit_residual_hz': holdout_prefit_hz,
        'holdout_postfit_residual_hz': holdout_postfit_hz,
        'holdout_postfit_abs_residual_hz': abs(holdout_postfit_hz),
        'holdout_residual_improved': bool(abs(holdout_postfit_hz) < abs(holdout_prefit_hz)),
        'claim_boundary': 'The two Goldstone nuisance biases are conditioning controls, not physical asteroid parameters. The Canberra-ATCA datum is excluded from estimation and retained as a genuine external holdout. This preflight cannot by itself confirm A1 or A2.',
    }
    summary['bias_control_gate_pass'], summary['bias_control_gate_checks'] = bias_control_gate(summary, settings_cfg)
    return summary


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--target', default='2020 GE')
    parser.add_argument('--models', nargs='+', default=['M_SY', 'M_Y'])
    parser.add_argument('--continue-on-error', action='store_true')
    args = parser.parse_args()
    cfg = load_config(); ensure_directories(cfg)
    root = project_root(); out_dir = root / cfg['paths']['joint_directory']; out_dir.mkdir(parents=True, exist_ok=True)
    summaries, failures = {}, []
    for model in args.models:
        try:
            s = _build_and_run(args.target, model, cfg)
            summaries[model] = s
            out = out_dir / f'{safe_slug(args.target)}__{model}__joint_bias_control_radar_sigma_x{float(cfg["radar_joint_bias_control"]["radar_sigma_multiplier"]):g}__summary.json'
            dump_json(out, s)
            print(json.dumps(s, indent=2))
        except Exception as exc:
            f = {'target_id': args.target, 'model': model, 'error': str(exc), 'traceback': traceback.format_exc()}
            failures.append(f); print(json.dumps(f, indent=2))
            dump_json(out_dir / f'{safe_slug(args.target)}__{model}__joint_bias_control_failure.json', f)
            if not args.continue_on_error:
                raise
    combined = {
        'target_id': args.target,
        'protocol_version': cfg['protocol']['frozen_protocol_version'],
        'models_requested': args.models,
        'fit_station_pair': cfg['radar_joint_bias_control']['fit_station_pair'],
        'holdout_station_pair': cfg['radar_joint_bias_control']['holdout_station_pair'],
        'n_success': len(summaries),
        'n_failed': len(failures),
        'all_runs_success': bool(len(summaries) == len(args.models) and not failures),
        'all_bias_control_gates_pass': bool(summaries and not failures and all(s['bias_control_gate_pass'] for s in summaries.values())),
        'model_summaries': summaries,
        'failures': failures,
        'claim_boundary': 'Bias-controlled joint-estimator preflight only. Goldstone range/Doppler offsets are nuisance parameters; Canberra-ATCA remains an external holdout. No physical model ranking is authorized until holdout and radar-specific systematic controls are reviewed.',
    }
    dump_json(out_dir / f'{safe_slug(args.target)}__joint_bias_control_comparison.json', combined)
    print(json.dumps(combined, indent=2))


if __name__ == '__main__':
    main()
