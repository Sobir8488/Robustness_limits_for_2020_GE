from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / 'src'
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

import argparse
import importlib.util
import json
import math
import traceback

import numpy as np
import pandas as pd

from darkcomet_stage2b.common import ARCSEC_TO_RAD, dump_json, ensure_directories, load_config, project_root, safe_slug
from darkcomet_stage2b.joint_preflight import normalized_rms
from darkcomet_stage2b.ra_branch import normalize_ra_observation_branches, wrap_to_pi
from darkcomet_stage2b.radar_bias_identifiability import summarize_identifiability, weighted_constant_bias_profile
from darkcomet_stage2b.radar_observables import normalize_longitude_deg
from darkcomet_stage2b.tudat_compat import create_offline_batch_mpc, make_rkf78_integrator

C_M_S = 299792458.0

_spec = importlib.util.spec_from_file_location('bias_control_runner', ROOT / 'scripts' / '20_run_joint_radar_bias_control.py')
_bc = importlib.util.module_from_spec(_spec)
assert _spec.loader is not None
_spec.loader.exec_module(_bc)
_load_json = _bc._load_json
_station_name = _bc._station_name
_resolve_observable_type = _bc._resolve_observable_type
_make_scalar_collection = _bc._make_scalar_collection
_merge = _bc._merge
_dynamic_seed = _bc._dynamic_seed


def _bias_only_gate(summary: dict, settings: dict) -> tuple[bool, dict[str, bool]]:
    b = summary['bias_parameter_diagnostics']
    checks = {
        'runtime_success': bool(summary.get('runtime_success', False)),
        'all_final_residuals_finite': bool(summary.get('all_final_residuals_finite', False)),
        'fit_radar_nrms_improved': bool(summary.get('fit_radar_postfit_nrms_improved', False)),
        'range_bias_within_gate': abs(float(b['range_bias_final_m'])) <= float(settings['max_abs_range_bias_m']),
        'doppler_bias_within_gate': abs(float(b['doppler_bias_final_m_s'])) <= float(settings['max_abs_doppler_bias_m_s']),
        'optical_fixed_solution_preserved': bool(summary.get('optical_fixed_solution_preserved', False)),
        'holdout_unchanged': bool(summary.get('holdout_unchanged_by_station_specific_bias_only_fit', False)),
    }
    return bool(all(checks.values())), checks


def _type_slice(collection, observable_type):
    mapping = collection.observable_type_start_index_and_size
    entry = mapping.get(observable_type) if hasattr(mapping, 'get') else mapping[observable_type]
    if isinstance(entry, (tuple, list, np.ndarray)) and len(entry) == 2:
        return slice(int(entry[0]), int(entry[0]) + int(entry[1]))
    raise RuntimeError(f'Unsupported observable_type_start_index_and_size entry: {entry!r}')


def _build_bias_only(target_id: str, model_name: str, cfg: dict) -> dict:
    """Profile two constant Goldstone biases with all dynamics frozen.

    TudatPy 1.0 does not permit an OrbitDeterminationManager with propagator
    settings when the estimatable parameter set contains no dynamical
    parameters. We therefore use a normal dynamical estimator only as an
    observation simulator at the accepted x30 seed, then solve the two
    constant nuisance offsets analytically by weighted least squares. This is
    exactly the profiled optimum for one constant bias per observable type.
    """
    from tudatpy.interface import spice
    from tudatpy.astro import element_conversion
    from tudatpy.dynamics import environment_setup, propagation_setup, parameters_setup
    from tudatpy.estimation import observable_models_setup, estimation_analysis, observations as tudat_observations, observations_setup

    root = project_root(); slug = safe_slug(target_id); suffix = 'fallback_1'
    settings = cfg['radar_bias_identifiability']
    fit_pair = str(cfg['radar_joint_bias_control']['fit_station_pair'])
    holdout_pair = str(cfg['radar_joint_bias_control']['holdout_station_pair'])
    multiplier = float(cfg['radar_joint_bias_control']['radar_sigma_multiplier'])

    model_summary = _load_json(root / cfg['paths']['models_directory'] / f'{slug}__{model_name}__{suffix}__summary.json')
    if not bool(model_summary.get('fit_valid', False)):
        raise RuntimeError(f'Optical {model_name} fit is not valid')
    mcfg = cfg['models'][model_name]
    dynamic_seed, dynamic_seed_source = _dynamic_seed(root, cfg, slug, model_name)
    cursor = 6; srp_seed = None; yarkovsky_seed = None
    if mcfg['srp']:
        srp_seed = float(dynamic_seed[cursor]); cursor += 1
    if mcfg['yarkovsky']:
        yarkovsky_seed = float(dynamic_seed[cursor]); cursor += 1
    if cursor != dynamic_seed.size:
        raise RuntimeError('Unexpected dynamic parameter layout')

    prepared = pd.read_csv(root / cfg['paths']['processed_directory'] / f'{slug}_prepared_{suffix}.csv')
    batch_table = pd.read_csv(root / cfg['paths']['processed_directory'] / f'{slug}_batchmpc_{suffix}.csv')
    radar = pd.read_csv(root / cfg['paths']['radar_directory'] / f'{slug}__radar_observables_tudat.csv')
    fit_radar = radar.loc[radar['station_pair'].astype(str) == fit_pair].copy()
    holdout = radar.loc[radar['station_pair'].astype(str) == holdout_pair].copy()
    if len(fit_radar) != 6 or len(holdout) != 1:
        raise RuntimeError('Expected six Goldstone fit scalars and one Canberra-ATCA holdout')

    spice.load_standard_kernels()
    batch, _ = create_offline_batch_mpc(batch_table, target_id=target_id, observatory_cache_path=root / cfg['paths']['observatory_cache'])
    batch.set_weights(prepared['weight_per_coordinate_rad_inverse2'].to_numpy(float))
    dcfg = cfg['dynamics']; origin = dcfg['global_frame_origin']; orientation = dcfg['global_frame_orientation']
    body_settings = environment_setup.get_default_body_settings(dcfg['bodies'], origin, orientation)
    bodies = environment_setup.create_system_of_bodies(body_settings)
    optical_collection = batch.to_tudat(bodies=bodies, included_satellites=None, apply_weights_VFCC17=False, apply_star_catalog_debias=False)
    target_name = str(batch.MPC_objects[0]); bodies.get(target_name).mass = 1.0

    coords = _load_json(root / cfg['paths']['radar_directory'] / f'{slug}__jpl_sb_radar_station_coordinates.json')
    radar_station_map = {}
    for code in sorted(set(radar['xmit'].astype(str)) | set(radar['rcvr'].astype(str))):
        c = coords[code]; station_name = _station_name(code)
        position = [float(c['altitude']) * 1000.0, math.radians(float(c['latitude'])), math.radians(normalize_longitude_deg(float(c['longitude'])))]
        environment_setup.add_ground_station(bodies.get_body('Earth'), station_name, position, element_conversion.geodetic_position_type)
        radar_station_map[code] = station_name

    if mcfg['srp']:
        rp = environment_setup.radiation_pressure.cannonball_radiation_target(
            float(model_summary['reference_area_m2_per_1kg']), 1.0, {'Sun': ['Earth']})
        environment_setup.add_radiation_pressure_target_model(bodies, target_name, rp)
    accelerations = {
        'Sun': [propagation_setup.acceleration.point_mass_gravity(), propagation_setup.acceleration.relativistic_correction(use_schwarzschild=True)],
        'Mercury': [propagation_setup.acceleration.point_mass_gravity()], 'Venus': [propagation_setup.acceleration.point_mass_gravity()],
        'Earth': [propagation_setup.acceleration.point_mass_gravity()], 'Moon': [propagation_setup.acceleration.point_mass_gravity()],
        'Mars': [propagation_setup.acceleration.point_mass_gravity()], 'Jupiter': [propagation_setup.acceleration.point_mass_gravity()],
        'Saturn': [propagation_setup.acceleration.point_mass_gravity()], 'Uranus': [propagation_setup.acceleration.point_mass_gravity()],
        'Neptune': [propagation_setup.acceleration.point_mass_gravity()],
    }
    if mcfg['srp']:
        accelerations['Sun'].append(propagation_setup.acceleration.radiation_pressure())
    if mcfg['yarkovsky']:
        accelerations['Sun'].append(propagation_setup.acceleration.yarkovsky(float(yarkovsky_seed)))
    acceleration_models = propagation_setup.create_acceleration_models(bodies, {target_name: accelerations}, [target_name], [origin])
    initial_time = float(model_summary['propagation_epoch_start_tdb_s_j2000'])
    end_time = max(float(model_summary['propagation_epoch_end_tdb_s_j2000']), float(radar['epoch_tdb_s_j2000'].max()) + 2.0 * 86400.0)
    propagator_settings = propagation_setup.propagator.translational(
        central_bodies=[origin], acceleration_models=acceleration_models, bodies_to_integrate=[target_name],
        initial_states=np.asarray(dynamic_seed[:6], dtype=float), initial_time=initial_time,
        integrator_settings=make_rkf78_integrator(propagation_setup.integrator, dcfg),
        termination_settings=propagation_setup.propagator.time_termination(end_time),
    )

    range_type, range_type_name = _resolve_observable_type(observable_models_setup.model_settings, ['n_way_range_type', 'two_way_range_type'])
    doppler_type, doppler_type_name = _resolve_observable_type(observable_models_setup.model_settings, ['two_way_instantaneous_doppler_type', 'two_way_doppler_instantaneous_type'])
    angular_type = observable_models_setup.model_settings.angular_position_type
    observation_settings = [observable_models_setup.model_settings.angular_position(link, bias_settings=None) for link in optical_collection.get_link_definitions_for_observables(angular_type)]
    correction = observable_models_setup.light_time_corrections.first_order_relativistic_light_time_correction(['Sun'])
    links_by_pair = {}
    for pair in sorted(radar['station_pair'].astype(str).unique()):
        xmit, rcvr = pair.split('->', 1)
        ends = {
            observable_models_setup.links.transmitter: observable_models_setup.links.body_reference_point_link_end_id('Earth', radar_station_map[xmit]),
            observable_models_setup.links.retransmitter: observable_models_setup.links.body_origin_link_end_id(target_name),
            observable_models_setup.links.receiver: observable_models_setup.links.body_reference_point_link_end_id('Earth', radar_station_map[rcvr]),
        }
        link = observable_models_setup.links.LinkDefinition(ends); links_by_pair[pair] = link
        observation_settings.append(observable_models_setup.model_settings.two_way_range(link, light_time_correction_settings=[correction], bias_settings=None))
        observation_settings.append(observable_models_setup.model_settings.two_way_doppler_instantaneous(link, light_time_correction_settings=[correction], bias_settings=None, normalized_with_speed_of_light=False))

    # Dynamic parameters are present only so Tudat can integrate the accepted x30 trajectory.
    # They are never estimated in this control.
    parameter_settings = parameters_setup.initial_states(propagator_settings, bodies)
    if mcfg['srp']:
        parameter_settings.append(parameters_setup.radiation_pressure_target_direction_scaling(target_name, 'Sun'))
    if mcfg['yarkovsky']:
        parameter_settings.append(parameters_setup.yarkovsky_parameter(target_name, 'Sun'))
    parameters = parameters_setup.create_parameter_set(parameter_settings, bodies, propagator_settings)
    if np.asarray(parameters.parameter_vector).size != dynamic_seed.size:
        raise RuntimeError('Dynamic simulator parameter size mismatch')
    parameters.parameter_vector = dynamic_seed.copy()
    estimator = estimation_analysis.Estimator(
        bodies=bodies, estimated_parameters=parameters, observation_settings=observation_settings,
        propagator_settings=propagator_settings, integrate_on_creation=True)

    tudat_observations.compute_residuals_and_dependent_variables(optical_collection, estimator.observation_simulators, bodies)
    raw_optical = np.asarray(optical_collection.get_concatenated_residuals(), dtype=float).reshape(-1)
    original = np.asarray(optical_collection.concatenated_observations, dtype=float).reshape(-1)
    adjusted, branch = normalize_ra_observation_branches(original, raw_optical)
    if branch['n_ra_branch_shifts'] > 0:
        optical_collection.set_observations(adjusted)
        tudat_observations.compute_residuals_and_dependent_variables(optical_collection, estimator.observation_simulators, bodies)
    optical_prefit = np.asarray(optical_collection.get_concatenated_residuals(), dtype=float).reshape(-1)
    branch_error = float(np.max(np.abs(wrap_to_pi(adjusted - original))))
    if branch_error > 1.0e-9:
        raise RuntimeError('RA branch equivalence verification failed')

    fit_parts = []
    for _, row in fit_radar.iterrows():
        typ = range_type if str(row['measurement_type']).lower() == 'delay' else doppler_type
        fit_parts.append(_make_scalar_collection(row, typ, links_by_pair[str(row['station_pair'])], estimator, bodies, observations_setup, observable_models_setup.links, multiplier))
    fit_collection, merge_method = _merge(fit_parts, tudat_observations)
    holdout_row = holdout.iloc[0]
    holdout_collection = _make_scalar_collection(holdout_row, doppler_type, links_by_pair[str(holdout_row['station_pair'])], estimator, bodies, observations_setup, observable_models_setup.links, 1.0)

    tudat_observations.compute_residuals_and_dependent_variables(fit_collection, estimator.observation_simulators, bodies)
    raw_fit = np.asarray(fit_collection.get_concatenated_residuals(), dtype=float).reshape(-1)
    weights = np.asarray(fit_collection.concatenated_weights, dtype=float).reshape(-1)
    range_slice = _type_slice(fit_collection, range_type)
    doppler_slice = _type_slice(fit_collection, doppler_type)

    # Exact weighted least-squares profile for one constant offset per observable type.
    profile = weighted_constant_bias_profile(
        raw_fit, weights, {'range': range_slice, 'doppler': doppler_slice}
    )
    range_bias = float(profile['biases']['range'])
    doppler_bias = float(profile['biases']['doppler'])
    postfit = np.asarray(profile['profiled_residuals'], dtype=float)

    tudat_observations.compute_residuals_and_dependent_variables(holdout_collection, estimator.observation_simulators, bodies)
    holdout_prefit_m_s = float(np.asarray(holdout_collection.get_concatenated_residuals(), dtype=float).reshape(-1)[0])
    holdout_postfit_m_s = holdout_prefit_m_s  # Goldstone-only biases cannot change a different link.
    holdout_freq = float(holdout_row['freq']) * 1.0e6

    optical_prefit_rms = float(np.sqrt(np.mean(np.square(optical_prefit))) / ARCSEC_TO_RAD)
    optical_postfit_rms = optical_prefit_rms
    optical_preserved = True
    summary = {
        'target_id': target_id, 'model': model_name, 'protocol_version': cfg['protocol']['frozen_protocol_version'],
        'scope': 'Goldstone nuisance-only analytic identifiability control with dynamics fixed at the accepted x30 seed',
        'runtime_success': True, 'fit_station_pair': fit_pair, 'holdout_station_pair': holdout_pair,
        'radar_sigma_multiplier': multiplier, 'maximum_iterations': 0,
        'n_fit_radar_scalars': int(len(fit_radar)), 'n_estimated_parameters': 2,
        'dynamic_seed_source': dynamic_seed_source, 'dynamics_frozen': True,
        'dynamic_simulator_parameter_count': int(dynamic_seed.size),
        'dynamic_parameters_used_for_simulation_only': True,
        'srp_reference_coefficient': 1.0 if mcfg['srp'] else None,
        'srp_scaling_parameter_seed': float(srp_seed) if mcfg['srp'] else None,
        'srp_seed_application_mode': 'unit_reference_coefficient_times_single_estimatable_direction_scaling' if mcfg['srp'] else None,
        'analytic_profile_solver': 'weighted_mean_residual_by_observable_type',
        'estimator_role': 'observation_simulation_only_at_frozen_dynamic_seed',
        'collection_merge_method': merge_method, 'range_observable_type_name': range_type_name,
        'doppler_observable_type_name': doppler_type_name, 'reference_link_end': 'receiver',
        'ra_branch_normalization': {'n_ra_branch_shifts': int(branch['n_ra_branch_shifts']), 'verification_max_error_rad': branch_error, 'verification_pass': True},
        'all_final_residuals_finite': bool(np.isfinite(postfit).all()),
        'fit_radar_raw_prefit_nrms': normalized_rms(raw_fit, weights),
        'fit_radar_seeded_prefit_nrms': normalized_rms(postfit, weights),
        'fit_radar_postfit_nrms': normalized_rms(postfit, weights),
        'fit_radar_postfit_nrms_improved': bool(normalized_rms(postfit, weights) < normalized_rms(raw_fit, weights)),
        'optical_prefit_rms_arcsec': optical_prefit_rms, 'optical_postfit_rms_arcsec': optical_postfit_rms,
        'optical_fixed_solution_preserved': optical_preserved,
        'initial_parameter_vector': [0.0, 0.0], 'final_parameter_vector': [range_bias, doppler_bias],
        'bias_parameter_diagnostics': {
            'range_bias_initial_m': 0.0, 'range_bias_final_m': range_bias,
            'range_bias_final_us_two_way': float(range_bias / C_M_S * 1.0e6),
            'doppler_bias_initial_m_s': 0.0, 'doppler_bias_final_m_s': doppler_bias,
            'doppler_bias_final_hz_at_8560MHz': float(doppler_bias * 8560.0e6 / C_M_S),
        },
        'fixed_force_parameters': {
            'A2_m_s2': float(yarkovsky_seed) if yarkovsky_seed is not None else None,
            'srp_scale': float(srp_seed) if srp_seed is not None else None,
        },
        'holdout_prefit_residual_hz': float(holdout_prefit_m_s * holdout_freq / C_M_S),
        'holdout_postfit_residual_hz': float(holdout_postfit_m_s * holdout_freq / C_M_S),
        'holdout_unchanged_by_station_specific_bias_only_fit': True,
        'claim_boundary': 'This control analytically profiles only two Goldstone nuisance biases. The dynamical state and nongravitational parameters remain frozen and no physical detection claim is authorized.',
    }
    summary['bias_only_gate_pass'], summary['bias_only_gate_checks'] = _bias_only_gate(summary, settings)
    return summary


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--target', default='2020 GE')
    parser.add_argument('--models', nargs='+', default=['M_SY', 'M_Y'])
    parser.add_argument('--continue-on-error', action='store_true')
    args = parser.parse_args(); cfg = load_config(); ensure_directories(cfg)
    root = project_root(); out_dir = root / cfg['paths']['joint_directory']; out_dir.mkdir(parents=True, exist_ok=True)
    bias_only = {}; failures = []
    for model in args.models:
        try:
            s = _build_bias_only(args.target, model, cfg); bias_only[model] = s
            dump_json(out_dir / f'{safe_slug(args.target)}__{model}__radar_bias_only_identifiability_summary.json', s)
            print(json.dumps(s, indent=2))
        except Exception as exc:
            f = {'target_id': args.target, 'model': model, 'error': str(exc), 'traceback': traceback.format_exc()}
            failures.append(f); print(json.dumps(f, indent=2))
            if not args.continue_on_error:
                raise
    dynamic_bias = {}
    for model in args.models:
        p = out_dir / f'{safe_slug(args.target)}__{model}__joint_bias_control_radar_sigma_x30__summary.json'
        if p.exists():
            dynamic_bias[model] = _load_json(p)
    if len(bias_only) == len(args.models) and len(dynamic_bias) == len(args.models):
        combined = summarize_identifiability(bias_only, dynamic_bias, cfg['radar_bias_identifiability'])
    else:
        combined = {'model_results': {}, 'publication_joint_radar_claim_ready': False, 'claim_boundary': 'Incomplete runtime products.'}
    combined.update({
        'target_id': args.target, 'protocol_version': cfg['protocol']['frozen_protocol_version'],
        'models_requested': args.models, 'n_success': len(bias_only), 'n_failed': len(failures),
        'all_runs_success': bool(len(bias_only) == len(args.models) and not failures), 'failures': failures,
    })
    dump_json(out_dir / f'{safe_slug(args.target)}__radar_bias_identifiability_summary.json', combined)
    print(json.dumps(combined, indent=2))


if __name__ == '__main__':
    main()
