from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

import argparse
import json
import pandas as pd

from darkcomet_stage2b.common import load_config, project_root
from darkcomet_stage2b.tudat_compat import load_observatory_table


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--refresh", action="store_true")
    args = parser.parse_args()

    cfg = load_config()
    root = project_root()
    processed = root / cfg["paths"]["processed_directory"]
    station_codes: set[str] = set()
    for path in sorted(processed.glob("*_batchmpc_*.csv")):
        table = pd.read_csv(path, dtype={"observatory": str})
        if "observatory" in table.columns:
            station_codes.update(table["observatory"].astype(str).str.strip().str.zfill(3))

    cache_path = root / cfg["paths"]["observatory_cache"]
    table, metadata = load_observatory_table(
        cache_path,
        required_codes=sorted(station_codes),
        refresh=args.refresh,
    )
    metadata["cached_station_codes_used_by_inputs"] = sorted(station_codes)
    metadata["cache_rows"] = int(len(table))
    print(json.dumps(metadata, indent=2))


if __name__ == "__main__":
    main()
