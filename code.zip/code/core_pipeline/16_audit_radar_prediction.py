from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

import argparse
import json
import math
import traceback

import numpy as np
import pandas as pd

from darkcomet_stage2b.common import (
    dump_json,
    ensure_directories,
    load_config,
    project_root,
    safe_slug,
)
from darkcomet_stage2b.radar_observables import (
    SPEED_OF_LIGHT_M_S,
    normalize_longitude_deg,
    two_way_doppler_m_s_to_hz,
    two_way_range_m_to_delay_us,
)
from darkcomet_stage2b.tudat_compat import create_offline_batch_mpc, make_rkf78_integrator


def _resolve_observable_type(model_settings, candidates):
    for name in candidates:
        if hasattr(model_settings, name):
            return getattr(model_settings, name), name
    raise AttributeError(f"None of the observable type names exist: {candidates}")


def _station_name(code: str) -> str:
    return "RADAR_" + str(code).replace("-", "M").replace("+", "P")


def _load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def _build_environment_and_estimator(target_id: str, model_name: str, radar: pd.DataFrame, cfg: dict):
    from tudatpy.interface import spice
    from tudatpy.astro import element_conversion
    from tudatpy.dynamics import environment_setup, propagation_setup, parameters_setup
    from tudatpy.estimation import observable_models_setup, estimation_analysis

    root = project_root()
    slug = safe_slug(target_id)
    suffix = "fallback_1"
    model_path = root / cfg["paths"]["models_directory"] / f"{slug}__{model_name}__{suffix}__summary.json"
    if not model_path.exists():
        raise FileNotFoundError(model_path)
    model_summary = _load_json(model_path)
    if not bool(model_summary.get("fit_valid", False)):
        raise RuntimeError(f"{model_name} optical fit is not valid")

    optical_batch_path = root / cfg["paths"]["processed_directory"] / f"{slug}_batchmpc_{suffix}.csv"
    if not optical_batch_path.exists():
        raise FileNotFoundError(optical_batch_path)
    optical_batch_table = pd.read_csv(optical_batch_path)

    spice.load_standard_kernels()
    batch, _ = create_offline_batch_mpc(
        optical_batch_table,
        target_id=target_id,
        observatory_cache_path=root / cfg["paths"]["observatory_cache"],
    )

    dcfg = cfg["dynamics"]
    origin = dcfg["global_frame_origin"]
    orientation = dcfg["global_frame_orientation"]
    body_settings = environment_setup.get_default_body_settings(
        dcfg["bodies"], origin, orientation
    )
    bodies = environment_setup.create_system_of_bodies(body_settings)
    # BatchMPC adds the asteroid body and optical observatory interfaces.
    batch.to_tudat(
        bodies=bodies,
        included_satellites=None,
        apply_weights_VFCC17=False,
        apply_star_catalog_debias=False,
    )
    target_name = str(batch.MPC_objects[0])
    bodies.get(target_name).mass = 1.0

    coords_path = root / cfg["paths"]["radar_directory"] / f"{slug}__jpl_sb_radar_station_coordinates.json"
    coords = _load_json(coords_path)
    radar_station_map = {}
    for code in sorted(set(radar["xmit"].astype(str)) | set(radar["rcvr"].astype(str))):
        if code not in coords:
            raise KeyError(f"Missing radar station coordinates for {code}")
        c = coords[code]
        station_name = _station_name(code)
        position = [
            float(c["altitude"]) * 1000.0,
            math.radians(float(c["latitude"])),
            math.radians(normalize_longitude_deg(float(c["longitude"]))),
        ]
        environment_setup.add_ground_station(
            bodies.get_body("Earth"),
            station_name,
            position,
            element_conversion.geodetic_position_type,
        )
        radar_station_map[code] = station_name

    mcfg = cfg["models"][model_name]
    if mcfg["srp"]:
        reference_area = float(model_summary["reference_area_m2_per_1kg"])
        rp_settings = environment_setup.radiation_pressure.cannonball_radiation_target(
            reference_area, 1.0, {"Sun": ["Earth"]}
        )
        environment_setup.add_radiation_pressure_target_model(
            bodies, target_name, rp_settings
        )

    accelerations = {
        "Sun": [
            propagation_setup.acceleration.point_mass_gravity(),
            propagation_setup.acceleration.relativistic_correction(use_schwarzschild=True),
        ],
        "Mercury": [propagation_setup.acceleration.point_mass_gravity()],
        "Venus": [propagation_setup.acceleration.point_mass_gravity()],
        "Earth": [propagation_setup.acceleration.point_mass_gravity()],
        "Moon": [propagation_setup.acceleration.point_mass_gravity()],
        "Mars": [propagation_setup.acceleration.point_mass_gravity()],
        "Jupiter": [propagation_setup.acceleration.point_mass_gravity()],
        "Saturn": [propagation_setup.acceleration.point_mass_gravity()],
        "Uranus": [propagation_setup.acceleration.point_mass_gravity()],
        "Neptune": [propagation_setup.acceleration.point_mass_gravity()],
    }
    if mcfg["srp"]:
        accelerations["Sun"].append(propagation_setup.acceleration.radiation_pressure())
    if mcfg["yarkovsky"]:
        accelerations["Sun"].append(
            propagation_setup.acceleration.yarkovsky(
                float(model_summary["A2_estimated_m_s2"])
            )
        )

    acceleration_models = propagation_setup.create_acceleration_models(
        bodies,
        {target_name: accelerations},
        [target_name],
        [origin],
    )
    initial_time = float(model_summary["propagation_epoch_start_tdb_s_j2000"])
    radar_end = float(radar["epoch_tdb_s_j2000"].max()) + 2.0 * 86400.0
    end_time = max(float(model_summary["propagation_epoch_end_tdb_s_j2000"]), radar_end)
    integrator = make_rkf78_integrator(propagation_setup.integrator, dcfg)
    propagator_settings = propagation_setup.propagator.translational(
        central_bodies=[origin],
        acceleration_models=acceleration_models,
        bodies_to_integrate=[target_name],
        initial_states=np.asarray(model_summary["final_parameter_vector"][:6], dtype=float),
        initial_time=initial_time,
        integrator_settings=integrator,
        termination_settings=propagation_setup.propagator.time_termination(end_time),
    )

    parameter_settings = parameters_setup.initial_states(propagator_settings, bodies)
    if mcfg["srp"]:
        parameter_settings.append(
            parameters_setup.radiation_pressure_target_direction_scaling(target_name, "Sun")
        )
    if mcfg["yarkovsky"]:
        parameter_settings.append(parameters_setup.yarkovsky_parameter(target_name, "Sun"))
    parameters = parameters_setup.create_parameter_set(
        parameter_settings, bodies, propagator_settings
    )
    final_vector = np.asarray(model_summary["final_parameter_vector"], dtype=float)
    if final_vector.size != np.asarray(parameters.parameter_vector).size:
        raise RuntimeError(
            f"Parameter length mismatch for {model_name}: "
            f"summary={final_vector.size}, runtime={np.asarray(parameters.parameter_vector).size}"
        )
    parameters.parameter_vector = final_vector

    light_time_correction = (
        observable_models_setup.light_time_corrections
        .first_order_relativistic_light_time_correction(["Sun"])
    )
    settings = []
    links_by_pair = {}
    for pair in sorted(radar["station_pair"].astype(str).unique()):
        xmit, rcvr = pair.split("->", 1)
        link_ends = {
            observable_models_setup.links.transmitter:
                observable_models_setup.links.body_reference_point_link_end_id(
                    "Earth", radar_station_map[xmit]
                ),
            observable_models_setup.links.retransmitter:
                observable_models_setup.links.body_origin_link_end_id(target_name),
            observable_models_setup.links.receiver:
                observable_models_setup.links.body_reference_point_link_end_id(
                    "Earth", radar_station_map[rcvr]
                ),
        }
        link = observable_models_setup.links.LinkDefinition(link_ends)
        links_by_pair[pair] = link
        settings.append(
            observable_models_setup.model_settings.two_way_range(
                link, light_time_correction_settings=[light_time_correction]
            )
        )
        settings.append(
            observable_models_setup.model_settings.two_way_doppler_instantaneous(
                link,
                light_time_correction_settings=[light_time_correction],
                normalized_with_speed_of_light=False,
            )
        )

    estimator = estimation_analysis.Estimator(
        bodies=bodies,
        estimated_parameters=parameters,
        observation_settings=settings,
        propagator_settings=propagator_settings,
        integrate_on_creation=True,
    )
    type_range, type_range_name = _resolve_observable_type(
        observable_models_setup.model_settings,
        ["n_way_range_type", "two_way_range_type"],
    )
    type_doppler, type_doppler_name = _resolve_observable_type(
        observable_models_setup.model_settings,
        ["two_way_instantaneous_doppler_type", "two_way_doppler_instantaneous_type"],
    )
    return {
        "bodies": bodies,
        "estimator": estimator,
        "links_by_pair": links_by_pair,
        "type_range": type_range,
        "type_range_name": type_range_name,
        "type_doppler": type_doppler,
        "type_doppler_name": type_doppler_name,
        "target_name": target_name,
        "model_summary": model_summary,
        "radar_station_map": radar_station_map,
    }


def _simulate_one(context: dict, row: pd.Series) -> float:
    from tudatpy.estimation import observable_models_setup, observations_setup

    obs_type = (
        context["type_range"]
        if str(row["measurement_type"]).lower() == "delay"
        else context["type_doppler"]
    )
    simulation_settings = [
        observations_setup.observations_simulation_settings.tabulated_simulation_settings(
            obs_type,
            context["links_by_pair"][str(row["station_pair"])],
            np.asarray([float(row["epoch_tdb_s_j2000"])], dtype=float),
            reference_link_end_type=observable_models_setup.links.receiver,
        )
    ]
    collection = observations_setup.observations_wrapper.simulate_observations(
        simulation_settings,
        context["estimator"].observation_simulators,
        context["bodies"],
    )
    values = np.asarray(collection.concatenated_observations, dtype=float).reshape(-1)
    if values.size != 1:
        raise RuntimeError(f"Expected one simulated scalar, received {values.size}")
    return float(values[0])


def run_model(target_id: str, model_name: str, cfg: dict) -> dict:
    root = project_root()
    slug = safe_slug(target_id)
    radar_path = root / cfg["paths"]["radar_directory"] / f"{slug}__radar_observables_tudat.csv"
    radar = pd.read_csv(radar_path)
    if not bool(radar["direct_fit_eligible"].astype(bool).all()):
        raise RuntimeError("Not all radar records are direct-fit eligible")

    context = _build_environment_and_estimator(target_id, model_name, radar, cfg)
    predicted = []
    for _, row in radar.iterrows():
        predicted.append(_simulate_one(context, row))
    out = radar.copy()
    out["model"] = model_name
    out["predicted_tudat_value"] = np.asarray(predicted, dtype=float)
    out["residual_tudat_value_observed_minus_predicted"] = (
        out["observed_tudat_value"].to_numpy(float)
        - out["predicted_tudat_value"].to_numpy(float)
    )
    out["normalized_residual"] = (
        out["residual_tudat_value_observed_minus_predicted"].to_numpy(float)
        / out["observed_tudat_sigma"].to_numpy(float)
    )
    out["predicted_native_value"] = np.nan
    out["residual_native_observed_minus_predicted"] = np.nan
    out["native_units"] = out["units"].astype(str)
    out["opposite_sign_predicted_native_value"] = np.nan
    out["opposite_sign_abs_residual_native"] = np.nan

    delay = out["measurement_type"].eq("delay")
    doppler = out["measurement_type"].eq("doppler")
    out.loc[delay, "predicted_native_value"] = two_way_range_m_to_delay_us(
        out.loc[delay, "predicted_tudat_value"].to_numpy(float)
    )
    out.loc[delay, "residual_native_observed_minus_predicted"] = (
        out.loc[delay, "value"].to_numpy(float)
        - out.loc[delay, "predicted_native_value"].to_numpy(float)
    )
    predicted_hz = two_way_doppler_m_s_to_hz(
        out.loc[doppler, "predicted_tudat_value"].to_numpy(float),
        out.loc[doppler, "freq"].to_numpy(float),
    )
    out.loc[doppler, "predicted_native_value"] = predicted_hz
    out.loc[doppler, "residual_native_observed_minus_predicted"] = (
        out.loc[doppler, "value"].to_numpy(float) - predicted_hz
    )
    out.loc[doppler, "opposite_sign_predicted_native_value"] = -predicted_hz
    out.loc[doppler, "opposite_sign_abs_residual_native"] = np.abs(
        out.loc[doppler, "value"].to_numpy(float) + predicted_hz
    )

    direct_doppler_chi2 = float(np.sum(np.square(
        out.loc[doppler, "residual_native_observed_minus_predicted"].to_numpy(float)
        / out.loc[doppler, "sigma"].to_numpy(float)
    ))) if bool(doppler.any()) else 0.0
    opposite_doppler_chi2 = float(np.sum(np.square(
        (out.loc[doppler, "value"].to_numpy(float) + predicted_hz)
        / out.loc[doppler, "sigma"].to_numpy(float)
    ))) if bool(doppler.any()) else 0.0

    rcfg = cfg["radar_validation"]
    delay_limit = float(rcfg["coarse_delay_residual_limit_us"])
    doppler_limit = float(rcfg["coarse_doppler_residual_limit_hz"])
    sign_factor = float(rcfg["doppler_sign_preference_factor"])
    max_delay = float(np.max(np.abs(
        out.loc[delay, "residual_native_observed_minus_predicted"].to_numpy(float)
    ))) if bool(delay.any()) else None
    max_doppler = float(np.max(np.abs(
        out.loc[doppler, "residual_native_observed_minus_predicted"].to_numpy(float)
    ))) if bool(doppler.any()) else None
    sign_gate = bool(
        opposite_doppler_chi2 >= sign_factor * max(direct_doppler_chi2, 1.0e-30)
    ) if bool(doppler.any()) else True
    summary = {
        "target_id": target_id,
        "model": model_name,
        "protocol_version": cfg["protocol"]["frozen_protocol_version"],
        "n_records": int(len(out)),
        "n_delay": int(delay.sum()),
        "n_doppler": int(doppler.sum()),
        "range_observable_type_name": context["type_range_name"],
        "doppler_observable_type_name": context["type_doppler_name"],
        "reference_link_end": "receiver",
        "epoch_semantics": "UTC echo reception epoch converted to TDB",
        "first_order_solar_relativistic_light_time_correction": True,
        "max_abs_delay_residual_us": max_delay,
        "max_abs_doppler_residual_hz": max_doppler,
        "delay_rms_residual_us": float(np.sqrt(np.mean(np.square(
            out.loc[delay, "residual_native_observed_minus_predicted"].to_numpy(float)
        )))) if bool(delay.any()) else None,
        "doppler_rms_residual_hz": float(np.sqrt(np.mean(np.square(
            out.loc[doppler, "residual_native_observed_minus_predicted"].to_numpy(float)
        )))) if bool(doppler.any()) else None,
        "radar_chi2": float(np.sum(np.square(out["normalized_residual"].to_numpy(float)))),
        "radar_normalized_residual_rms": float(np.sqrt(np.mean(np.square(
            out["normalized_residual"].to_numpy(float)
        )))),
        "direct_doppler_sign_chi2": direct_doppler_chi2,
        "opposite_doppler_sign_chi2": opposite_doppler_chi2,
        "doppler_sign_convention_gate_pass": sign_gate,
        "coarse_delay_closure_limit_us": delay_limit,
        "coarse_doppler_closure_limit_hz": doppler_limit,
        "coarse_delay_closure_pass": bool(max_delay is None or max_delay <= delay_limit),
        "coarse_doppler_closure_pass": bool(max_doppler is None or max_doppler <= doppler_limit),
        "prediction_closure_gate_pass": bool(
            (max_delay is None or max_delay <= delay_limit)
            and (max_doppler is None or max_doppler <= doppler_limit)
            and sign_gate
        ),
        "claim_boundary": (
            "Prediction-only closure uses the frozen optical best-fit parameters without "
            "refitting to radar. The coarse gate is an implementation and gross-ephemeris "
            "check, not a meter-level radar fit. Tropospheric/ionospheric calibration, Earth "
            "orientation refinements, and radar-specific editing remain required before joint estimation."
        ),
    }
    out_csv = root / cfg["paths"]["tables_directory"] / f"{slug}__{model_name}__radar_prediction_residuals.csv"
    out_json = root / cfg["paths"]["tables_directory"] / f"{slug}__{model_name}__radar_prediction_summary.json"
    out.to_csv(out_csv, index=False)
    dump_json(out_json, summary)
    return summary


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--target", default="2020 GE")
    parser.add_argument("--models", nargs="+", default=["M_SY", "M_Y"])
    args = parser.parse_args()

    cfg = load_config()
    ensure_directories(cfg)
    root = project_root()
    slug = safe_slug(args.target)
    summaries = []
    failures = []
    for model in args.models:
        try:
            summaries.append(run_model(args.target, model, cfg))
        except Exception as exc:
            failure = {
                "target_id": args.target,
                "model": model,
                "error": str(exc),
                "traceback": traceback.format_exc(),
            }
            failures.append(failure)
            dump_json(
                root / cfg["paths"]["tables_directory"] / f"{slug}__{model}__radar_prediction_failure.json",
                failure,
            )

    combined = {
        "target_id": args.target,
        "protocol_version": cfg["protocol"]["frozen_protocol_version"],
        "models_requested": args.models,
        "n_success": len(summaries),
        "n_failed": len(failures),
        "model_summaries": {s["model"]: s for s in summaries},
        "all_prediction_runs_success": len(failures) == 0,
        "all_coarse_closure_gates_pass": bool(
            summaries and len(failures) == 0 and all(s["prediction_closure_gate_pass"] for s in summaries)
        ),
        "preferred_by_radar_prediction_chi2": (
            min(summaries, key=lambda x: x["radar_chi2"])["model"] if summaries else None
        ),
        "claim_boundary": (
            "This is an out-of-sample prediction audit using optical-only fitted parameters. "
            "It is not a joint optical-radar parameter estimate."
        ),
    }
    combined_path = root / cfg["paths"]["tables_directory"] / f"{slug}__radar_prediction_comparison.json"
    dump_json(combined_path, combined)

    lines = [
        f"# {args.target} optical-to-radar prediction audit",
        "",
        f"- Protocol: {combined['protocol_version']}",
        f"- Successful models: {combined['n_success']}/{len(args.models)}",
        f"- All coarse closure gates: {combined['all_coarse_closure_gates_pass']}",
        f"- Lowest radar prediction chi-square: {combined['preferred_by_radar_prediction_chi2']}",
        "",
        "## Model summaries",
        "",
    ]
    for s in summaries:
        lines.extend([
            f"### {s['model']}",
            "",
            f"- max |delay residual|: {s['max_abs_delay_residual_us']} us",
            f"- max |Doppler residual|: {s['max_abs_doppler_residual_hz']} Hz",
            f"- normalized residual RMS: {s['radar_normalized_residual_rms']}",
            f"- Doppler sign gate: {s['doppler_sign_convention_gate_pass']}",
            f"- coarse closure gate: {s['prediction_closure_gate_pass']}",
            "",
        ])
    lines.extend(["## Claim boundary", "", combined["claim_boundary"]])
    report_path = root / cfg["paths"]["reports_directory"] / f"{slug}__radar_prediction_report.md"
    report_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps(combined, indent=2))
    if failures:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
