from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

import argparse
import json
import numpy as np
import pandas as pd
from darkcomet_stage2b.common import dump_json, load_config, project_root, safe_slug
from darkcomet_stage2b.loo_claims import build_loo_claim_summary


def _load_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--target", required=True, choices=["2020 GE", "2021 VH2"])
    parser.add_argument("--model", required=True, choices=["M_SRP", "M_Y", "M_SY"])
    parser.add_argument("--fallback-sigma", type=float, default=1.0)
    args = parser.parse_args()

    cfg = load_config()
    root = project_root()
    slug = safe_slug(args.target)
    suffix = f"fallback_{args.fallback_sigma:g}"
    models_dir = root / cfg["paths"]["models_directory"]
    prepared = pd.read_csv(root / cfg["paths"]["processed_directory"] / f"{slug}_prepared_{suffix}.csv")
    clusters = sorted(prepared["cluster_id"].astype(int).unique())

    full_path = models_dir / f"{slug}__{args.model}__{suffix}__summary.json"
    full = _load_json(full_path) if full_path.exists() else {}
    full_a1 = full.get("A1_equivalent_au_d2")
    full_a2 = full.get("A2_estimated_au_d2")

    rows = []
    for cluster in clusters:
        tag = f"{slug}__{args.model}__{suffix}__exclude_cluster_{cluster}"
        summary_path = models_dir / f"{tag}__summary.json"
        failure_path = models_dir / f"{tag}__failure.json"
        if summary_path.exists():
            row = _load_json(summary_path)
            row["loo_status"] = "success"
            row["failure_error"] = None
        else:
            failure = _load_json(failure_path) if failure_path.exists() else {}
            row = {
                "target_id": args.target,
                "model": args.model,
                "fallback_sigma_arcsec": args.fallback_sigma,
                "excluded_cluster": int(cluster),
                "fit_valid": False,
                "model_comparison_eligible": False,
                "loo_status": "failed",
                "failure_error": failure.get("error", "missing summary and failure file"),
            }
        if full_a1 is not None and row.get("A1_equivalent_au_d2") is not None:
            row["A1_loo_sign_consistent_with_full"] = bool(np.sign(row["A1_equivalent_au_d2"]) == np.sign(full_a1))
            row["A1_ratio_to_full"] = float(row["A1_equivalent_au_d2"] / full_a1) if full_a1 else np.nan
        if full_a2 is not None and row.get("A2_estimated_au_d2") is not None:
            row["A2_loo_sign_consistent_with_full"] = bool(np.sign(row["A2_estimated_au_d2"]) == np.sign(full_a2))
            row["A2_ratio_to_full"] = float(row["A2_estimated_au_d2"] / full_a2) if full_a2 else np.nan
        rows.append(row)

    frame = pd.DataFrame(rows).sort_values("excluded_cluster")
    out = root / cfg["paths"]["loo_directory"] / f"{slug}__{args.model}__{suffix}__loo_summary.csv"
    frame.to_csv(out, index=False)

    summary = {
        "target_id": args.target,
        "model": args.model,
        "fallback_sigma_arcsec": args.fallback_sigma,
    }
    summary.update(build_loo_claim_summary(
        frame,
        model=args.model,
        full_a1=full_a1,
        full_a2=full_a2,
        min_abs_z_gate=float(cfg["claim_gates"]["parameter_abs_z_min"]),
        max_abs_ratio_gate=float(cfg["claim_gates"].get("loo_max_abs_ratio_to_full", 3.0)),
    ))
    summary_path = root / cfg["paths"]["loo_directory"] / f"{slug}__{args.model}__{suffix}__loo_summary.json"
    dump_json(summary_path, summary)
    print(frame.to_string(index=False))
    print("\nLOO summary:\n" + json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
