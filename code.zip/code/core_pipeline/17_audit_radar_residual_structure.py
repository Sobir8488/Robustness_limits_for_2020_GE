from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

import argparse
import json

import pandas as pd

from darkcomet_stage2b.common import dump_json, ensure_directories, load_config, project_root, safe_slug
from darkcomet_stage2b.radar_residual_audit import compare_model_summaries, summarize_model_prediction


def _read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8")) if path.exists() else None


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--target", default="2020 GE")
    parser.add_argument("--models", nargs="+", default=["M_SY", "M_Y"])
    args = parser.parse_args()

    cfg = load_config()
    ensure_directories(cfg)
    root = project_root()
    slug = safe_slug(args.target)
    rcfg = cfg["radar_validation"]
    formal_limit = float(rcfg.get("formal_prediction_nrms_limit", 5.0))
    profile_limit = float(rcfg.get("profile_prediction_nrms_limit", 5.0))

    model_summaries = {}
    row_tables = []
    failures = []
    for model in args.models:
        try:
            residual_path = root / cfg["paths"]["tables_directory"] / f"{slug}__{model}__radar_prediction_residuals.csv"
            prediction_summary_path = root / cfg["paths"]["tables_directory"] / f"{slug}__{model}__radar_prediction_summary.json"
            if not residual_path.exists():
                raise FileNotFoundError(residual_path)
            frame = pd.read_csv(residual_path)
            prediction_summary = _read_json(prediction_summary_path) or {}
            summary = summarize_model_prediction(
                frame,
                model=model,
                formal_nrms_limit=formal_limit,
                profile_nrms_limit=profile_limit,
                coarse_gate_pass=prediction_summary.get("prediction_closure_gate_pass"),
                doppler_sign_gate_pass=prediction_summary.get("doppler_sign_convention_gate_pass"),
            )
            model_summaries[model] = summary
            compact = frame[[
                "epoch_utc", "measurement_type", "station_pair", "value", "sigma", "freq",
                "predicted_native_value", "residual_native_observed_minus_predicted", "normalized_residual"
            ]].copy()
            compact.insert(0, "model", model)
            row_tables.append(compact)
        except Exception as exc:
            failures.append({"model": model, "error": str(exc)})

    comparison = compare_model_summaries(model_summaries) if model_summaries else {}
    combined = {
        "target_id": args.target,
        "protocol_version": cfg["protocol"]["frozen_protocol_version"],
        "models_requested": args.models,
        "n_success": len(model_summaries),
        "n_failed": len(failures),
        "failures": failures,
        "model_summaries": model_summaries,
        **comparison,
        "claim_boundary": (
            "This audit profiles residual structure in prediction-only radar comparisons. "
            "A lower radar prediction chi-square does not replace a joint optical-radar fit. "
            "Per-measurement-type bias profiles are diagnostics, not fitted physical corrections."
        ),
        "recommended_next_step": (
            "Proceed to joint optical-radar estimation only with center-of-mass records, receiver-epoch semantics, "
            "validated Doppler sign, explicit radar weights, and separate reporting of raw and nuisance-profiled residuals."
        ),
    }

    out_json = root / cfg["paths"]["tables_directory"] / f"{slug}__radar_residual_structure_summary.json"
    dump_json(out_json, combined)
    if row_tables:
        pd.concat(row_tables, ignore_index=True).to_csv(
            root / cfg["paths"]["tables_directory"] / f"{slug}__radar_residual_structure_rows.csv",
            index=False,
        )

    lines = [
        f"# {args.target} radar residual-structure audit",
        "",
        f"- Protocol: {combined['protocol_version']}",
        f"- Successful models: {combined['n_success']}/{len(args.models)}",
        f"- Raw radar chi-square preference: {combined.get('raw_chi2_preferred_model')}",
        f"- Global-bias-profile preference: {combined.get('global_bias_profile_chi2_preferred_model')}",
        f"- A1 external prediction support: {combined.get('A1_external_prediction_support_status')}",
        f"- Joint-fit readiness: {combined.get('joint_optical_radar_fit_readiness_gate_pass')}",
        "",
        "## Models",
        "",
    ]
    for model, summary in model_summaries.items():
        lines.extend([
            f"### {model}",
            "",
            f"- raw normalized residual RMS: {summary['raw_radar_normalized_residual_rms']}",
            f"- global-bias-profile normalized residual RMS: {summary['global_bias_profile_normalized_residual_rms']}",
            f"- weighted delay bias: {summary['delay_weighted_bias_us']} us",
            f"- weighted Doppler bias: {summary['doppler_weighted_bias_hz']} Hz",
            f"- maximum one-way range-equivalent delay residual: {summary['max_abs_delay_one_way_range_equivalent_km']} km",
            f"- maximum two-way Doppler-velocity-equivalent residual: {summary['max_abs_two_way_doppler_velocity_equivalent_m_s']} m/s",
            f"- classification: {summary['prediction_classification']}",
            "",
        ])
    lines.extend(["## Claim boundary", "", combined["claim_boundary"], "", "## Next step", "", combined["recommended_next_step"]])
    report = root / cfg["paths"]["reports_directory"] / f"{slug}__radar_residual_structure_report.md"
    report.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps(combined, indent=2))
    if failures:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
