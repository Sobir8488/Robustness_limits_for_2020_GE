from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

import argparse
import json

import pandas as pd

from darkcomet_stage2b.common import dump_json, ensure_directories, load_config, project_root, safe_slug
from darkcomet_stage2b.radar_observables import prepare_radar_observables, summarize_prepared_radar


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--target", default="2020 GE")
    args = parser.parse_args()

    cfg = load_config()
    ensure_directories(cfg)
    root = project_root()
    slug = safe_slug(args.target)
    radar_dir = root / cfg["paths"]["radar_directory"]
    tables_dir = root / cfg["paths"]["tables_directory"]
    reports_dir = root / cfg["paths"]["reports_directory"]

    source_path = radar_dir / f"{slug}__jpl_sb_radar_astrometry.csv"
    acquisition_summary_path = tables_dir / f"{slug}__radar_astrometry_summary.json"
    if not source_path.exists():
        raise FileNotFoundError(f"Radar astrometry not found: {source_path}")
    if not acquisition_summary_path.exists():
        raise FileNotFoundError(f"Radar acquisition summary not found: {acquisition_summary_path}")

    acquisition = json.loads(acquisition_summary_path.read_text(encoding="utf-8"))
    if not bool(acquisition.get("acquisition_gate_pass", False)):
        raise RuntimeError("Radar acquisition gate did not pass")
    if not bool(acquisition.get("direct_center_of_mass_fit_ready", False)):
        raise RuntimeError("Radar records are not center-of-mass direct-fit ready")

    raw = pd.read_csv(source_path)
    prepared = prepare_radar_observables(raw)
    summary = summarize_prepared_radar(prepared)
    summary.update({
        "target_id": args.target,
        "protocol_version": cfg["protocol"]["frozen_protocol_version"],
        "source_file": str(source_path.relative_to(root)).replace("\\", "/"),
        "acquisition_summary_file": str(acquisition_summary_path.relative_to(root)).replace("\\", "/"),
        "delay_conversion": "two_way_range_m = c * delay_us * 1e-6",
        "doppler_conversion": "two_way_doppler_m_s = c * delta_f_hz / transmitter_frequency_hz",
        "claim_boundary": (
            "This product is a semantics-preserving conversion layer. It does not by itself "
            "constitute radar closure or a joint optical-radar orbit fit."
        ),
    })

    out_csv = radar_dir / f"{slug}__radar_observables_tudat.csv"
    out_json = tables_dir / f"{slug}__radar_observable_conversion_summary.json"
    out_md = reports_dir / f"{slug}__radar_observable_conversion_report.md"
    prepared.to_csv(out_csv, index=False)
    dump_json(out_json, summary)

    lines = [
        f"# {args.target} radar observable conversion audit",
        "",
        f"- Protocol: {summary['protocol_version']}",
        f"- Records: {summary['n_records']} ({summary['n_delay']} delay, {summary['n_doppler']} Doppler)",
        f"- All center of mass: {summary['all_center_of_mass']}",
        f"- Conversion gate: {summary['conversion_gate_pass']}",
        f"- Epoch semantics: {summary['epoch_semantics']}",
        f"- Reference link end: {summary['reference_link_end']}",
        "",
        "## Conversion rules",
        "",
        f"- Delay: `{summary['delay_conversion']}`",
        f"- Doppler: `{summary['doppler_conversion']}`",
        "",
        "## Claim boundary",
        "",
        summary["claim_boundary"],
    ]
    out_md.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps({
        "prepared_csv": str(out_csv),
        "summary_json": str(out_json),
        "report_md": str(out_md),
        "conversion_gate_pass": summary["conversion_gate_pass"],
    }, indent=2))


if __name__ == "__main__":
    main()
