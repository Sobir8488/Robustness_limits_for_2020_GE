from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

import argparse
import json
from importlib import metadata
import numpy as np
import pandas as pd
from darkcomet_stage2b.common import load_config, project_root, safe_slug, dump_json
from darkcomet_stage2b.horizons_identity import query_anchored_cartesian_state, query_first_epoch_sky_check
from darkcomet_stage2b.tudat_compat import create_offline_batch_mpc


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--target", choices=["2020 GE", "2021 VH2"])
    args = parser.parse_args()

    try:
        import tudatpy
        from tudatpy.interface import spice
        from tudatpy.data.horizons import HorizonsQuery
        from tudatpy.dynamics import environment_setup
    except Exception as exc:
        raise RuntimeError(
            "TudatPy import failed. Activate the dedicated environment: conda activate darkcomet-tudat-clean"
        ) from exc

    cfg = load_config()
    root = project_root()
    targets = [args.target] if args.target else list(cfg["targets"])
    results = []

    spice.load_standard_kernels()
    dcfg = cfg["dynamics"]
    body_settings = environment_setup.get_default_body_settings(
        dcfg["bodies"], dcfg["global_frame_origin"], dcfg["global_frame_orientation"]
    )
    bodies = environment_setup.create_system_of_bodies(body_settings)
    for target_id in targets:
        tcfg = cfg["targets"][target_id]
        slug = safe_slug(target_id)
        batch_file = root / cfg["paths"]["processed_directory"] / f"{slug}_batchmpc_fallback_1.csv"
        if not batch_file.exists():
            raise FileNotFoundError(f"Run 01_prepare_tudat_inputs.py first: {batch_file}")
        table = pd.read_csv(batch_file)
        batch, batch_meta = create_offline_batch_mpc(
            table,
            target_id=target_id,
            observatory_cache_path=root / cfg["paths"]["observatory_cache"],
        )
        if float(batch.epoch_start) <= 0.0:
            raise RuntimeError(
                f"{target_id}: invalid non-positive observation epoch {batch.epoch_start}; do not run estimation"
            )
        anchor_mode = str(tcfg.get("initial_state_anchor", "direct_ssb"))
        state, identity_meta = query_anchored_cartesian_state(
            HorizonsQuery,
            bodies=bodies,
            target_id=target_id,
            target_cfg=tcfg,
            epoch=float(batch.epoch_start - float(tcfg.get("initial_state_lead_days", 1.0)) * 86400.0),
            frame_origin=dcfg["global_frame_origin"],
            frame_orientation=dcfg["global_frame_orientation"],
            anchor_mode=anchor_mode,
        )
        first = table.sort_values("epoch").iloc[0]
        sky_check = query_first_epoch_sky_check(
            HorizonsQuery,
            target_id=target_id,
            target_cfg=tcfg,
            station_code=str(first["observatory"]),
            epoch=float(batch.epoch_start),
            observed_ra_deg=float(first["RA"]),
            observed_dec_deg=float(first["DEC"]),
        )
        max_sep = float(cfg["fit_validation"]["max_horizons_first_epoch_separation_deg"])
        sky_check["gate_max_separation_deg"] = max_sep
        sky_check["gate_pass"] = bool(sky_check["angular_separation_deg"] <= max_sep)
        if not sky_check["gate_pass"]:
            raise RuntimeError(
                f"{target_id}: exact Horizons first-epoch sky separation is "
                f"{sky_check['angular_separation_deg']:.6g} deg (> {max_sep} deg); refusing estimation"
            )
        results.append({
            "target_id": target_id,
            "jpl_spkid": int(tcfg["jpl_spkid"]),
            "tudatpy_version": getattr(tudatpy, "__version__", "unknown"),
            "pandas_version": metadata.version("pandas"),
            "astropy_version": metadata.version("astropy"),
            "batch_size": int(batch.size),
            "batch_objects": list(batch.MPC_objects),
            "epoch_start_tdb_s_j2000": float(batch.epoch_start),
            "epoch_end_tdb_s_j2000": float(batch.epoch_end),
            "horizons_state_finite": bool(np.isfinite(state).all()),
            "horizons_state_norm_m": float(np.linalg.norm(state[:3])),
            "initial_state_anchor_mode": anchor_mode,
            "horizons_identity": identity_meta,
            "horizons_first_epoch_sky_check": sky_check,
            "batchmpc_compatibility": batch_meta,
        })
    dump_json(root / cfg["paths"]["tables_directory"] / "stage2b_tudat_preflight.json", results)
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
