from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

import argparse
import json

from darkcomet_stage2b.common import load_config, project_root, safe_slug
from darkcomet_stage2b.radar_astrometry import (
    RadarPaths,
    build_query_url,
    download_json,
    write_radar_products,
)


def main() -> None:
    parser = argparse.ArgumentParser(description="Download and audit JPL small-body radar astrometry")
    parser.add_argument("--target", default="2020 GE")
    parser.add_argument("--timeout", type=float, default=60.0)
    parser.add_argument("--attempts", type=int, default=3)
    parser.add_argument("--force", action="store_true", help="redownload even if a raw JSON already exists")
    args = parser.parse_args()

    cfg = load_config()
    root = project_root()
    if args.target not in cfg["targets"]:
        raise KeyError(f"Unknown target: {args.target}")
    target_cfg = cfg["targets"][args.target]
    spk_id = target_cfg.get("jpl_spkid")
    if not spk_id:
        raise RuntimeError(f"No JPL SPK-ID configured for {args.target}")

    slug = safe_slug(args.target)
    radar_dir = root / cfg["paths"].get("radar_directory", "data/radar")
    tables_dir = root / cfg["paths"]["tables_directory"]
    reports_dir = root / cfg["paths"]["reports_directory"]
    paths = RadarPaths(
        raw_json=radar_dir / f"{slug}__jpl_sb_radar_raw.json",
        normalized_csv=radar_dir / f"{slug}__jpl_sb_radar_astrometry.csv",
        coordinates_json=radar_dir / f"{slug}__jpl_sb_radar_station_coordinates.json",
        summary_json=tables_dir / f"{slug}__radar_astrometry_summary.json",
        report_md=reports_dir / f"{slug}__radar_astrometry_report.md",
    )
    url = build_query_url(spk_id=spk_id)

    if paths.raw_json.exists() and not args.force:
        payload = json.loads(paths.raw_json.read_text(encoding="utf-8"))
        source = "existing_raw_json"
    else:
        payload = download_json(url, timeout_s=args.timeout, attempts=args.attempts)
        source = "JPL_API_download"

    summary = write_radar_products(
        payload=payload,
        paths=paths,
        target_id=args.target,
        spk_id=spk_id,
        query_url=url,
    )
    summary["payload_source"] = source
    paths.summary_json.write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(summary, indent=2))

    if not summary["acquisition_gate_pass"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
