from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

import argparse
import pandas as pd
from darkcomet_stage2b.common import load_config, ensure_directories, project_root, safe_slug
from darkcomet_stage2b.prep import prepare_ades


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--target", choices=["2020 GE", "2021 VH2"])
    parser.add_argument("--fallback-sigma", type=float, default=None)
    args = parser.parse_args()

    cfg = load_config()
    ensure_directories(cfg)
    root = project_root()
    wcfg = cfg["weighting"]
    fallback = float(args.fallback_sigma or wcfg["fallback_sigma_arcsec"])
    targets = [args.target] if args.target else list(cfg["targets"])

    summaries = []
    for target_id in targets:
        tcfg = cfg["targets"][target_id]
        raw = pd.read_csv(root / cfg["paths"]["input_directory"] / tcfg["input_file"])
        audit, batch = prepare_ades(
            raw,
            target_id=target_id,
            fallback_sigma_arcsec=fallback,
            minimum_sigma_arcsec=float(wcfg["minimum_sigma_arcsec"]),
            maximum_sigma_arcsec=float(wcfg["maximum_sigma_arcsec"]),
            same_night_threshold=int(wcfg["same_night_threshold"]),
            gap_days=float(cfg["clustering"]["gap_days"]),
        )
        slug = safe_slug(target_id)
        suffix = f"fallback_{fallback:g}"
        audit.to_csv(root / cfg["paths"]["processed_directory"] / f"{slug}_prepared_{suffix}.csv", index=False)
        batch.to_csv(root / cfg["paths"]["processed_directory"] / f"{slug}_batchmpc_{suffix}.csv", index=False)
        summaries.append({
            "target_id": target_id,
            "fallback_sigma_arcsec": fallback,
            "n_observations": len(audit),
            "n_clusters": int(audit["cluster_id"].nunique()),
            "n_explicit_rms": int((audit["sigma_source"] == "ADES_RMS").sum()),
            "median_sigma_effective_arcsec": float(audit["sigma_effective_arcsec"].median()),
            "max_same_night_group": int(audit["same_night_group_size"].max()),
        })
    pd.DataFrame(summaries).to_csv(
        root / cfg["paths"]["tables_directory"] / f"stage2b_preparation_summary_fallback_{fallback:g}.csv",
        index=False,
    )
    print(pd.DataFrame(summaries).to_string(index=False))


if __name__ == "__main__":
    main()
