# Q1+ scientific-figure style

- Vector PDF is the manuscript source; 360-dpi PNG is a review/export companion.
- TrueType (Type 42) font embedding; no Type-3 plot fonts.
- Final-size axis labels target about 10--11 pt, tick labels about 9--10 pt, legends about 9 pt.
- Line widths ~1.25--1.45 pt; marker sizes ~5--6 pt.
- Figure canvas is matched to its intended journal placement to avoid destructive down-scaling.
- Default Matplotlib colour cycle plus marker-shape differences; no decorative palette.
- Numerical science values are unchanged.
