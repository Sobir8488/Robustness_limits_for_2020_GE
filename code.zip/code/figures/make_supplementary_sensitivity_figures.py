from pathlib import Path
import csv
import matplotlib.pyplot as plt
from q1plus_plot_style import apply_q1plus_style
apply_q1plus_style()
root=Path(__file__).resolve().parents[1]
# Weighting plot
rows=list(csv.DictReader((root/'figure_sources'/'weighting_sensitivity_values.csv').open()))
fig,ax=plt.subplots(figsize=(5.25,3.45),constrained_layout=True)
for model,marker in [('MY','o'),('MSY','s')]:
    rr=[r for r in rows if r['model']==model]
    x=[float(r['fallback']) for r in rr]; y=[float(r['A2']) for r in rr]; e=[float(r['sigma']) for r in rr]
    ax.errorbar(x,y,yerr=e,marker=marker,capsize=4,capthick=1.15,elinewidth=1.25,label=rf'$M_{{\rm {model}}}$')
ax.axhline(-1.93982,linewidth=1.0,linestyle='--',label='catalogue seed')
ax.set_xlabel('Fallback optical uncertainty [arcsec]')
ax.set_ylabel(r'$A_2$ [$10^{-12}$ au d$^{-2}$]')
ax.legend(loc='center right')
ax.grid(axis='both',linewidth=0.45,alpha=0.28)
fig.savefig(root/'figures'/'fig_weighting_sensitivity.pdf')
fig.savefig(root/'figures'/'fig_weighting_sensitivity.png',dpi=360)
plt.close(fig)
# Radial/transverse LOO plot
rows=list(csv.DictReader((root/'figure_sources'/'msy_loo_values.csv').open()))
x=[int(r['excluded']) for r in rows]
fig,axes=plt.subplots(2,1,figsize=(5.55,4.90),sharex=True,constrained_layout=True)
axes[0].errorbar(x,[float(r['A2']) for r in rows],yerr=[float(r['A2_sigma']) for r in rows],marker='o',capsize=4,capthick=1.15,elinewidth=1.25)
axes[0].axhline(-2.1399,linewidth=1.0,linestyle='--'); axes[0].axhline(0,linewidth=0.9)
axes[0].set_ylabel(r'$A_2$ [$10^{-12}$ au d$^{-2}$]')
axes[1].errorbar(x,[float(r['A1']) for r in rows],yerr=[float(r['A1_sigma']) for r in rows],marker='s',capsize=4,capthick=1.15,elinewidth=1.25)
axes[1].axhline(2.9354,linewidth=1.0,linestyle='--'); axes[1].axhline(0,linewidth=0.9)
axes[1].set_ylabel(r'Equivalent $A_1$ [$10^{-10}$ au d$^{-2}$]')
axes[1].set_xlabel('Excluded temporal cluster')
axes[1].set_xticks(x)
for ax in axes: ax.grid(axis='both',linewidth=0.45,alpha=0.28)
fig.savefig(root/'figures'/'fig_msy_loo_transport.pdf')
fig.savefig(root/'figures'/'fig_msy_loo_transport.png',dpi=360)
