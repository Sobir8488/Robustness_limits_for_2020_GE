from pathlib import Path
from datetime import datetime, timedelta
import pandas as pd
import matplotlib.pyplot as plt
from q1plus_plot_style import apply_q1plus_style
apply_q1plus_style()
root=Path(__file__).resolve().parents[1]

def decimal_year(epoch_seconds):
    dt=datetime(2000,1,1,12,0,0)+timedelta(seconds=float(epoch_seconds))
    y0=datetime(dt.year,1,1); y1=datetime(dt.year+1,1,1)
    return dt.year+(dt-y0).total_seconds()/(y1-y0).total_seconds()

def read(name):
    df=pd.read_csv(root/'figure_sources'/name)
    df['year']=[decimal_year(x) for x in df['epoch_tdb_s_j2000']]
    return df
my=read('residuals_MY_fallback1.csv')
msy=read('residuals_MSY_fallback1.csv')
fig,axes=plt.subplots(2,1,figsize=(7.05,4.45),sharex=True,constrained_layout=True)
for ax,df,label,ylim in [
    (axes[0],my,r'$M_{\rm Y}$',(-3.35,3.75)),
    (axes[1],msy,r'$M_{\rm SY}$',(-2.25,2.25)),
]:
    for comp,marker in [('RA','o'),('DEC','s')]:
        d=df[df['component']==comp]
        ax.scatter(d['year'],d['residual_arcsec'],s=20,marker=marker,label=comp,alpha=0.90)
    ax.axhline(0,linewidth=0.9,linestyle='--')
    ax.set_ylabel('Residual [arcsec]')
    ax.set_ylim(*ylim)
    ax.text(0.015,0.88,label,transform=ax.transAxes,ha='left',va='top',fontsize=10.8,fontweight='semibold')
    ax.grid(axis='both',linewidth=0.45,alpha=0.27)
axes[0].legend(loc='upper right',ncol=2,columnspacing=1.2,handletextpad=0.35)
axes[1].set_xlabel('Approximate calendar year')
axes[1].set_xlim(2020.0,2025.1)
axes[1].set_xticks([2020,2021,2022,2023,2024,2025])
fig.savefig(root/'figures'/'fig_optical_residual_chronology.pdf')
fig.savefig(root/'figures'/'fig_optical_residual_chronology.png',dpi=360)
