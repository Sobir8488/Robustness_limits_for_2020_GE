#!/usr/bin/env python3
from pathlib import Path
import csv
import matplotlib.pyplot as plt
from q1plus_plot_style import apply_q1plus_style
apply_q1plus_style()
BASE=Path(__file__).resolve().parents[1]
CSV=Path(__file__).with_name('station_night_robustness_values.csv')
OUT=BASE/'figures'/'fig_station_night_robustness.pdf'
rows=[]
with CSV.open(newline='',encoding='utf-8') as f:
    for row in csv.DictReader(f):
        rows.append({k:(float(v) if k not in {'analysis','interval_type'} else v) for k,v in row.items()})
fig,ax=plt.subplots(figsize=(3.65,2.72),constrained_layout=True)
y=list(range(len(rows)))[::-1]
for yi,row in zip(y,rows):
    c,lo,hi=row['centre'],row['lower'],row['upper']
    ax.errorbar(c,yi,xerr=[[c-lo],[hi-c]],fmt='o',capsize=4,capthick=1.2,elinewidth=1.35,markersize=5.6)
ax.axvline(0.0,linewidth=1.0,linestyle='--')
ax.set_yticks(y)
ax.set_yticklabels([r['analysis'] for r in rows],fontsize=9.3)
ax.set_xlabel(r'$A_2\ [10^{-12}\ \mathrm{au\ d^{-2}}]$')
ax.set_ylim(-0.55,len(rows)-0.45)
ax.grid(axis='x',linewidth=0.5,alpha=0.35)
fig.savefig(OUT)
fig.savefig(BASE/'figures'/'fig_station_night_robustness.png',dpi=360)
