from pathlib import Path
import csv
import matplotlib.pyplot as plt
from q1plus_plot_style import apply_q1plus_style
apply_q1plus_style()
root=Path(__file__).resolve().parents[1]
rows=list(csv.DictReader((root/'figure_sources'/'temporal_cluster_loo_MY.csv').open()))
x=[int(r['excluded_cluster']) for r in rows]
y=[float(r['A2_1e-12_au_d-2']) for r in rows]
e=[float(r['A2_sigma_1e-12_au_d-2']) for r in rows]
n=[int(r['n_positions']) for r in rows]
full=-1.91279
fig,ax=plt.subplots(figsize=(3.55,2.78),constrained_layout=True)
ax.axhspan(min(y),max(y),alpha=0.09)
ax.axhline(full,linewidth=1.0,linestyle='--')
ax.errorbar(x,y,yerr=e,fmt='o',capsize=4,capthick=1.15,elinewidth=1.25,markersize=5.7,zorder=3)
for xi,yi,ni in zip(x,y,n):
    ax.annotate(rf'$N={ni}$',(xi,yi),xytext=(0,8),textcoords='offset points',ha='center',va='bottom',fontsize=8.6)
ax.set_xticks(x)
ax.set_xlabel('Excluded temporal cluster')
ax.set_ylabel(r'$A_2$ [$10^{-12}$ au d$^{-2}$]')
ax.set_ylim(min(y)-0.22,max(y)+0.30)
ax.grid(axis='y',linewidth=0.45,alpha=0.30)
fig.savefig(root/'figures'/'fig_my_temporal_loo.pdf')
fig.savefig(root/'figures'/'fig_my_temporal_loo.png',dpi=360)
