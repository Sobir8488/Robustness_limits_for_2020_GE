from pathlib import Path
import matplotlib.pyplot as plt
from q1plus_plot_style import apply_q1plus_style
apply_q1plus_style()
root=Path(__file__).resolve().parents[1]
fig,axes=plt.subplots(1,3,figsize=(7.15,2.75),constrained_layout=True)

ax=axes[0]
vals=[-1.91279,-0.4128708]
ax.scatter([0,1],vals,s=44,zorder=3)
ax.axhline(0,linewidth=1.0,linestyle='--')
ax.set_xticks([0,1],['Tudat','OrbFit'])
ax.set_ylim(-2.15,0.20)
ax.set_ylabel(r'$A_2$ [$10^{-12}$ au d$^{-2}$]')
ax.set_title('Independent optima')

ax=axes[1]
ratios=[370.03,12861.05]
ax.bar([0,1],ratios,width=0.62)
ax.set_yscale('log')
ax.set_xticks([0,1],['OrbFit\n$\\to$ Tudat','Tudat\n$\\to$ OrbFit'])
ax.set_ylabel(r'Transport $\chi^2/\chi^2_{\rm own}$')
ax.set_title('No-refit transport')
ax.set_ylim(250,26000)
for i,v in enumerate(ratios):
    ax.text(i,v*1.10,f'{v:g}',ha='center',va='bottom',fontsize=8.8)

ax=axes[2]
msy_x=[1000,300,100,30]; msy_y=[0.775,2.377,5.508,16.311]
my_x=[1000,300,100,30,10]; my_y=[0.541,1.801,5.353,16.988,43.688]
ax.plot(msy_x,msy_y,marker='o',label=r'$M_{\rm SY}$')
ax.plot(my_x,my_y,marker='s',label=r'$M_{\rm Y}$')
ax.set_xscale('log'); ax.set_yscale('log'); ax.invert_xaxis()
ax.axhline(1,linewidth=1.0,linestyle='--')
ax.set_xlabel(r'Radar $\sigma$ multiplier')
ax.set_ylabel('Radar NRMS')
ax.set_title('Radar continuation')
ax.legend(loc='upper left')
for ax in axes:
    ax.tick_params(pad=2.5)
fig.savefig(root/'figures'/'fig_external_closure.pdf')
fig.savefig(root/'figures'/'fig_external_closure.png',dpi=360)
