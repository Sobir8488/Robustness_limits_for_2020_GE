from pathlib import Path
import runpy
root=Path(__file__).resolve().parent
for name in [
    'make_optical_residual_chronology.py',
    'make_my_temporal_loo.py',
    'make_station_night_robustness.py',
    'make_external_closure.py',
    'make_supplementary_sensitivity_figures.py',
]:
    print('RUN',name)
    runpy.run_path(str(root/name),run_name='__main__')
print('All Q1+ figures regenerated.')
