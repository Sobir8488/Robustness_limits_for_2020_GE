from __future__ import annotations
from pathlib import Path
import argparse, hashlib, json, math, os, shutil, subprocess, sys, tempfile, time
import numpy as np
import pandas as pd

ARCSEC_TO_RAD = math.pi / (180.0 * 3600.0)
J2000_JD = 2451545.0
TDB_MINUS_UTC_REFERENCE_S = 69.184
DEFAULT_RHOS = [0.0, 0.25, 0.50, 0.75, 0.90]
LINE_SEARCH = [1.0, 0.5, 0.25, 0.125, 0.0625]
DOF = 102 - 7

EXPECTED_HASHES = {
    "scripts/03_run_model_family.py": "84686ac3da98dadc764188543ba81e5b4c840b0dc795d7b4a0aa6dbefe2af892",
    "config/stage2b.yaml": "4223acbb41e74f85005f3dbf95318f37a4b1f71af583b9bc57bfb92d3dd05c07",
    "data/processed/2020_GE_prepared_fallback_1.csv": "1fbc469f4c4e5a5c7630c76feeafbd8e1e8351879b88a41cf25a7aa97c574d3a",
}

def dump_json(path: Path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, default=float) + "\n", encoding="utf-8")

def sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()

def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024*1024), b""):
            h.update(chunk)
    return h.hexdigest()

def vector_key(p: np.ndarray) -> str:
    return sha256_bytes(np.asarray(p, dtype="<f8").tobytes(order="C"))[:20]

def load_baseline(package_root: Path):
    inp = package_root / "inputs"
    summary = json.loads((inp / "tudat_candidate_summary.json").read_text(encoding="utf-8"))
    covariance = pd.read_csv(inp / "tudat_candidate_covariance.csv", header=None).to_numpy(float)
    design = pd.read_csv(inp / "tudat_candidate_design_matrix.csv", header=None).to_numpy(float)
    residuals = pd.read_csv(inp / "tudat_candidate_residuals.csv")
    r0 = pd.to_numeric(residuals["residual_rad"], errors="raise").to_numpy(float)
    sigma0 = pd.to_numeric(residuals["sigma_arcsec"], errors="raise").to_numpy(float) * ARCSEC_TO_RAD
    p0 = np.asarray(summary["final_parameter_vector"], dtype=float).reshape(7)
    scales = np.sqrt(np.diag(covariance))
    conv = float(summary["A2_estimated_au_d2"]) / float(summary["A2_estimated_m_s2"])
    return summary, covariance, design, r0, sigma0, p0, scales, conv

def crosswalk_groups(project_root: Path, residual_table: pd.DataFrame):
    prep = pd.read_csv(project_root / "data/processed/2020_GE_prepared_fallback_1.csv")
    if len(prep) != 51:
        raise RuntimeError(f"Expected 51 prepared positions, found {len(prep)}")
    tprep = (
        (pd.to_numeric(prep["epoch_jd_utc"], errors="raise").to_numpy(float) - J2000_JD)
        * 86400.0 + TDB_MINUS_UTC_REFERENCE_S
    )
    scalar_times = pd.to_numeric(
        residual_table["epoch_tdb_s_j2000"], errors="raise"
    ).to_numpy(float)
    if len(scalar_times) != 102:
        raise RuntimeError("Expected 102 scalar times")
    tvec = scalar_times[::2]
    D = np.abs(tvec[:, None] - tprep[None, :])
    idx = np.argmin(D, axis=1)
    err = D[np.arange(len(tvec)), idx]
    if len(set(idx.tolist())) != 51:
        raise RuntimeError("Epoch crosswalk is not one-to-one")
    if float(np.max(err)) > 0.01:
        raise RuntimeError(f"Epoch crosswalk max error {float(np.max(err))} s exceeds 0.01 s")
    blocks = (
        prep["stn"].astype(str).str.strip()
        + "|"
        + prep["utc_night"].astype(str).str.strip()
    ).to_numpy()[idx]
    if len(set(blocks.tolist())) != 19:
        raise RuntimeError(f"Expected 19 station-night blocks, got {len(set(blocks.tolist()))}")
    scalar_blocks = np.repeat(blocks, 2)
    components = residual_table["component"].astype(str).to_numpy()
    groups = np.asarray(
        [f"{b}|{c}" for b, c in zip(scalar_blocks, components)], dtype=object
    )
    return prep, idx, err, scalar_blocks, groups

def build_covariance(sigmas: np.ndarray, groups: np.ndarray, rho: float):
    n = len(sigmas)
    C = np.zeros((n, n), dtype=float)
    for label in dict.fromkeys(groups.tolist()):
        ii = np.where(groups == label)[0]
        m = len(ii)
        R = np.full((m, m), float(rho), dtype=float)
        np.fill_diagonal(R, 1.0)
        C[np.ix_(ii, ii)] = R * np.outer(sigmas[ii], sigmas[ii])
    # singleton groups are handled above; no zero diagonal may remain.
    if np.any(np.diag(C) <= 0.0):
        raise RuntimeError("Invalid block covariance diagonal")
    L = np.linalg.cholesky(C)
    return C, L

def objective(residual: np.ndarray, L: np.ndarray) -> float:
    rw = np.linalg.solve(L, residual)
    return float(rw @ rw)

def gls_step(H: np.ndarray, r: np.ndarray, L: np.ndarray, scales: np.ndarray):
    S = np.diag(scales)
    A = np.linalg.solve(L, H @ S)
    b = np.linalg.solve(L, r)
    q, _, rank, sv = np.linalg.lstsq(A, b, rcond=None)
    dp = S @ q
    cond = float(sv[0] / sv[-1]) if len(sv) and sv[-1] > 0 else float("inf")
    return dp, int(rank), cond, A

def correlated_covariance(H: np.ndarray, L: np.ndarray, scales: np.ndarray):
    S = np.diag(scales)
    A = np.linalg.solve(L, H @ S)
    Nq = A.T @ A
    Vq = np.linalg.pinv(Nq, rcond=1.0e-14)
    Vp = S @ Vq @ S
    sv = np.linalg.svd(A, compute_uv=False)
    cond = float(sv[0] / sv[-1]) if sv[-1] > 0 else float("inf")
    rank = int(np.linalg.matrix_rank(A))
    return Vp, rank, cond

class Evaluator:
    def __init__(self, project_root: Path, package_root: Path, work_root: Path):
        self.project_root = project_root
        self.package_root = package_root
        self.work_root = work_root
        self.script = package_root / "scripts/pss3a2_tudat_linearization.py"
        self.cache = {}
        self.eval_count = 0

    def evaluate(self, p: np.ndarray):
        p = np.asarray(p, dtype=float).reshape(7)
        key = vector_key(p)
        if key in self.cache:
            return self.cache[key]
        self.eval_count += 1
        evdir = self.work_root / f"eval_{self.eval_count:04d}_{key}"
        evdir.mkdir(parents=True, exist_ok=True)
        pfile = evdir / "parameter_vector.json"
        dump_json(pfile, {"parameter_vector": p.tolist(), "sha256_float64": sha256_bytes(np.asarray(p, dtype="<f8").tobytes())})
        env = os.environ.copy()
        env["PSS3A2_PROJECT_ROOT"] = str(self.project_root)
        env["PSS3A2_EVAL_ROOT"] = str(evdir)
        env["PSS3A2_PARAMETER_FILE"] = str(pfile)
        cmd = [sys.executable, str(self.script), "--target", "2020 GE", "--model", "M_Y", "--fallback-sigma", "1.0"]
        log = evdir / "tudat_linearization.log"
        t0 = time.time()
        proc = subprocess.run(
            cmd, cwd=str(self.project_root), env=env,
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True
        )
        log.write_text(proc.stdout, encoding="utf-8")
        if proc.returncode != 0:
            raise RuntimeError(
                f"Tudat linearization failed (return code {proc.returncode}). See {log}"
            )
        audit = evdir / "audit"
        summary = json.loads((audit / "linearization_summary.json").read_text(encoding="utf-8"))
        residuals = pd.read_csv(audit / "linearization_residuals.csv")
        H = pd.read_csv(audit / "linearization_design_matrix.csv", header=None).to_numpy(float)
        r = pd.to_numeric(residuals["residual_rad"], errors="raise").to_numpy(float)
        sigma = pd.to_numeric(residuals["sigma_rad"], errors="raise").to_numpy(float)
        if H.shape != (102,7) or r.shape != (102,) or sigma.shape != (102,):
            raise RuntimeError("Malformed linearization output")
        result = {
            "key": key, "dir": evdir, "summary": summary, "residuals": residuals,
            "H": H, "r": r, "sigma": sigma, "elapsed_s": time.time()-t0,
        }
        self.cache[key] = result
        return result

def _relative_frobenius(delta: np.ndarray, reference: np.ndarray) -> float:
    return float(
        np.linalg.norm(delta, ord="fro")
        / max(np.linalg.norm(reference, ord="fro"), np.finfo(float).tiny)
    )

def _relative_l2(delta: np.ndarray, reference: np.ndarray) -> float:
    return float(
        np.linalg.norm(delta)
        / max(np.linalg.norm(reference), np.finfo(float).tiny)
    )

def baseline_replay_gate(
    ev, baseline_summary, baseline_cov, baseline_design, baseline_r, baseline_sigma
):
    H, r, sigma = ev["H"], ev["r"], ev["sigma"]
    w = 1.0 / np.square(sigma)
    normal = H.T @ (w[:, None] * H)
    chi2 = float(np.sum(w * np.square(r)))

    # IMPORTANT: the raw 7x7 normal matrix is extremely ill-conditioned because
    # the six Cartesian state coordinates and A2 have very different physical
    # scales. A direct np.linalg.pinv(normal) is therefore not a valid replay of
    # the archived Tudat covariance. Stage-3F1R already established that raw
    # covariance-normal arithmetic is numerically misleading while the
    # dimensionless scale-aware closure is stable. Reconstruct the diagonal-
    # likelihood covariance in that same dimensionless parameter basis.
    scales = np.sqrt(np.maximum(np.diag(baseline_cov), np.finfo(float).tiny))
    D = np.diag(scales)
    scaled_normal = D @ normal @ D
    scaled_cond = float(np.linalg.cond(scaled_normal))
    scaled_rank = int(np.linalg.matrix_rank(scaled_normal))
    if scaled_rank != 7 or not np.isfinite(scaled_cond):
        raise RuntimeError(
            f"Baseline scaled normal is not stably full rank: rank={scaled_rank}, cond={scaled_cond}"
        )
    scaled_cov = np.linalg.inv(scaled_normal)
    cov = D @ scaled_cov @ D

    target_chi2 = float(baseline_summary["chi2"])
    target_sigma = float(baseline_summary["A2_sigma_raw_m_s2"])
    got_sigma = float(math.sqrt(max(cov[6, 6], 0.0)))

    chi_rel = abs(chi2 - target_chi2) / max(abs(target_chi2), 1.0)
    cov_rel = _relative_frobenius(cov - baseline_cov, baseline_cov)
    sigma_rel = abs(got_sigma - target_sigma) / max(abs(target_sigma), np.finfo(float).tiny)
    design_rel = _relative_frobenius(H - baseline_design, baseline_design)
    residual_rel = _relative_l2(r - baseline_r, baseline_r)
    sigma_vector_rel = _relative_l2(sigma - baseline_sigma, baseline_sigma)

    gates = {
        "replay_method": "scale_aware_normal_inversion_consistent_with_stage3f1r_matrix_finalizer",
        "chi2_relative_error": chi_rel,
        "design_matrix_frobenius_relative_error": design_rel,
        "residual_vector_l2_relative_error": residual_rel,
        "sigma_vector_l2_relative_error": sigma_vector_rel,
        "covariance_frobenius_relative_error": cov_rel,
        "A2_sigma_relative_error": sigma_rel,
        "scaled_normal_rank": scaled_rank,
        "scaled_normal_condition_number": scaled_cond,
        "chi2_gate": bool(chi_rel <= 1.0e-8),
        "design_matrix_gate": bool(design_rel <= 1.0e-8),
        "residual_vector_gate": bool(residual_rel <= 1.0e-8),
        "sigma_vector_gate": bool(sigma_vector_rel <= 1.0e-10),
        "covariance_gate": bool(cov_rel <= 1.0e-8),
        "A2_sigma_gate": bool(sigma_rel <= 1.0e-8),
        "scaled_rank_gate": bool(scaled_rank == 7),
    }
    gates["overall_pass"] = all(
        gates[k] for k in (
            "chi2_gate", "design_matrix_gate", "residual_vector_gate",
            "sigma_vector_gate", "covariance_gate", "A2_sigma_gate",
            "scaled_rank_gate"
        )
    )
    return gates

def optimize_rho(rho, evaluator, p_start, scales, groups, sigma, conv, max_iter, output_root):
    C, L = build_covariance(sigma, groups, rho)
    p = np.asarray(p_start, dtype=float).copy()
    history = []
    converged = False
    status = "MAX_ITERATIONS"
    ev = evaluator.evaluate(p)
    q = objective(ev["r"], L)
    for iteration in range(max_iter):
        H, r = ev["H"], ev["r"]
        dp, rank, cond, _ = gls_step(H, r, L, scales)
        scaled_step = float(np.max(np.abs(dp / scales)))
        # Guard against an excessively large Newton step while preserving direction.
        clip_factor = 1.0
        if scaled_step > 5.0:
            clip_factor = 5.0 / scaled_step
            dp = dp * clip_factor
            scaled_step = 5.0
        accepted = False
        best_trial = None
        for lam in LINE_SEARCH:
            ptrial = p + lam * dp
            if not np.isfinite(ptrial).all():
                continue
            trial = evaluator.evaluate(ptrial)
            qtrial = objective(trial["r"], L)
            if qtrial < q - max(1.0e-10, 1.0e-12*abs(q)):
                best_trial = (lam, ptrial, trial, qtrial)
                accepted = True
                break
        if not accepted:
            # A tiny computed update with no resolvable improvement is a stationary solution.
            if scaled_step <= 1.0e-4:
                converged = True
                status = "STATIONARY_NO_RESOLVABLE_IMPROVEMENT"
                history.append({
                    "rho":rho,"iteration":iteration,"objective":q,
                    "scaled_step_inf":scaled_step,"linear_rank":rank,
                    "scaled_design_condition_number":cond,"clip_factor":clip_factor,
                    "accepted":False,"lambda":0.0,"relative_improvement":0.0,
                    "A2_au_d2":float(p[6]*conv),
                })
                break
            status = "LINE_SEARCH_FAILED"
            history.append({
                "rho":rho,"iteration":iteration,"objective":q,
                "scaled_step_inf":scaled_step,"linear_rank":rank,
                "scaled_design_condition_number":cond,"clip_factor":clip_factor,
                "accepted":False,"lambda":0.0,"relative_improvement":0.0,
                "A2_au_d2":float(p[6]*conv),
            })
            break
        lam, pnew, evnew, qnew = best_trial
        rel_improve = float((q-qnew)/max(abs(q),1.0))
        history.append({
            "rho":rho,"iteration":iteration,"objective":q,
            "trial_objective":qnew,"scaled_step_inf":scaled_step,
            "linear_rank":rank,"scaled_design_condition_number":cond,
            "clip_factor":clip_factor,"accepted":True,"lambda":lam,
            "relative_improvement":rel_improve,
            "A2_au_d2":float(p[6]*conv),
            "trial_A2_au_d2":float(pnew[6]*conv),
        })
        p, ev, q = pnew, evnew, qnew
        accepted_scaled_step = float(lam * scaled_step)
        if accepted_scaled_step <= 1.0e-4 and rel_improve <= 1.0e-8:
            converged = True
            status = "CONVERGED"
            break
    # final exact linearization and covariance
    ev = evaluator.evaluate(p)
    q = objective(ev["r"], L)
    V, rank, cond = correlated_covariance(ev["H"], L, scales)
    sigma_raw_m = math.sqrt(max(float(V[6,6]),0.0))
    red = q / DOF
    inflation = max(1.0, math.sqrt(red))
    sigma_scaled_au = abs(sigma_raw_m * conv) * inflation
    a2_au = float(p[6]*conv)
    lo, hi = a2_au - 1.96*sigma_scaled_au, a2_au + 1.96*sigma_scaled_au
    result = {
        "rho":float(rho),"converged":bool(converged),"status":status,
        "iterations":len(history),"final_objective":q,"reduced_correlated_chi2":red,
        "final_parameter_vector":p.tolist(),"A2_au_d2":a2_au,
        "sigma_A2_raw_au_d2":abs(sigma_raw_m*conv),
        "sigma_A2_overdispersion_scaled_au_d2":sigma_scaled_au,
        "normal_approx_95_lo_au_d2":lo,"normal_approx_95_hi_au_d2":hi,
        "interval_excludes_zero":bool(lo>0 or hi<0),
        "scaled_design_rank":rank,"scaled_design_condition_number":cond,
        "final_eval_key":ev["key"],"final_eval_elapsed_s":ev["elapsed_s"],
    }
    rdir = output_root / f"rho_{str(rho).replace('.','p')}"
    rdir.mkdir(parents=True, exist_ok=True)
    dump_json(rdir / "final_result.json", result)
    pd.DataFrame([{"parameter_index":i,"value":float(v)} for i,v in enumerate(p)]).to_csv(
        rdir / "final_parameter_vector.csv", index=False
    )
    ev["residuals"].to_csv(rdir / "final_residuals.csv", index=False)
    pd.DataFrame(history).to_csv(rdir / "iteration_history.csv", index=False)
    return result, history

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--project-root", type=Path, required=True)
    ap.add_argument("--package-root", type=Path, default=Path(__file__).resolve().parents[1])
    ap.add_argument("--output-root", type=Path, default=None)
    ap.add_argument("--rho-grid", default="0,0.25,0.5,0.75,0.9")
    ap.add_argument("--max-outer-iterations", type=int, default=8)
    ap.add_argument("--keep-work", action="store_true")
    args = ap.parse_args()

    project_root = args.project_root.resolve()
    package_root = args.package_root.resolve()
    output_root = (
        args.output_root.resolve()
        if args.output_root is not None
        else (project_root / "results/pss3a2_nonlinear_correlated_v102")
    )
    output_root.mkdir(parents=True, exist_ok=True)
    summary, baseline_cov, baseline_design, baseline_r, baseline_sigma, p0, scales, conv = load_baseline(package_root)
    rhos = [float(x.strip()) for x in args.rho_grid.split(",") if x.strip()]
    if not rhos or any((x < 0 or x >= 1) for x in rhos):
        raise RuntimeError("rho values must satisfy 0 <= rho < 1")

    # Readiness gates before launching Tudat.
    required = [
        project_root / "scripts/03_run_model_family.py",
        project_root / "config/stage2b.yaml",
        project_root / "data/processed/2020_GE_prepared_fallback_1.csv",
        project_root / "data/processed/2020_GE_batchmpc_fallback_1.csv",
        project_root / "data/reference/mpc_observatory_codes.csv",
        project_root / "src/darkcomet_stage2b/common.py",
    ]
    missing = [str(p) for p in required if not p.is_file()]
    if missing:
        raise FileNotFoundError("Missing project prerequisites:\n" + "\n".join(missing))
    hash_audit = {}
    for rel, expected in EXPECTED_HASHES.items():
        path = project_root / rel
        actual = sha256_file(path)
        hash_audit[rel] = {"expected":expected, "actual":actual, "match":actual==expected}
    dump_json(output_root / "PSS3A2_SOURCE_HASH_AUDIT.json", hash_audit)
    if not all(x["match"] for x in hash_audit.values()):
        raise RuntimeError(
            "Frozen source/input hash gate failed. See PSS3A2_SOURCE_HASH_AUDIT.json; "
            "do not run PSS3-A2 against a different scientific lineage."
        )
    try:
        import tudatpy
    except Exception as exc:
        raise RuntimeError(
            "tudatpy is not importable in this Python interpreter. Activate the darkcomet-tudat-clean environment."
        ) from exc

    work_root = Path(tempfile.mkdtemp(prefix="PSS3A2_"))
    evaluator = Evaluator(project_root, package_root, work_root)
    run_status = {"work_root":str(work_root),"output_root":str(output_root)}
    try:
        baseline_ev = evaluator.evaluate(p0)
        replay = baseline_replay_gate(
            baseline_ev, summary, baseline_cov, baseline_design, baseline_r, baseline_sigma
        )
        dump_json(output_root / "PSS3A2_BASELINE_REPLAY.json", replay)
        if not replay["overall_pass"]:
            raise RuntimeError(
                "Frozen Tudat baseline replay failed. PSS3-A2 nonlinear correlated refit is blocked; "
                "inspect PSS3A2_BASELINE_REPLAY.json."
            )
        prep, idx, err, scalar_blocks, groups = crosswalk_groups(project_root, baseline_ev["residuals"])
        sigma = baseline_ev["sigma"]
        if not np.allclose(sigma, baseline_ev["sigma"], rtol=0, atol=0):
            raise RuntimeError("Internal sigma consistency failure")

        all_results, all_history = [], []
        for rho in rhos:
            result, history = optimize_rho(
                rho, evaluator, p0, scales, groups, sigma, conv,
                args.max_outer_iterations, output_root
            )
            all_results.append(result)
            all_history.extend(history)

        rdf = pd.DataFrame(all_results)
        rdf.to_csv(output_root / "PSS3A2_RHO_SUMMARY.csv", index=False, float_format="%.17g")
        pd.DataFrame(all_history).to_csv(
            output_root / "PSS3A2_ITERATION_HISTORY.csv", index=False, float_format="%.17g"
        )
        all_converged = bool(all(x["converged"] for x in all_results))
        all_intervals_negative = bool(
            all(x["interval_excludes_zero"] and x["normal_approx_95_hi_au_d2"] < 0 for x in all_results)
        )
        rho0 = next((x for x in all_results if abs(x["rho"]) < 1e-15), None)
        rho0_relative_A2_shift = (
            abs(rho0["A2_au_d2"] - float(summary["A2_estimated_au_d2"]))
            / abs(float(summary["A2_estimated_au_d2"])) if rho0 else None
        )
        validation = {
            "stage":"PSS3-A2 full nonlinear station-night correlated Tudat refit",
            "version":"1.0.2",
            "protocol_version":"1.0.0",
            "scientific_fit_executed":True,
            "frozen_source_hash_audit":hash_audit,
            "baseline_replay":replay,
            "prepared_rows":int(len(prep)),
            "station_night_blocks":int(len(set(scalar_blocks.tolist()))),
            "epoch_crosswalk_max_error_s":float(np.max(err)),
            "rho_grid":rhos,
            "all_rho_converged":all_converged,
            "all_rho_normal_intervals_negative":all_intervals_negative,
            "rho0_relative_A2_shift_from_frozen_baseline":rho0_relative_A2_shift,
            "rho0_consistency_gate":bool(rho0_relative_A2_shift is not None and rho0_relative_A2_shift <= 1.0e-3),
            "total_tudat_linearizations":int(evaluator.eval_count),
            "PSS3A2_FULL_NONLINEAR_OFFDIAGONAL_REFIT_EXECUTED":True,
            "PSS3A2_NUMERICAL_CLOSURE_READY":bool(all_converged and replay["overall_pass"] and (rho0_relative_A2_shift is not None and rho0_relative_A2_shift <= 1.0e-3)),
            "PHYSICAL_A2_DETECTION_AUTHORIZED":False,
            "YARKOVSKY_DETECTION_AUTHORIZED":False,
            "claim_boundary_reason":(
                "Even if the explicit correlated-likelihood nonlinear refits remain negative, "
                "the previously frozen station-night bootstrap/jackknife intervals cross zero, "
                "Tudat-OrbFit same-candidate transport fails, and radar formal closure is absent."
            ),
        }
        prior_validation = json.loads(
            (package_root / "reference/PSS3_VALIDATION.json").read_text(encoding="utf-8")
        )
        validation["PSS3B_DIRECT_LOCAL_SVD_CONDITION_DIAGNOSTIC_READY"] = bool(
            prior_validation.get("PSS3B_DIRECT_LOCAL_SVD_CONDITION_DIAGNOSTIC_READY", False)
        )
        validation["PSS3C_EVIDENCE_GROUNDED_HARMONISATION_MATRIX_READY"] = bool(
            prior_validation.get("PSS3C_EVIDENCE_GROUNDED_HARMONISATION_MATRIX_READY", False)
        )
        validation["PSS3_SCIENTIFIC_CLOSURE_READY"] = bool(
            validation["PSS3A2_NUMERICAL_CLOSURE_READY"]
            and validation["PSS3B_DIRECT_LOCAL_SVD_CONDITION_DIAGNOSTIC_READY"]
            and validation["PSS3C_EVIDENCE_GROUNDED_HARMONISATION_MATRIX_READY"]
        )
        dump_json(output_root / "PSS3A2_VALIDATION.json", validation)

        # Report and manuscript insertion are generated from actual results.
        lines = [
            "# PSS3-A2 nonlinear correlated-likelihood report","",
            "## Method",
            "For each prescribed within-station-night equicorrelation coefficient, the full seven-parameter Tudat M_Y orbit was re-estimated by an external generalized Gauss-Newton loop. Each outer iteration re-integrated the Tudat dynamics and variational equations at the current state-force vector, extracted the 102x7 design matrix and 102 scalar residuals, solved the block-correlated GLS normal problem, and accepted the step only when the full correlated objective decreased.",
            "",
            "RA and Dec are treated as separate correlation channels within each station-night; the original scalar sigmas are retained on the covariance diagonal.",
            "",
            "## Results","",
        ]
        for x in all_results:
            lines.append(
                f"- rho={x['rho']:.2f}: status={x['status']}, A2={x['A2_au_d2']:.6e} au d^-2, "
                f"sigma_scaled={x['sigma_A2_overdispersion_scaled_au_d2']:.6e}, "
                f"95%=[{x['normal_approx_95_lo_au_d2']:.6e}, {x['normal_approx_95_hi_au_d2']:.6e}], "
                f"Q={x['final_objective']:.6f}."
            )
        lines += [
            "",
            "## Claim disposition",
            "This calculation closes the specific reviewer question of whether the local off-diagonal covariance result survives full nonlinear re-estimation. It does not, by itself, authorize a physical A2 or Yarkovsky detection. The publication claim remains controlled by the wider evidence hierarchy: support-conditioned station-night resampling, G37 practical-identifiability diagnostics, cross-code same-candidate transport, and radar closure.",
            "",
            f"Numerical closure ready: **{validation['PSS3A2_NUMERICAL_CLOSURE_READY']}**.",
            f"Overall Phase-3 scientific closure ready: **{validation['PSS3_SCIENTIFIC_CLOSURE_READY']}**.",
        ]
        (output_root / "PSS3A2_FINAL_REPORT.md").write_text("\n".join(lines)+"\n", encoding="utf-8")

        manuscript = [
            "# Manuscript insertion generated from PSS3-A2","",
            "A full nonlinear sensitivity test was also performed with an explicit station-night covariance. "
            "Within each station-night, residuals of the same angular coordinate were assigned an equicorrelation coefficient rho while retaining the frozen per-coordinate variances. "
            "For each rho, the complete seven-parameter transverse-only orbit was re-estimated rather than evaluated at a fixed linearization point. "
        ]
        if all_converged:
            manuscript.append(
                "All prescribed correlated-likelihood branches converged under the external generalized Gauss-Newton loop. "
            )
        if all_intervals_negative:
            manuscript.append(
                "Across the tested correlation grid, the re-estimated transverse coefficient remained negative and its local overdispersion-scaled normal interval did not cross zero. "
                "This shows that explicit within-block covariance, considered in isolation, does not reproduce the much broader uncertainty obtained when station-night support itself is resampled. "
            )
        else:
            manuscript.append(
                "At least one correlated-likelihood branch did not retain a zero-excluding negative local interval, so the off-diagonal likelihood itself weakens the nominal transverse signal. "
            )
        manuscript.append(
            "In either case, the station-night bootstrap and jackknife remain the primary support-sensitive claim boundary, and no physical A2 or Yarkovsky detection is promoted."
        )
        (output_root / "PSS3A2_MANUSCRIPT_INSERTION.md").write_text(
            "".join(manuscript)+"\n", encoding="utf-8"
        )

        # Byte-level manifest and a single upload-ready archive.
        manifest_rows = []
        for fp in sorted(output_root.rglob("*")):
            if fp.is_file() and fp.name != "MANIFEST_SHA256.txt":
                manifest_rows.append(
                    f"{sha256_file(fp)}  {fp.relative_to(output_root).as_posix()}"
                )
        (output_root / "MANIFEST_SHA256.txt").write_text(
            "\n".join(manifest_rows) + "\n", encoding="utf-8"
        )
        import zipfile
        archive_path = project_root / "2020_GE_PSS3A2_OUTPUTS_v1_0_2.zip"
        if archive_path.exists():
            archive_path.unlink()
        with zipfile.ZipFile(archive_path, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
            for fp in sorted(output_root.rglob("*")):
                if fp.is_file():
                    zf.write(
                        fp,
                        arcname=f"2020_GE_PSS3A2_OUTPUTS_v1_0_2/{fp.relative_to(output_root).as_posix()}",
                    )
        validation["output_archive"] = {
            "path": str(archive_path),
            "bytes": int(archive_path.stat().st_size),
            "sha256": sha256_file(archive_path),
        }
        dump_json(output_root / "PSS3A2_VALIDATION.json", validation)
        # Rebuild manifest once more because validation now contains archive metadata.
        manifest_rows = []
        for fp in sorted(output_root.rglob("*")):
            if fp.is_file() and fp.name != "MANIFEST_SHA256.txt":
                manifest_rows.append(
                    f"{sha256_file(fp)}  {fp.relative_to(output_root).as_posix()}"
                )
        (output_root / "MANIFEST_SHA256.txt").write_text(
            "\n".join(manifest_rows) + "\n", encoding="utf-8"
        )
        # Rebuild archive so the manifest and final validation are included.
        archive_path.unlink()
        with zipfile.ZipFile(archive_path, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
            for fp in sorted(output_root.rglob("*")):
                if fp.is_file():
                    zf.write(
                        fp,
                        arcname=f"2020_GE_PSS3A2_OUTPUTS_v1_0_2/{fp.relative_to(output_root).as_posix()}",
                    )
        print(json.dumps(validation, indent=2))
        print(f"PSS3A2_OUTPUT_ARCHIVE={archive_path}")
        return 0 if validation["PSS3A2_NUMERICAL_CLOSURE_READY"] else 2
    finally:
        if args.keep_work:
            print(f"PSS3A2_WORK_ROOT={work_root}")
        else:
            shutil.rmtree(work_root, ignore_errors=True)

if __name__ == "__main__":
    raise SystemExit(main())
