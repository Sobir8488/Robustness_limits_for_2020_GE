from pathlib import Path
import argparse, json, sys
import pandas as pd

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--output-root", type=Path, required=True)
    args=ap.parse_args()
    root=args.output_root.resolve()
    v=root/"PSS3A2_VALIDATION.json"
    s=root/"PSS3A2_RHO_SUMMARY.csv"
    required=[v,s,root/"PSS3A2_BASELINE_REPLAY.json",root/"PSS3A2_FINAL_REPORT.md",root/"PSS3A2_MANUSCRIPT_INSERTION.md"]
    missing=[str(p) for p in required if not p.is_file()]
    if missing:
        print(json.dumps({"pass":False,"missing":missing},indent=2))
        return 2
    val=json.loads(v.read_text(encoding="utf-8"))
    df=pd.read_csv(s)
    checks={
        "five_rho_rows": len(df)==5,
        "rho_grid_exact": sorted(round(float(x),2) for x in df["rho"])==[0.0,0.25,0.5,0.75,0.9],
        "all_converged": bool(val.get("all_rho_converged",False)),
        "baseline_replay_pass": bool(val.get("baseline_replay",{}).get("overall_pass",False)),
        "rho0_consistency_gate": bool(val.get("rho0_consistency_gate",False)),
        "scientific_fit_executed": bool(val.get("scientific_fit_executed",False)),
        "physical_detection_not_authorized": val.get("PHYSICAL_A2_DETECTION_AUTHORIZED") is False,
        "yarkovsky_detection_not_authorized": val.get("YARKOVSKY_DETECTION_AUTHORIZED") is False,
    }
    out={"pass":all(checks.values()),"checks":checks,"validation":val}
    print(json.dumps(out,indent=2))
    return 0 if out["pass"] else 2
if __name__=="__main__":
    raise SystemExit(main())
