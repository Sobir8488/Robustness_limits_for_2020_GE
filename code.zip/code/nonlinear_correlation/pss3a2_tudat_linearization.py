from pathlib import Path
import sys
import os
_PROJECT_ROOT_TEXT = os.environ.get('PSS3A2_PROJECT_ROOT','').strip()
_EVAL_ROOT_TEXT = os.environ.get('PSS3A2_EVAL_ROOT','').strip()
_PARAMETER_FILE_TEXT = os.environ.get('PSS3A2_PARAMETER_FILE','').strip()
if not _PROJECT_ROOT_TEXT or not _EVAL_ROOT_TEXT or not _PARAMETER_FILE_TEXT:
    raise RuntimeError('PSS3A2_PROJECT_ROOT, PSS3A2_EVAL_ROOT, and PSS3A2_PARAMETER_FILE are required')
ROOT = Path(_PROJECT_ROOT_TEXT).resolve()
PSS3A2_EVAL_ROOT = Path(_EVAL_ROOT_TEXT).resolve()
PSS3A2_PARAMETER_FILE = Path(_PARAMETER_FILE_TEXT).resolve()
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

import argparse
import json
import math
import traceback
import inspect
from pathlib import Path

import numpy as np
import pandas as pd

from darkcomet_stage2b.common import (
    ARCSEC_TO_RAD,
    SOLAR_PRESSURE_1AU_N_M2,
    au_d2_to_m_s2,
    dump_json,
    ensure_directories,
    load_config,
    m_s2_to_au_d2,
    project_root,
    safe_slug,
)
from darkcomet_stage2b.stats import information_criteria, safe_z
from darkcomet_stage2b.fit_diagnostics import weighted_fit_statistics
from darkcomet_stage2b.horizons_identity import query_anchored_cartesian_state
from darkcomet_stage2b.tudat_compat import create_offline_batch_mpc, make_rkf78_integrator
from darkcomet_stage2b.ra_branch import normalize_ra_observation_branches, wrap_to_pi


def safe_callable_signature(callable_obj):
    """Return non-fatal API provenance for Python and pybind11 callables.

    Some TudatPy functions are pybind11 builtins without ``__text_signature__``.
    ``inspect.signature`` then raises ``ValueError`` even though the callable is
    valid.  Provenance collection must never block orbit estimation.
    """
    try:
        return str(inspect.signature(callable_obj)), "inspect.signature", True
    except (TypeError, ValueError) as exc:
        doc = str(getattr(callable_obj, "__doc__", "") or "")
        first_line = next((line.strip() for line in doc.splitlines() if line.strip()), "")
        if first_line:
            return first_line, "pybind11_docstring", False
        return (
            f"<signature unavailable: {type(exc).__name__}>",
            "unavailable",
            False,
        )


def parameter_labels(model_name: str) -> list[str]:
    labels = [
        "initial_state_x_m", "initial_state_y_m", "initial_state_z_m",
        "initial_state_vx_m_s", "initial_state_vy_m_s", "initial_state_vz_m_s",
    ]
    if model_name in {"M_SRP", "M_SY"}:
        labels.append("srp_parallel_scale")
    if model_name in {"M_Y", "M_SY"}:
        labels.append("A2_m_s2")
    return labels


def parameter_rows(model_name, values, formal_errors, error_inflation_factor):
    labels = parameter_labels(model_name)
    if len(labels) != len(values):
        labels = labels[:len(values)] + [f"unnamed_parameter_{i}" for i in range(len(labels), len(values))]
    rows = []
    for i, (label, value) in enumerate(zip(labels, values)):
        raw_error = float(formal_errors[i]) if i < len(formal_errors) else float("nan")
        scaled_error = raw_error * float(error_inflation_factor)
        rows.append({
            "parameter_index": i,
            "parameter_name": label,
            "value": float(value),
            "formal_error_raw": raw_error,
            "formal_error_overdispersion_scaled": scaled_error,
            "z_formal": safe_z(float(value), raw_error),
            "z_overdispersion_scaled": safe_z(float(value), scaled_error),
        })
    return rows


def run_fit(
    target_id: str,
    model_name: str,
    fallback_sigma: float,
    exclude_cluster: int | None,
    initial_state_lead_days_override: float | None = None,
    initial_state_anchor_override: str | None = None,
    force_seed_policy_override: str | None = None,
):
    from tudatpy.interface import spice
    from tudatpy import estimation
    from tudatpy.dynamics import environment_setup, propagation_setup, parameters_setup
    from tudatpy.estimation import observable_models_setup, estimation_analysis, observations as tudat_observations
    from tudatpy.data.horizons import HorizonsQuery

    cfg = json.loads(json.dumps(load_config()))
    cfg["paths"]["models_directory"] = str(PSS3A2_EVAL_ROOT / "models")
    cfg["paths"]["residuals_directory"] = str(PSS3A2_EVAL_ROOT / "residuals")
    cfg["dynamics"]["maximum_iterations"] = 1
    ensure_directories(cfg)
    root = project_root()
    if root.resolve() != ROOT.resolve():
        raise RuntimeError(f"Project-root mismatch: imported={root} requested={ROOT}")
    tcfg = cfg["targets"][target_id]
    mcfg = cfg["models"][model_name]
    if model_name != "M_Y" or exclude_cluster is not None or float(fallback_sigma) != 1.0:
        raise RuntimeError("PSS3-A2 linearization is restricted to full-sample M_Y, fallback=1")
    parameter_payload = json.loads(PSS3A2_PARAMETER_FILE.read_text(encoding="utf-8"))
    external_parameter_vector = np.asarray(parameter_payload["parameter_vector"], dtype=float).reshape(-1)
    if external_parameter_vector.shape != (7,) or not np.isfinite(external_parameter_vector).all():
        raise RuntimeError(f"Expected finite 7-vector, got {external_parameter_vector}")
    slug = safe_slug(target_id)
    suffix = f"fallback_{fallback_sigma:g}"

    prepared_path = root / cfg["paths"]["processed_directory"] / f"{slug}_prepared_{suffix}.csv"
    batch_path = root / cfg["paths"]["processed_directory"] / f"{slug}_batchmpc_{suffix}.csv"
    if not prepared_path.exists() or not batch_path.exists():
        raise FileNotFoundError(
            f"Prepared inputs not found for {target_id}, fallback={fallback_sigma}. "
            "Run 01_prepare_tudat_inputs.py with the same fallback sigma."
        )

    full_prepared = pd.read_csv(prepared_path)
    full_batch_table = pd.read_csv(batch_path)
    prepared = full_prepared.copy()
    batch_table = full_batch_table.copy()
    if exclude_cluster is not None:
        keep = prepared["cluster_id"].astype(int) != int(exclude_cluster)
        prepared = prepared.loc[keep].reset_index(drop=True)
        batch_table = batch_table.loc[keep].reset_index(drop=True)
        if len(prepared) < 10:
            raise RuntimeError("Leave-one-cluster-out sample has fewer than 10 observations")

    spice.load_standard_kernels()

    batch, batch_meta = create_offline_batch_mpc(
        batch_table,
        target_id=target_id,
        observatory_cache_path=root / cfg["paths"]["observatory_cache"],
    )
    full_batch = batch
    full_batch_meta = batch_meta
    if exclude_cluster is not None:
        full_batch, full_batch_meta = create_offline_batch_mpc(
            full_batch_table,
            target_id=target_id,
            observatory_cache_path=root / cfg["paths"]["observatory_cache"],
        )
    weights = prepared["weight_per_coordinate_rad_inverse2"].to_numpy(float)
    batch.set_weights(weights)

    dcfg = cfg["dynamics"]
    global_frame_origin = dcfg["global_frame_origin"]
    global_frame_orientation = dcfg["global_frame_orientation"]
    body_settings = environment_setup.get_default_body_settings(
        dcfg["bodies"], global_frame_origin, global_frame_orientation
    )
    bodies = environment_setup.create_system_of_bodies(body_settings)

    observation_collection = batch.to_tudat(
        bodies=bodies,
        included_satellites=None,
        apply_weights_VFCC17=False,
        apply_star_catalog_debias=False,
    )
    if float(batch.epoch_start) <= 0.0:
        raise RuntimeError(
            f"{target_id}: BatchMPC time axis is invalid ({batch.epoch_start}); "
            "run the v0.3.3 preflight before estimation"
        )
    target_name = str(batch.MPC_objects[0])
    bodies_to_propagate = [target_name]
    central_bodies = [global_frame_origin]

    # The target is normalized to 1 kg. For SRP models, the reference area is chosen
    # from the catalogue A1 prior so that the estimated parallel scaling begins near 1.
    bodies.get(target_name).mass = 1.0
    a1_prior = abs(float(tcfg["jpl_catalogue_A1_au_d2"]))
    a1_prior_si = au_d2_to_m_s2(a1_prior)
    reference_area_m2 = max(a1_prior_si / SOLAR_PRESSURE_1AU_N_M2, 1.0e-8)
    if mcfg["srp"]:
        rp_settings = environment_setup.radiation_pressure.cannonball_radiation_target(
            reference_area_m2,
            1.0,
            {"Sun": ["Earth"]},
        )
        environment_setup.add_radiation_pressure_target_model(
            bodies, target_name, rp_settings
        )

    observation_settings_list = []
    (
        angular_position_signature,
        angular_position_signature_source,
        angular_position_signature_introspection_available,
    ) = safe_callable_signature(
        observable_models_setup.model_settings.angular_position
    )
    # TudatPy 1.0.0 exposes only link/light-time/bias/convergence arguments.
    # The later normalize_right_ascension keyword is not a periodic-wrap switch;
    # in newer builds it changes the observable from alpha to alpha*cos(delta).
    # Keep the native [alpha, delta] observable for cross-version comparability.
    links = observation_collection.get_link_definitions_for_observables(
        observable_type=observable_models_setup.model_settings.angular_position_type
    )
    for link in list(links):
        observation_settings_list.append(
            observable_models_setup.model_settings.angular_position(
                link, bias_settings=None
            )
        )
    angular_position_compatibility = {
        "signature": angular_position_signature,
        "signature_source": angular_position_signature_source,
        "signature_introspection_available": (
            angular_position_signature_introspection_available
        ),
        "normalize_right_ascension_keyword_supported": (
            "normalize_right_ascension" in angular_position_signature
            if angular_position_signature_introspection_available
            else None
        ),
        "normalization_mode": "native_alpha_delta",
        "unsupported_keyword_omitted": True,
        "provenance_introspection_nonfatal": True,
    }

    accelerations = {
        "Sun": [
            propagation_setup.acceleration.point_mass_gravity(),
            propagation_setup.acceleration.relativistic_correction(use_schwarzschild=True),
        ],
        "Mercury": [propagation_setup.acceleration.point_mass_gravity()],
        "Venus": [propagation_setup.acceleration.point_mass_gravity()],
        "Earth": [propagation_setup.acceleration.point_mass_gravity()],
        "Moon": [propagation_setup.acceleration.point_mass_gravity()],
        "Mars": [propagation_setup.acceleration.point_mass_gravity()],
        "Jupiter": [propagation_setup.acceleration.point_mass_gravity()],
        "Saturn": [propagation_setup.acceleration.point_mass_gravity()],
        "Uranus": [propagation_setup.acceleration.point_mass_gravity()],
        "Neptune": [propagation_setup.acceleration.point_mass_gravity()],
    }
    if mcfg["srp"]:
        accelerations["Sun"].append(propagation_setup.acceleration.radiation_pressure())
    if mcfg["yarkovsky"]:
        a2_initial_si = float(external_parameter_vector[6])
        accelerations["Sun"].append(propagation_setup.acceleration.yarkovsky(a2_initial_si))

    acceleration_models = propagation_setup.create_acceleration_models(
        bodies,
        {target_name: accelerations},
        bodies_to_propagate,
        central_bodies,
    )

    end_buffer_s = float(dcfg["time_buffer_days"]) * 86400.0
    # LOO fits use the full-sample reference epoch and propagation interval.
    # For close-encounter targets, querying the initial state many weeks before
    # the first observation can amplify small force-model differences before the
    # fit sees any data.  Use a target-specific lead time, with a CLI override for
    # a controlled epoch-sensitivity ladder.
    reference_batch = full_batch if exclude_cluster is not None else batch
    configured_lead_days = float(
        tcfg.get("initial_state_lead_days", dcfg["time_buffer_days"])
    )
    initial_state_lead_days = (
        float(initial_state_lead_days_override)
        if initial_state_lead_days_override is not None
        else configured_lead_days
    )
    if not (0.005 <= initial_state_lead_days <= float(dcfg["time_buffer_days"])):
        raise ValueError(
            "initial_state_lead_days must be between 0.005 and "
            f"{float(dcfg['time_buffer_days']):g} days"
        )
    epoch_start = float(reference_batch.epoch_start - initial_state_lead_days * 86400.0)
    epoch_end = float(reference_batch.epoch_end + end_buffer_s)

    configured_anchor_mode = str(tcfg.get("initial_state_anchor", "direct_ssb"))
    initial_state_anchor_mode = (
        str(initial_state_anchor_override)
        if initial_state_anchor_override is not None
        else configured_anchor_mode
    )
    initial_state = np.asarray(external_parameter_vector[:6], dtype=float).copy()
    initial_state_anchor_mode = "pss3a2_external_parameter_vector"
    horizons_identity = {
        "identity_mode": "pss3a2_external_parameter_vector",
        "external_horizons_query_executed": False,
        "parameter_file": str(PSS3A2_PARAMETER_FILE),
        "state_finite": bool(np.isfinite(initial_state).all()),
        "state_position_norm_m": float(np.linalg.norm(initial_state[:3])),
        "state_velocity_norm_m_s": float(np.linalg.norm(initial_state[3:])),
    }

    integrator_settings = make_rkf78_integrator(
        propagation_setup.integrator,
        dcfg,
    )
    termination = propagation_setup.propagator.time_termination(epoch_end)
    propagator_settings = propagation_setup.propagator.translational(
        central_bodies=central_bodies,
        acceleration_models=acceleration_models,
        bodies_to_integrate=bodies_to_propagate,
        initial_states=initial_state,
        initial_time=epoch_start,
        integrator_settings=integrator_settings,
        termination_settings=termination,
    )

    parameter_settings = parameters_setup.initial_states(propagator_settings, bodies)
    if mcfg["srp"]:
        parameter_settings.append(
            parameters_setup.radiation_pressure_target_direction_scaling(target_name, "Sun")
        )
    if mcfg["yarkovsky"]:
        parameter_settings.append(parameters_setup.yarkovsky_parameter(target_name, "Sun"))

    parameters_to_estimate = parameters_setup.create_parameter_set(
        parameter_settings, bodies, propagator_settings
    )

    # Preserve nesting in the optimizer. Extended full-sample models start
    # from M0. LOO models use the corresponding full-sample best-fit vector at
    # the same fixed reference epoch; this is essential for sparse subsets.
    warm_start_source = "exact_spkid_horizons"
    initial_parameter_vector = np.asarray(parameters_to_estimate.parameter_vector, dtype=float).copy()
    if exclude_cluster is not None:
        full_model_path = root / cfg["paths"]["models_directory"] / f"{slug}__{model_name}__{suffix}__summary.json"
        if full_model_path.exists():
            full_model_summary = json.loads(full_model_path.read_text(encoding="utf-8"))
            full_model_vector = np.asarray(full_model_summary.get("final_parameter_vector", []), dtype=float)
            if (
                bool(full_model_summary.get("fit_valid", False))
                and full_model_vector.size == initial_parameter_vector.size
                and np.isfinite(full_model_vector).all()
            ):
                initial_parameter_vector[:] = full_model_vector
                warm_start_source = f"full_sample_{model_name}_best_iteration_fixed_epoch"
        if warm_start_source == "exact_spkid_horizons":
            m0_path = root / cfg["paths"]["models_directory"] / f"{slug}__M0__{suffix}__summary.json"
            if m0_path.exists():
                m0_summary = json.loads(m0_path.read_text(encoding="utf-8"))
                m0_vector = np.asarray(m0_summary.get("final_parameter_vector", []), dtype=float)
                if (
                    bool(m0_summary.get("fit_valid", False))
                    and m0_vector.size >= 6
                    and np.isfinite(m0_vector[:6]).all()
                ):
                    initial_parameter_vector[:6] = m0_vector[:6]
                    warm_start_source = "full_sample_M0_best_iteration_fixed_epoch"
    elif (
        model_name != "M0"
        and cfg["fit_validation"].get("warm_start_extended_models_from_M0", True)
    ):
        m0_path = root / cfg["paths"]["models_directory"] / f"{slug}__M0__{suffix}__summary.json"
        if m0_path.exists():
            m0_summary = json.loads(m0_path.read_text(encoding="utf-8"))
            m0_vector = np.asarray(m0_summary.get("final_parameter_vector", []), dtype=float)
            if (
                bool(m0_summary.get("fit_valid", False))
                and m0_vector.size >= 6
                and np.isfinite(m0_vector[:6]).all()
            ):
                initial_parameter_vector[:6] = m0_vector[:6]
                warm_start_source = "M0_best_iteration_state"
    preserve_full_model_force_amplitudes = bool(
        exclude_cluster is not None
        and warm_start_source == f"full_sample_{model_name}_best_iteration_fixed_epoch"
    )
    configured_force_seed_policy = str(tcfg.get("force_seed_policy", "zero"))
    force_seed_policy = (
        str(force_seed_policy_override)
        if force_seed_policy_override is not None
        else configured_force_seed_policy
    )
    if force_seed_policy not in {"zero", "catalogue_priors"}:
        raise ValueError(f"Unknown force seed policy: {force_seed_policy!r}")
    initial_srp_scale_seed = None
    initial_a2_seed_si = None
    if not preserve_full_model_force_amplitudes:
        extra_index = 6
        if mcfg["srp"] and extra_index < initial_parameter_vector.size:
            initial_srp_scale_seed = 1.0 if force_seed_policy == "catalogue_priors" else 0.0
            initial_parameter_vector[extra_index] = initial_srp_scale_seed
            extra_index += 1
        if mcfg["yarkovsky"] and extra_index < initial_parameter_vector.size:
            initial_a2_seed_si = (
                au_d2_to_m_s2(float(tcfg.get("jpl_catalogue_A2_au_d2") or 0.0))
                if force_seed_policy == "catalogue_priors"
                else 0.0
            )
            initial_parameter_vector[extra_index] = initial_a2_seed_si
    if initial_parameter_vector.size != external_parameter_vector.size:
        raise RuntimeError(
            f"Parameter dimension mismatch: Tudat={initial_parameter_vector.size}, external={external_parameter_vector.size}"
        )
    initial_parameter_vector[:] = external_parameter_vector
    warm_start_source = "pss3a2_external_parameter_vector"
    initial_a2_seed_si = float(external_parameter_vector[6])
    parameters_to_estimate.parameter_vector = initial_parameter_vector

    estimator = estimation_analysis.Estimator(
        bodies=bodies,
        estimated_parameters=parameters_to_estimate,
        observation_settings=observation_settings_list,
        propagator_settings=propagator_settings,
        integrate_on_creation=True,
    )

    # TudatPy 1.0 may retain an observed-minus-computed RA residual close to
    # ±2π for a physically tiny angle difference.  A single such branch jump
    # dominates the least-squares norm and drives the state update away from
    # the valid local solution.  Compute the prefit observables once, then
    # shift only RA values by integer multiples of 2π to the nearest simulated
    # branch.  This is a representation change, not a data or physics change.
    tudat_observations.compute_residuals_and_dependent_variables(
        observation_collection, estimator.observation_simulators, bodies
    )
    prefit_raw_residuals_before_branch = np.asarray(
        observation_collection.get_concatenated_residuals(), dtype=float
    ).reshape(-1)
    original_observation_values = np.asarray(
        observation_collection.concatenated_observations, dtype=float
    ).reshape(-1)
    branch_adjusted_observations, ra_branch_normalization = (
        normalize_ra_observation_branches(
            original_observation_values, prefit_raw_residuals_before_branch
        )
    )
    if ra_branch_normalization["n_ra_branch_shifts"] > 0:
        observation_collection.set_observations(branch_adjusted_observations)
        tudat_observations.compute_residuals_and_dependent_variables(
            observation_collection, estimator.observation_simulators, bodies
        )
    prefit_residuals_after_branch = np.asarray(
        observation_collection.get_concatenated_residuals(), dtype=float
    ).reshape(-1)
    expected_prefit_after_branch = prefit_raw_residuals_before_branch.copy()
    expected_prefit_after_branch[0::2] = wrap_to_pi(
        expected_prefit_after_branch[0::2]
    )
    branch_verification_error = float(
        np.max(np.abs(prefit_residuals_after_branch - expected_prefit_after_branch))
    )
    ra_branch_normalization.update({
        "applied": bool(ra_branch_normalization["n_ra_branch_shifts"] > 0),
        "post_reset_prefit_rms_arcsec": float(
            np.sqrt(np.mean(prefit_residuals_after_branch**2)) / ARCSEC_TO_RAD
        ),
        "post_reset_prefit_max_abs_arcsec": float(
            np.max(np.abs(prefit_residuals_after_branch)) / ARCSEC_TO_RAD
        ),
        "post_reset_verification_max_error_rad": branch_verification_error,
        "post_reset_verification_pass": bool(branch_verification_error <= 1.0e-9),
    })
    if not ra_branch_normalization["post_reset_verification_pass"]:
        raise RuntimeError(
            "RA branch-normalization verification failed: "
            f"max error={branch_verification_error} rad"
        )

    pod_input = estimation_analysis.EstimationInput(
        observations_and_times=observation_collection,
        convergence_checker=estimation_analysis.estimation_convergence_checker(
            maximum_iterations=1
        ),
        apply_final_parameter_correction=False,
    )
    pod_input.set_weights_from_observation_collection()
    pod_input.define_estimation_settings(
        reintegrate_equations_on_first_iteration=True,
        reintegrate_variational_equations=True,
        save_design_matrix=True,
        print_output_to_terminal=False,
        save_residuals_and_parameters_per_iteration=True,
        save_state_history_per_iteration=False,
    )
    pod_output = estimator.perform_estimation(pod_input)

    audit_dir = PSS3A2_EVAL_ROOT / "audit"
    audit_dir.mkdir(parents=True, exist_ok=True)
    residual_history = np.asarray(pod_output.residual_history, dtype=float)
    parameter_history = np.asarray(pod_output.parameter_history, dtype=float)
    design_matrix = np.asarray(pod_output.design_matrix, dtype=float)
    collection_weights = np.asarray(
        observation_collection.concatenated_weights, dtype=float
    ).reshape(-1)
    times = np.asarray(observation_collection.concatenated_times, dtype=float).reshape(-1)
    if residual_history.ndim != 2 or residual_history.shape[0] != 102:
        raise RuntimeError(f"Unexpected residual-history shape: {residual_history.shape}")
    if parameter_history.ndim != 2 or parameter_history.shape[0] != 7:
        raise RuntimeError(f"Unexpected parameter-history shape: {parameter_history.shape}")
    if design_matrix.shape != (102, 7):
        raise RuntimeError(f"Unexpected design-matrix shape: {design_matrix.shape}")
    if collection_weights.shape != (102,) or times.shape != (102,):
        raise RuntimeError("Unexpected native weight/time vector shape")
    residual0 = residual_history[:, 0].reshape(-1)
    parameter0 = parameter_history[:, 0].reshape(-1)
    if not np.allclose(parameter0, external_parameter_vector, rtol=0.0, atol=1.0e-20):
        raise RuntimeError(
            "Tudat iteration-zero parameter vector does not match requested external vector"
        )
    sigma_rad = 1.0 / np.sqrt(collection_weights)
    components = np.where(np.arange(102) % 2 == 0, "RA", "DEC")
    pd.DataFrame({
        "scalar_index": np.arange(102),
        "epoch_tdb_s_j2000": times,
        "component": components,
        "residual_rad": residual0,
        "residual_arcsec": residual0 / ARCSEC_TO_RAD,
        "sigma_rad": sigma_rad,
        "sigma_arcsec": sigma_rad / ARCSEC_TO_RAD,
        "native_weight_rad_inverse2": collection_weights,
    }).to_csv(audit_dir / "linearization_residuals.csv", index=False)
    np.savetxt(audit_dir / "linearization_design_matrix.csv", design_matrix, delimiter=",")
    np.savetxt(audit_dir / "parameter_history.csv", parameter_history, delimiter=",")
    np.savetxt(audit_dir / "residual_history.csv", residual_history, delimiter=",")
    np.savetxt(audit_dir / "iteration0_parameter_vector.csv", parameter0.reshape(1,-1), delimiter=",")
    # Native diagonal covariance at this linearization, for replay checking.
    normal_native = design_matrix.T @ (collection_weights[:, None] * design_matrix)
    covariance_native = np.linalg.pinv(normal_native, rcond=1.0e-14)
    np.savetxt(audit_dir / "native_linearized_covariance.csv", covariance_native, delimiter=",")
    summary = {
        "stage": "PSS3-A2 Tudat exact nonlinear linearization",
        "target_id": target_id,
        "model": model_name,
        "fallback_sigma_arcsec": float(fallback_sigma),
        "n_positions": int(len(prepared)),
        "n_scalars": int(len(residual0)),
        "parameter_vector": parameter0.tolist(),
        "residual_history_shape": list(residual_history.shape),
        "parameter_history_shape": list(parameter_history.shape),
        "design_matrix_shape": list(design_matrix.shape),
        "apply_final_parameter_correction": False,
        "maximum_iterations": 1,
        "ra_branch_normalization": ra_branch_normalization,
        "propagation_epoch_start_tdb_s_j2000": float(epoch_start),
        "propagation_epoch_end_tdb_s_j2000": float(epoch_end),
        "weight_vector_sha256": __import__("hashlib").sha256(
            np.asarray(collection_weights, dtype="<f8").tobytes(order="C")
        ).hexdigest(),
        "residual_vector_sha256": __import__("hashlib").sha256(
            np.asarray(residual0, dtype="<f8").tobytes(order="C")
        ).hexdigest(),
        "design_matrix_all_finite": bool(np.isfinite(design_matrix).all()),
        "residuals_all_finite": bool(np.isfinite(residual0).all()),
        "native_covariance_all_finite": bool(np.isfinite(covariance_native).all()),
        "external_horizons_query_executed": False,
        "scientific_claim_authorized": False,
    }
    (audit_dir / "linearization_summary.json").write_text(
        json.dumps(summary, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(summary, indent=2))
    return summary


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--target", default="2020 GE")
    parser.add_argument("--model", default="M_Y")
    parser.add_argument("--fallback-sigma", type=float, default=1.0)
    args = parser.parse_args()
    run_fit(args.target, args.model, args.fallback_sigma, None, None, None, None)


if __name__ == "__main__":
    main()
