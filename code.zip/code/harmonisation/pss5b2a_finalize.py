from pathlib import Path
import argparse, zipfile, hashlib, json

ap=argparse.ArgumentParser()
ap.add_argument("--project-root",type=Path,required=True)
ap.add_argument("--output-root",type=Path,required=True)
args=ap.parse_args()
project=args.project_root.resolve(); out=args.output_root.resolve()
val=out/"PSS5B2A_STATION_SCALE_VALIDATION.json"
if not val.is_file():
    raise SystemExit(2)

rows=[]
for p in sorted(out.rglob("*")):
    if p.is_file() and p.name!="MANIFEST_SHA256.txt":
        rows.append(f"{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.relative_to(out).as_posix()}")
(out/"MANIFEST_SHA256.txt").write_text("\n".join(rows)+"\n",encoding="utf-8")

zp=project/"2020_GE_PSS5B2A_STATION_SCALE_OUTPUTS_v1_0_0.zip"
with zipfile.ZipFile(zp,"w",zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(out.rglob("*")):
        if p.is_file():
            z.write(p,arcname=f"2020_GE_PSS5B2A_STATION_SCALE_OUTPUTS_v1_0_0/{p.relative_to(out).as_posix()}")
print("PSS5B2A_STATION_SCALE_OUTPUT_ARCHIVE="+str(zp))
