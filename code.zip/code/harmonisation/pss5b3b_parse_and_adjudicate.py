from __future__ import annotations
from pathlib import Path
import argparse,json,re,math,hashlib,zipfile

K=0.01720209895
DAYS_PER_MYR=365.25e6
FLOAT=re.compile(r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[DEde][-+]?\d+)?")
FROZEN_TUDAT_A2=-1.9127881663788407e-12
FROZEN_ORBFIT_A2=-4.1287077220144016e-13
FROZEN_RATIO=abs(FROZEN_TUDAT_A2)/abs(FROZEN_ORBFIT_A2)

def ff(x): return float(x.replace("D","E").replace("d","e"))
def a2_from(equ,dadt):
    a,h,k=equ[0],equ[1],equ[2]
    return 0.5*(dadt/DAYS_PER_MYR)*K*math.sqrt(a)*(1-h*h-k*k)

def parse_branch(root:Path,name:str):
    fel=root/"2020GE.fel"; log=root/"fitobs.log"; rwo=root/"obsdata/2020GE.rwo"; fop=root/"2020GE.fop"
    for p in [fel,log,rwo,fop]:
        if not p.is_file(): raise RuntimeError(f"{name}: missing {p}")
    t=fel.read_text(encoding="ascii",errors="replace")
    em=re.search(r"(?m)^\s*EQU\s+(.+?)\s*$",t)
    nm=re.search(r"(?m)^\s*NGR\s+(.+?)\s*$",t)
    if not em or not nm: raise RuntimeError(f"{name}: EQU/NGR missing")
    equ=[ff(x) for x in FLOAT.findall(em.group(1))[:6]]
    ngr=[ff(x) for x in FLOAT.findall(nm.group(1))]
    if len(equ)!=6 or len(ngr)<2: raise RuntimeError(f"{name}: malformed solution")
    dadt=ngr[1]; a2=a2_from(equ,dadt)

    lt=log.read_text(encoding="utf-8",errors="replace")
    rms=[ff(x) for x in re.findall(r"RMS of weighed residuals is\s+("+FLOAT.pattern+r")",lt,re.I)]
    iter_rms=[ff(x) for x in re.findall(r"RMS residuals\s*=\s*("+FLOAT.pattern+r")",lt,re.I)]
    norm_corr=[ff(x) for x in re.findall(r"norm corr\s*=\s*("+FLOAT.pattern+r")",lt,re.I)]
    fatal=[line.strip() for line in lt.splitlines()
           if re.search(r"\b(STOP|FATAL|segmentation|abnormal end)\b",line,re.I)]
    recs=[l for l in rwo.read_text(encoding="ascii",errors="replace").splitlines()
          if re.match(r"^\s*2020GE\s+O\s+C\s+\d{4}\s+\d{2}\s+[0-9.]+",l)]
    return {
      "branch":name,"EQU":equ,"NGR":ngr,"dadt_au_Myr":dadt,"A2_au_d2":a2,
      "weighted_RMS":rms[-1] if rms else None,
      "iteration_RMS":iter_rms,
      "norm_corrections":norm_corr,
      "last_norm_correction":norm_corr[-1] if norm_corr else None,
      "fatal_hits":fatal,"n_records":len(recs),
      "fel_sha256":hashlib.sha256(fel.read_bytes()).hexdigest(),
      "rwo_sha256":hashlib.sha256(rwo.read_bytes()).hexdigest(),
      "fop_sha256":hashlib.sha256(fop.read_bytes()).hexdigest()
    }

def parse_bai(path:Path):
    txt=path.read_text(encoding="ascii",errors="replace")
    lines=[l.rstrip() for l in txt.splitlines()]
    nb=None; epochs=None; bodies=[]
    # Writer format: first line nbout; second line t1 t2 dt; then mass + name.
    if lines:
        m=re.search(r"[-+]?\d+",lines[0])
        if m: nb=int(m.group(0))
    if len(lines)>=2:
        vals=FLOAT.findall(lines[1])
        if len(vals)>=3: epochs=[ff(x) for x in vals[:3]]
    for l in lines[2:]:
        vals=FLOAT.findall(l)
        if not vals: continue
        mass=ff(vals[0])
        # name starts after first numeric token
        mm=FLOAT.search(l)
        name=l[mm.end():].strip() if mm else ""
        if name: bodies.append({"mass_solar":mass,"name":name})
    return {"nbout":nb,"epoch_grid":epochs,"bodies":bodies,"raw_sha256":hashlib.sha256(path.read_bytes()).hexdigest()}

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--project-root",type=Path,required=True)
    ap.add_argument("--work-root",type=Path,required=True)
    ap.add_argument("--output-root",type=Path,required=True)
    args=ap.parse_args()
    project=args.project_root.resolve(); work=args.work_root.resolve(); out=args.output_root.resolve()
    out.mkdir(parents=True,exist_ok=True)

    baseline=parse_branch(work/"baseline","AST17_baseline")
    noast=parse_branch(work/"no_ast","no_massive_asteroids")

    # PSS-5B3B v1.0.1 parser hotfix:
    # baseline/AST17.bai is a Linux symlink.  Windows pathlib can read the
    # regular branch outputs through \\wsl.localhost, but it cannot reliably
    # dereference this Linux symlink.  The WSL science runner already exported
    # the exact real BAI file to the Windows output directory before fitting.
    # Use that regular file for the archival census.
    bai_export = out / "AST17.bai.exact_ascii_copy"
    if not bai_export.is_file():
        raise RuntimeError(
            "Missing exported exact AST17 index: "
            f"{bai_export}. The WSL science runner should have created it "
            "before the two fit branches."
        )
    bai=parse_bai(bai_export)
    (out/"AST17_EXACT_INDEX.json").write_text(json.dumps(bai,indent=2),encoding="utf-8")

    # Hard gates on baseline replay and controlled FOP diff.
    rel=abs(baseline["A2_au_d2"]-FROZEN_ORBFIT_A2)/abs(FROZEN_ORBFIT_A2)
    rms_ref=2.2312002428767035
    rms_rel=(abs(baseline["weighted_RMS"]-rms_ref)/rms_ref
             if baseline["weighted_RMS"] is not None else None)

    b_lines=(work/"baseline/2020GE.fop").read_text(encoding="utf-8",errors="replace").splitlines()
    n_lines=(work/"no_ast/2020GE.fop").read_text(encoding="utf-8",errors="replace").splitlines()
    diffs=[]
    for i,(a,b) in enumerate(zip(b_lines,n_lines),start=1):
        if a!=b: diffs.append({"line":i,"baseline":a,"no_ast":b})
    if len(b_lines)!=len(n_lines):
        diffs.append({"line_count_difference":[len(b_lines),len(n_lines)]})

    baseline_pass=(
        rel < 1e-8 and baseline["n_records"]==51 and not baseline["fatal_hits"]
        and baseline["weighted_RMS"] is not None and rms_rel < 1e-8
    )
    controlled_diff_pass=(
        len(diffs)==1
        and re.search(r"\.iast\s*=\s*17\b",diffs[0]["baseline"])
        and re.search(r"\.iast\s*=\s*0\b",diffs[0]["no_ast"])
    )
    noast_fit_pass=(
        noast["n_records"]==51 and not noast["fatal_hits"]
        and noast["weighted_RMS"] is not None
        and math.isfinite(noast["A2_au_d2"])
    )

    ratio_new=abs(FROZEN_TUDAT_A2)/abs(noast["A2_au_d2"]) if noast["A2_au_d2"]!=0 else math.inf
    log_gap_removed=(
        1-abs(math.log(max(ratio_new,1e-300)))/abs(math.log(FROZEN_RATIO))
        if math.isfinite(ratio_new) and ratio_new>0 else None
    )
    orbfit_a2_shift=(noast["A2_au_d2"]-baseline["A2_au_d2"])/abs(baseline["A2_au_d2"])
    rms_change=(
        (noast["weighted_RMS"]-baseline["weighted_RMS"])/baseline["weighted_RMS"]
        if baseline["weighted_RMS"] else None
    )

    validation={
      "stage":"PSS-5B3B controlled OrbFit massive-perturber ablation",
      "version":"1.0.1-parser-hotfix",
      "baseline_replay":baseline,
      "no_massive_asteroids":noast,
      "baseline_A2_relative_error_vs_frozen":rel,
      "baseline_RMS_relative_error_vs_frozen":rms_rel,
      "baseline_replay_pass":bool(baseline_pass),
      "FOP_differences":diffs,
      "controlled_one_line_iast_diff_pass":bool(controlled_diff_pass),
      "noast_fit_pass":bool(noast_fit_pass),
      "AST17_exact_index":bai,
      "frozen_Tudat_A2_au_d2":FROZEN_TUDAT_A2,
      "frozen_full_amplitude_ratio_abs":FROZEN_RATIO,
      "noast_harmonized_amplitude_ratio_abs":ratio_new,
      "OrbFit_A2_relative_shift_from_AST17_baseline":orbfit_a2_shift,
      "OrbFit_weighted_RMS_relative_change":rms_change,
      "fraction_of_log_amplitude_gap_removed":log_gap_removed,
      "scientific_test_valid":bool(baseline_pass and controlled_diff_pass and noast_fit_pass),
      "AST17_LAYER_PRIMARY_CAUSE_AUTHORIZED":False,
      "PHYSICAL_A2_DETECTION_AUTHORIZED":False,
      "YARKOVSKY_DETECTION_AUTHORIZED":False,
      "SINGLE_CAUSE_AUTHORIZED":False,
      "manuscript_policy":"Internal harmonisation evidence. Do not insert automatically; retain only if clean, necessary, and claim-safe."
    }
    (out/"PSS5B3B_VALIDATION.json").write_text(json.dumps(validation,indent=2,allow_nan=False),encoding="utf-8")
    (out/"PSS5B3B_BRANCH_RESULTS.json").write_text(json.dumps({"baseline":baseline,"no_ast":noast},indent=2),encoding="utf-8")

    report=f"""# PSS-5B3B controlled OrbFit perturber ablation

Baseline OrbFit AST17:
- A2 = `{baseline['A2_au_d2']:.17g} au d^-2`
- weighted RMS = `{baseline['weighted_RMS']}`
- baseline replay pass = `{baseline_pass}`

OrbFit with `.iast=0`:
- A2 = `{noast['A2_au_d2']:.17g} au d^-2`
- weighted RMS = `{noast['weighted_RMS']}`
- fit pass = `{noast_fit_pass}`

Frozen Tudat A2:
`{FROZEN_TUDAT_A2:.17g} au d^-2`

Cross-code amplitude ratio:
- frozen AST17 OrbFit denominator: `{FROZEN_RATIO:.9f}`
- no-massive-asteroid OrbFit denominator: `{ratio_new:.9f}`

OrbFit A2 relative shift after removing AST17:
`{orbfit_a2_shift:.6%}`

Weighted RMS relative change:
`{rms_change:.6%}`

Fraction of log-amplitude gap removed:
`{log_gap_removed:.6%}`

The only intended FOP change is `.iast=17 -> .iast=0`.
No guessed SPICE asteroid mapping or surrogate ephemeris is used.
No physical A2/Yarkovsky or single-cause claim is authorized by this stage.
"""
    (out/"PSS5B3B_REPORT.md").write_text(report,encoding="utf-8")
    print(json.dumps(validation,indent=2))
    return 0 if validation["scientific_test_valid"] else 2

if __name__=="__main__":
    raise SystemExit(main())
