from __future__ import annotations
from pathlib import Path
import argparse, json, math, shutil, tempfile, sys
import pandas as pd

PACKAGE_ROOT=Path(__file__).resolve().parents[1]
if str(PACKAGE_ROOT/"scripts") not in sys.path:
    sys.path.insert(0,str(PACKAGE_ROOT/"scripts"))
import pss3a2_nonlinear_correlated_refit as base

ORBFIT_A2=-4.1287077220144016e-13
BASE_RATIO=4.632897979626392
FROZEN_RECIP={
    "OrbFit_candidate_in_Tudat":370.02643130748265,
    "Tudat_candidate_in_OrbFit":12861.05166643932,
}

def dump(p,o):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(o,indent=2,allow_nan=False),encoding="utf-8")

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--project-root",type=Path,required=True)
    ap.add_argument("--package-root",type=Path,default=PACKAGE_ROOT)
    ap.add_argument("--output-root",type=Path,default=None)
    ap.add_argument("--max-outer-iterations",type=int,default=10)
    args=ap.parse_args()
    project=args.project_root.resolve(); package=args.package_root.resolve()
    out=(args.output_root.resolve() if args.output_root else project/"results"/"pss5b2b_lighttime_ablation_v100")
    if out.exists(): shutil.rmtree(out)
    out.mkdir(parents=True)

    oa=json.loads((package/"reference/PSS5B2B_ORBFIT_LIGHTTIME_CONFIG_AUDIT.json").read_text(encoding="utf-8"))
    if oa["effective_iaber_inferred"] != 1:
        raise RuntimeError("OrbFit iaber gate does not support this experiment")

    summary,bcov,bdesign,br,bsigma,p0,scales,conv=base.load_baseline(package)

    hashes={}
    for rel,expected in base.EXPECTED_HASHES.items():
        actual=base.sha256_file(project/rel)
        hashes[rel]={"expected":expected,"actual":actual,"match":actual==expected}
    dump(out/"PSS5B2B_SOURCE_HASH_AUDIT.json",hashes)
    if not all(v["match"] for v in hashes.values()):
        raise RuntimeError("Frozen source/input hash gate failed")

    work=Path(tempfile.mkdtemp(prefix="P5B2B_"))
    bwork=work/"baseline"; bwork.mkdir()
    bev=base.Evaluator(project,package,bwork,lighttime_mode="baseline")
    ev0=bev.evaluate(p0)
    replay=base.baseline_replay_gate(ev0,summary,bcov,bdesign,br,bsigma)
    dump(out/"PSS5B2B_BASELINE_REPLAY.json",replay)
    if not replay["overall_pass"]:
        raise RuntimeError("Baseline replay failed")

    prep,idx,err,scalar_blocks,groups=base.crosswalk_groups(project,ev0["residuals"])
    sigma=ev0["sigma"]

    rows=[]; branch_results={}
    for mode in ["max1","max2"]:
        bw=work/mode; bw.mkdir()
        evaluator=base.Evaluator(project,package,bw,lighttime_mode=mode)
        first=evaluator.evaluate(p0)
        audit=json.loads((first["dir"]/"PSS5B2B_LIGHTTIME_RUNTIME_AUDIT.json").read_text(encoding="utf-8"))
        (out/mode).mkdir(parents=True,exist_ok=True)
        dump(out/mode/"PSS5B2B_LIGHTTIME_RUNTIME_AUDIT.json",audit)
        result,history=base.optimize_rho(
            0.0,evaluator,p0,scales,groups,sigma,conv,args.max_outer_iterations,out/mode
        )
        pd.DataFrame(history).to_csv(out/mode/"PSS5B2B_ITERATION_HISTORY.csv",index=False,float_format="%.17g")
        a2=float(result["A2_au_d2"])
        ratio=abs(a2)/abs(ORBFIT_A2)
        rel=(a2-float(summary["A2_estimated_au_d2"]))/abs(float(summary["A2_estimated_au_d2"]))
        log_removed=1.0-abs(math.log(max(ratio,1e-300)))/abs(math.log(BASE_RATIO))
        rec={
            "mode":mode,
            "maximum_number_of_iterations":1 if mode=="max1" else 2,
            "converged":bool(result["converged"]),
            "status":result.get("status"),
            "A2_au_d2":a2,
            "sigma_scaled_au_d2":float(result["sigma_A2_overdispersion_scaled_au_d2"]),
            "normal_95_lo_au_d2":float(result["normal_approx_95_lo_au_d2"]),
            "normal_95_hi_au_d2":float(result["normal_approx_95_hi_au_d2"]),
            "interval_excludes_zero":bool(result["interval_excludes_zero"]),
            "relative_A2_shift_from_baseline":float(rel),
            "amplitude_ratio_abs":float(ratio),
            "fraction_of_log_amplitude_gap_removed":float(log_removed),
            "final_objective":float(result["final_objective"]),
            "reduced_chi2":float(result["reduced_correlated_chi2"]),
            "tudat_linearizations":evaluator.eval_count,
        }
        rows.append(rec); branch_results[mode]=rec

    pd.DataFrame(rows).to_csv(out/"PSS5B2B_LIGHTTIME_BRANCH_SUMMARY.csv",index=False,float_format="%.17g")
    validation={
        "stage":"PSS-5B2B light-time iteration sensitivity",
        "version":"1.0.0",
        "scientific_fit_executed":True,
        "orbfit_configuration_audit":oa,
        "baseline_replay":replay,
        "branches":branch_results,
        "max_abs_relative_A2_shift_from_baseline":float(max(abs(r["relative_A2_shift_from_baseline"]) for r in rows)),
        "best_amplitude_ratio_abs":float(min(r["amplitude_ratio_abs"] for r in rows)),
        "max_fraction_of_log_amplitude_gap_removed":float(max(r["fraction_of_log_amplitude_gap_removed"] for r in rows)),
        "all_branches_converged":bool(all(r["converged"] for r in rows)),
        "exact_OrbFit_aber1_emulation_claimed":False,
        "reciprocal_no_refit_metrics_recomputed":False,
        "frozen_reciprocal_no_refit_chi2_ratios":FROZEN_RECIP,
        "PHYSICAL_A2_DETECTION_AUTHORIZED":False,
        "YARKOVSKY_DETECTION_AUTHORIZED":False,
        "CAUSAL_EXPLANATION_AUTHORIZED":False,
        "claim_boundary_reason":"This is a light-time iteration-depth sensitivity test motivated by OrbFit iaber=1, not an exact reimplementation of aber1.",
        "PSS5B2B_LIGHTTIME_SENSITIVITY_READY":bool(all(r["converged"] for r in rows)),
    }
    dump(out/"PSS5B2B_LIGHTTIME_VALIDATION.json",validation)

    lines=["# PSS-5B2B light-time iteration sensitivity","",
           "OrbFit effective configuration: `iaber=1`.",
           "Tudat branches restrict the iterative light-time solution to 1 or 2 iterations.",
           "This is a sensitivity test, not an exact OrbFit aber1 emulator.",""]
    for r in rows:
        lines += [f"## {r['mode']}",
                  f"- A2 = `{r['A2_au_d2']:.17g} au d^-2`",
                  f"- |A2,T|/|A2,O| = `{r['amplitude_ratio_abs']:.9f}`",
                  f"- relative A2 shift = `{r['relative_A2_shift_from_baseline']:.6%}`",
                  f"- log-gap removed = `{r['fraction_of_log_amplitude_gap_removed']:.6%}`",
                  f"- final objective = `{r['final_objective']:.12g}`",
                  f"- converged = `{r['converged']}`",""]
    lines += ["Reciprocal no-refit metrics are not recomputed here.",
              "No physical A2, Yarkovsky, or single-cause claim is authorized."]
    (out/"PSS5B2B_LIGHTTIME_REPORT.md").write_text("\n".join(lines)+"\n",encoding="utf-8")
    print(json.dumps(validation,indent=2))
    return 0 if validation["PSS5B2B_LIGHTTIME_SENSITIVITY_READY"] else 2

if __name__=="__main__":
    raise SystemExit(main())
