from __future__ import annotations
from pathlib import Path
import argparse, json, math, hashlib, os, sys, traceback
import numpy as np
import pandas as pd

AU_M = 149_597_870_700.0
DAY_S = 86_400.0
YEAR_D = 365.25
YEAR_S = YEAR_D * DAY_S
AU_D2_TO_M_S2 = AU_M / DAY_S**2

def dump_json(path: Path, payload):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, allow_nan=False), encoding="utf-8")

def sha256(path: Path):
    h=hashlib.sha256()
    with path.open("rb") as f:
        for b in iter(lambda:f.read(1024*1024),b""): h.update(b)
    return h.hexdigest()

def unit(x):
    x=np.asarray(x,float)
    n=float(np.linalg.norm(x))
    if not np.isfinite(n) or n<=0: raise RuntimeError("non-finite/zero vector")
    return x/n

def orbfit_sec_nong9_accel_m_s2(x_m, v_m_s, dadt_au_Myr, mu_sun_m3_s2):
    # Exact algebraic transcription of the frozen OrbFit 5.0.8 sec_nong9 A2-only branch.
    # Convert state to the source routine's AU/year working units.
    x=np.asarray(x_m,float)/AU_M
    v=np.asarray(v_m_s,float)*YEAR_S/AU_M
    mu=float(mu_sun_m3_s2)*(YEAR_S**2)/(AU_M**3)
    rr=float(np.linalg.norm(x)); rr2=float(np.dot(x,x))
    vv2=float(np.dot(v,v)); rv=float(np.dot(x,v))
    h=np.cross(x,v); h2=float(np.dot(h,h))
    sqarg=max(2.0*mu/rr-vv2,0.0)
    factor=h2*math.sqrt(sqarg)/mu
    yark_acc=0.5*factor/1.0e6/rr2
    trans=v-x*rv/rr2
    t_hat=unit(trans)
    a_au_y2=float(dadt_au_Myr)*yark_acc*t_hat
    return a_au_y2*AU_M/(YEAR_S**2)

def tudat_a2_law_m_s2(x_m, v_m_s, A2_au_d2):
    r=np.asarray(x_m,float); v=np.asarray(v_m_s,float)
    rr=float(np.linalg.norm(r))
    rhat=unit(r)
    trans=v-rhat*float(np.dot(v,rhat))
    that=unit(trans)
    mag=float(A2_au_d2)*AU_D2_TO_M_S2*(AU_M/rr)**2
    return mag*that

def choose_grid(keys, start, end, max_n=512):
    keys=np.asarray(sorted(float(k) for k in keys if start <= float(k) <= end),float)
    if keys.size == 0: raise RuntimeError("No propagated states inside observation interval")
    if keys.size <= max_n: return keys
    idx=np.linspace(0,keys.size-1,max_n).round().astype(int)
    return keys[np.unique(idx)]

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--project-root", type=Path, required=True)
    ap.add_argument("--package-root", type=Path, required=True)
    ap.add_argument("--output-root", type=Path, required=True)
    args=ap.parse_args()
    project=args.project_root.resolve(); package=args.package_root.resolve(); out=args.output_root.resolve()
    out.mkdir(parents=True, exist_ok=True)
    src=project/"src"
    if str(src) not in sys.path: sys.path.insert(0,str(src))

    from darkcomet_stage2b.common import load_config
    from darkcomet_stage2b.tudat_compat import make_rkf78_integrator
    from tudatpy.interface import spice
    from tudatpy.dynamics import environment_setup, propagation_setup, simulator

    cand=json.loads((package/"inputs/tudat_candidate_summary.json").read_text(encoding="utf-8"))
    mapping=json.loads((package/"reference/stage3f3a_source_mapping_audit_v2_7_1.json").read_text(encoding="utf-8"))
    recon=json.loads((package/"reference/stage3f3c_final_reconciliation_summary_v3_1_0.json").read_text(encoding="utf-8"))
    cfg=load_config()

    # Exact project-lineage checks previously frozen in PSS3 preflight.
    audit={}
    expected={
      "scripts/03_run_model_family.py":"84686ac3da98dadc764188543ba81e5b4c840b0dc795d7b4a0aa6dbefe2af892",
      "config/stage2b.yaml":"4223acbb41e74f85005f3dbf95318f37a4b1f71af583b9bc57bfb92d3dd05c07",
      "data/processed/2020_GE_prepared_fallback_1.csv":"1fbc469f4c4e5a5c7630c76feeafbd8e1e8351879b88a41cf25a7aa97c574d3a",
    }
    for rel,exp in expected.items():
        p=project/rel
        act=sha256(p) if p.is_file() else None
        audit[rel]={"expected":exp,"actual":act,"match":act==exp}
    dump_json(out/"PSS5B1_SOURCE_HASH_AUDIT.json",audit)
    if not all(v["match"] for v in audit.values()):
        raise RuntimeError("Frozen project hash audit failed")

    spice.load_standard_kernels()
    dcfg=cfg["dynamics"]
    body_settings=environment_setup.get_default_body_settings(
        dcfg["bodies"], dcfg["global_frame_origin"], dcfg["global_frame_orientation"]
    )
    body_settings.add_empty_settings("2020 GE")
    bodies=environment_setup.create_system_of_bodies(body_settings)
    bodies.get("2020 GE").mass=1.0

    A2=float(cand["A2_estimated_au_d2"])
    A2_si=float(cand["A2_estimated_m_s2"])
    acc={
      "Sun":[
        propagation_setup.acceleration.point_mass_gravity(),
        propagation_setup.acceleration.relativistic_correction(use_schwarzschild=True),
        propagation_setup.acceleration.yarkovsky(A2_si),
      ],
      "Mercury":[propagation_setup.acceleration.point_mass_gravity()],
      "Venus":[propagation_setup.acceleration.point_mass_gravity()],
      "Earth":[propagation_setup.acceleration.point_mass_gravity()],
      "Moon":[propagation_setup.acceleration.point_mass_gravity()],
      "Mars":[propagation_setup.acceleration.point_mass_gravity()],
      "Jupiter":[propagation_setup.acceleration.point_mass_gravity()],
      "Saturn":[propagation_setup.acceleration.point_mass_gravity()],
      "Uranus":[propagation_setup.acceleration.point_mass_gravity()],
      "Neptune":[propagation_setup.acceleration.point_mass_gravity()],
    }
    models=propagation_setup.create_acceleration_models(
        bodies, {"2020 GE":acc}, ["2020 GE"], [dcfg["global_frame_origin"]]
    )
    t0=float(cand["propagation_epoch_start_tdb_s_j2000"])
    t1=float(cand["propagation_epoch_end_tdb_s_j2000"])
    obs0=float(cand["full_sample_epoch_start_tdb_s_j2000"])
    obs1=float(cand["full_sample_epoch_end_tdb_s_j2000"])
    state0=np.asarray(cand["final_parameter_vector"][:6],float)

    integ=make_rkf78_integrator(propagation_setup.integrator,dcfg)
    prop=propagation_setup.propagator.translational(
        central_bodies=[dcfg["global_frame_origin"]],
        acceleration_models=models,
        bodies_to_integrate=["2020 GE"],
        initial_states=state0,
        initial_time=t0,
        integrator_settings=integ,
        termination_settings=propagation_setup.propagator.time_termination(t1),
    )
    dyn=simulator.create_dynamics_simulator(bodies,prop)
    if not dyn.integration_completed_successfully:
        raise RuntimeError("Frozen Tudat trajectory propagation failed")
    hist=dyn.propagation_results.state_history
    grid=choose_grid(hist.keys(),obs0,obs1,512)

    mu=float(bodies.get("Sun").gravitational_parameter)
    dadt=float(mapping["Tudat"]["equivalent_OrbFit_dadt_au_Myr"])
    rows=[]
    for epoch in grid:
        # nearest propagated state key is exact because grid is selected from state_history keys
        target=np.asarray(hist[float(epoch)],float)
        sun=np.asarray(spice.get_body_cartesian_state_at_epoch(
            "Sun","SSB","J2000","NONE",float(epoch)
        ),float)
        x=target[:3]-sun[:3]; v=target[3:]-sun[3:]
        ao=orbfit_sec_nong9_accel_m_s2(x,v,dadt,mu)
        at=tudat_a2_law_m_s2(x,v,A2)
        mo=float(np.linalg.norm(ao)); mt=float(np.linalg.norm(at))
        dot=float(np.dot(unit(ao),unit(at))) if mo>0 and mt>0 else float("nan")
        ratio=mo/mt
        rows.append({
            "epoch_tdb_s_j2000":float(epoch),
            "heliocentric_r_au":float(np.linalg.norm(x)/AU_M),
            "heliocentric_speed_km_s":float(np.linalg.norm(v)/1000.0),
            "orbfit_sec_nong9_accel_m_s2":mo,
            "tudat_A2_r2_accel_m_s2":mt,
            "orbfit_to_tudat_force_ratio":ratio,
            "direction_cosine":dot,
            "fractional_modulation_from_unity":ratio-1.0,
        })
    df=pd.DataFrame(rows)
    df.to_csv(out/"PSS5B1_FORCE_LAW_SAME_STATE_GRID.csv",index=False)

    ratio=df["orbfit_to_tudat_force_ratio"].to_numpy(float)
    direction=df["direction_cosine"].to_numpy(float)
    baseline_ratio=float(recon["independent_fits"]["amplitude_ratio_abs"])
    summary={
      "stage":"PSS-5B1 same-state force-law equivalence",
      "version":"1.0.0",
      "scientific_fit_executed":False,
      "same_state_force_evaluation_executed":True,
      "n_grid_states":int(len(df)),
      "Tudat_A2_au_d2":A2,
      "Tudat_equivalent_OrbFit_dadt_au_Myr":dadt,
      "force_ratio_min":float(np.min(ratio)),
      "force_ratio_median":float(np.median(ratio)),
      "force_ratio_max":float(np.max(ratio)),
      "max_abs_fractional_modulation":float(np.max(np.abs(ratio-1.0))),
      "direction_cosine_min":float(np.min(direction)),
      "baseline_cross_code_A2_amplitude_ratio":baseline_ratio,
      "required_factor_4p633_inside_instantaneous_force_ratio_range":
          bool(np.min(ratio) <= baseline_ratio <= np.max(ratio)),
      "required_inverse_factor_inside_instantaneous_force_ratio_range":
          bool(np.min(ratio) <= 1.0/baseline_ratio <= np.max(ratio)),
      "baseline_reciprocal_no_refit_chi2_ratios":{
          "OrbFit_candidate_in_Tudat":float(recon["reciprocal_no_refit"]["B1_OrbFit_candidate_in_Tudat"]["chi2_ratio_to_receiving_optimum"]),
          "Tudat_candidate_in_OrbFit":float(recon["reciprocal_no_refit"]["B2_Tudat_candidate_in_OrbFit"]["chi2_ratio_to_receiving_optimum"]),
      },
      "claim_boundary":{
          "physical_A2_detection_authorized":False,
          "Yarkovsky_detection_authorized":False,
          "note":"This stage isolates instantaneous force-law normalization/direction only; it does not refit either code and therefore does not by itself change the frozen amplitude or reciprocal-transport metrics."
      }
    }
    # Quantitative, non-arbitrary disposition.
    summary["instantaneous_force_normalization_can_span_observed_amplitude_gap"] = bool(
        summary["required_factor_4p633_inside_instantaneous_force_ratio_range"] or
        summary["required_inverse_factor_inside_instantaneous_force_ratio_range"]
    )
    dump_json(out/"PSS5B1_SUMMARY.json",summary)

    md=f"""# PSS-5B1 force-law equivalence report

Frozen cross-code amplitude ratio: **{baseline_ratio:.6f}**.

Same-state OrbFit/Tudat instantaneous transverse-force ratio:
- minimum: **{summary['force_ratio_min']:.9g}**
- median: **{summary['force_ratio_median']:.9g}**
- maximum: **{summary['force_ratio_max']:.9g}**
- maximum |ratio-1|: **{summary['max_abs_fractional_modulation']:.3%}**
- minimum direction cosine: **{summary['direction_cosine_min']:.12f}**

The observed factor-4.633 coefficient gap is {"inside" if summary["instantaneous_force_normalization_can_span_observed_amplitude_gap"] else "outside"} the instantaneous force-normalization range sampled on the frozen same-state trajectory.

This stage does not re-estimate either orbit and therefore does not alter the frozen reciprocal no-refit chi-square ratios ({summary['baseline_reciprocal_no_refit_chi2_ratios']['OrbFit_candidate_in_Tudat']:.3f}, {summary['baseline_reciprocal_no_refit_chi2_ratios']['Tudat_candidate_in_OrbFit']:.3f}).

Physical A2 and Yarkovsky claims remain blocked.
"""
    (out/"PSS5B1_REPORT.md").write_text(md,encoding="utf-8")
    print(json.dumps(summary,indent=2))
    return 0

if __name__=="__main__":
    try:
        raise SystemExit(main())
    except Exception:
        traceback.print_exc()
        raise
