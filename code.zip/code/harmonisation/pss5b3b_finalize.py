from pathlib import Path
import argparse,hashlib,zipfile
ap=argparse.ArgumentParser()
ap.add_argument("--project-root",type=Path,required=True)
ap.add_argument("--output-root",type=Path,required=True)
a=ap.parse_args()
project=a.project_root.resolve(); out=a.output_root.resolve()
if not (out/"PSS5B3B_VALIDATION.json").is_file(): raise SystemExit(2)
rows=[]
for p in sorted(out.rglob("*")):
    if p.is_file() and p.name!="MANIFEST_SHA256.txt":
        rows.append(f"{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.relative_to(out).as_posix()}")
(out/"MANIFEST_SHA256.txt").write_text("\n".join(rows)+"\n",encoding="utf-8")
zp=project/"2020_GE_PSS5B3B_ORBFIT_PERTURBER_OUTPUTS_v1_0_1.zip"
with zipfile.ZipFile(zp,"w",zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(out.rglob("*")):
        if p.is_file():
            z.write(p,arcname=f"2020_GE_PSS5B3B_ORBFIT_PERTURBER_OUTPUTS_v1_0_1/{p.relative_to(out).as_posix()}")
print("PSS5B3B_OUTPUT_ARCHIVE="+str(zp))
