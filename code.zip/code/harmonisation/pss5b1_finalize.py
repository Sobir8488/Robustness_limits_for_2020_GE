from pathlib import Path
import argparse, zipfile, hashlib, json, os
ap=argparse.ArgumentParser()
ap.add_argument("--output-root",type=Path,required=True)
ap.add_argument("--project-root",type=Path,required=True)
args=ap.parse_args()
out=args.output_root.resolve(); project=args.project_root.resolve()
if not (out/"PSS5B1_SUMMARY.json").is_file(): raise SystemExit(2)
manifest=[]
for p in sorted(out.rglob("*")):
    if p.is_file() and p.name!="MANIFEST_SHA256.txt":
        h=hashlib.sha256(p.read_bytes()).hexdigest()
        manifest.append(f"{h}  {p.relative_to(out).as_posix()}")
(out/"MANIFEST_SHA256.txt").write_text("\n".join(manifest)+"\n",encoding="utf-8")
zp=project/"2020_GE_PSS5B1_OUTPUTS_v1_0_0.zip"
with zipfile.ZipFile(zp,"w",zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(out.rglob("*")):
        if p.is_file(): z.write(p,arcname=f"2020_GE_PSS5B1_OUTPUTS_v1_0_0/{p.relative_to(out).as_posix()}")
print("PSS5B1_OUTPUT_ARCHIVE="+str(zp))
