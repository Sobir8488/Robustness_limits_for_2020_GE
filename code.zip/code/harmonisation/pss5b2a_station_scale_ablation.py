from __future__ import annotations
from pathlib import Path
import argparse, json, math, os, re, subprocess, tempfile, hashlib, shutil, sys
import numpy as np
import pandas as pd

PACKAGE_ROOT = Path(__file__).resolve().parents[1]
if str(PACKAGE_ROOT/"scripts") not in sys.path:
    sys.path.insert(0, str(PACKAGE_ROOT/"scripts"))

import pss3a2_nonlinear_correlated_refit as base

FALLBACK_ORBFIT_RADIUS_M = 6378136.3000000007
ORBFIT_A2_AU_D2 = -4.1287077220144016e-13
FROZEN_BASELINE_RATIO = 4.632897979626392
FROZEN_RECIPROCAL = {
    "OrbFit_candidate_in_Tudat": 370.02643130748265,
    "Tudat_candidate_in_OrbFit": 12861.05166643932,
}

def dump(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, allow_nan=False), encoding="utf-8")

def run_wsl_text(cmd):
    try:
        p=subprocess.run(["wsl.exe","bash","-lc",cmd],
                         stdout=subprocess.PIPE,stderr=subprocess.STDOUT,
                         text=True,errors="replace",timeout=60)
        return p.returncode,p.stdout
    except Exception as exc:
        return 999, f"{type(exc).__name__}: {exc}"

def extract_fortran_assignments(text):
    # Sufficient for the simple PARAMETER assignments in fund_const.
    joined=[]
    buf=""
    for raw in text.splitlines():
        line=raw.split("!",1)[0].strip()
        if not line:
            continue
        if line.endswith("&"):
            buf += line[:-1] + " "
            continue
        if line.startswith("&"):
            line=line[1:].strip()
        if buf:
            line=buf+line
            buf=""
        joined.append(line)
    assigns={}
    for line in joined:
        # handle declarations such as DOUBLE PRECISION, PARAMETER :: aukm=..., reau=...
        rhs_part=line.split("::",1)[-1] if "::" in line else line
        for piece in rhs_part.split(","):
            if "=" in piece:
                name,expr=piece.split("=",1)
                name=name.strip().lower()
                expr=expr.strip()
                if re.match(r"^[a-z_][a-z0-9_]*$",name):
                    assigns[name]=expr
    return assigns

def safe_eval_expr(expr, env, depth=0):
    if depth>12:
        raise ValueError("expression recursion too deep")
    e=expr.lower().replace("d+","e+").replace("d-","e-")
    e=re.sub(r"(?<=\d)d(?=\d)", "e", e)
    names=set(re.findall(r"\b[a-z_][a-z0-9_]*\b",e))
    for name in sorted(names,key=len,reverse=True):
        if name in env:
            val=env[name] if isinstance(env[name],(int,float)) else safe_eval_expr(env[name],env,depth+1)
            e=re.sub(rf"\b{re.escape(name)}\b", f"({float(val):.17g})", e)
        elif name not in {"e"}:
            raise ValueError(f"unresolved symbol {name} in {expr}")
    if not re.match(r"^[0-9eE+\-*/(). ]+$", e):
        raise ValueError(f"unsafe expression {e}")
    return float(eval(e, {"__builtins__":{}}, {}))

def resolve_orbfit_reau_radius(out):
    stage="/home/globularclusters/stage3_orbfit"
    rc,paths=run_wsl_text(
        "find -L '"+stage+"' -type f -iname 'fund_const.f90' 2>/dev/null | head -n 20"
    )
    pathlist=[x.strip() for x in paths.splitlines() if x.strip()]
    audit={"search_return_code":rc,"candidate_paths":pathlist}
    for path in pathlist:
        rc2,text=run_wsl_text("cat '"+path.replace("'","'\\''")+"'")
        if rc2!=0 or not text.strip():
            continue
        (out/"ORBFIT_fund_const_runtime.f90").write_text(text,encoding="utf-8")
        assigns=extract_fortran_assignments(text)
        audit["selected_path"]=path
        audit["assignment_keys"]=sorted(assigns.keys())
        try:
            reau=safe_eval_expr(assigns["reau"],assigns)
            # reau is OrbFit's Earth radius in AU. Recover metres using aukm when present,
            # otherwise the exact SI AU.
            if "aukm" in assigns:
                aukm=safe_eval_expr(assigns["aukm"],assigns)
                radius_m=reau*aukm*1000.0
                audit.update({"reau_au":reau,"aukm":aukm,"radius_m":radius_m,
                               "provenance":"runtime fund_const: reau * aukm * 1000"})
            else:
                radius_m=reau*149597870700.0
                audit.update({"reau_au":reau,"radius_m":radius_m,
                               "provenance":"runtime fund_const: reau * exact SI AU"})
            if 6.0e6 < radius_m < 7.0e6:
                dump(out/"PSS5B2A_ORBFIT_RADIUS_AUDIT.json",audit)
                return float(radius_m), audit
        except Exception as exc:
            audit["parse_error"]=f"{type(exc).__name__}: {exc}"
    audit.update({
        "radius_m":FALLBACK_ORBFIT_RADIUS_M,
        "provenance":"fallback exact OrbFit station_coordinates.f90 earth_radius parameter",
        "fallback_used":True,
    })
    dump(out/"PSS5B2A_ORBFIT_RADIUS_AUDIT.json",audit)
    return FALLBACK_ORBFIT_RADIUS_M,audit

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--project-root",type=Path,required=True)
    ap.add_argument("--package-root",type=Path,default=PACKAGE_ROOT)
    ap.add_argument("--output-root",type=Path,default=None)
    ap.add_argument("--max-outer-iterations",type=int,default=8)
    args=ap.parse_args()

    project=args.project_root.resolve()
    package=args.package_root.resolve()
    out=(args.output_root.resolve() if args.output_root else
         project/"results"/"pss5b2a_station_scale_ablation_v100")
    if out.exists():
        shutil.rmtree(out)
    out.mkdir(parents=True)

    summary, baseline_cov, baseline_design, baseline_r, baseline_sigma, p0, scales, conv = base.load_baseline(package)

    # Frozen lineage gate.
    hash_audit={}
    for rel,expected in base.EXPECTED_HASHES.items():
        path=project/rel
        actual=base.sha256_file(path)
        hash_audit[rel]={"expected":expected,"actual":actual,"match":actual==expected}
    dump(out/"PSS5B2A_SOURCE_HASH_AUDIT.json",hash_audit)
    if not all(v["match"] for v in hash_audit.values()):
        raise RuntimeError("Frozen source/input hash gate failed")

    target_radius_m,radius_audit=resolve_orbfit_reau_radius(out)

    work=Path(tempfile.mkdtemp(prefix="P5B2A_"))
    baseline_work=work/"baseline"; baseline_work.mkdir()
    harm_work=work/"harmonized"; harm_work.mkdir()

    baseline_eval=base.Evaluator(project,package,baseline_work,
                                 station_scale_mode="baseline",
                                 orbfit_parallax_radius_m=None)
    harm_eval=base.Evaluator(project,package,harm_work,
                             station_scale_mode="orbfit_equatorial",
                             orbfit_parallax_radius_m=target_radius_m)

    # Exact baseline replay proves that the station-scale patch is inert in baseline mode.
    ev0=baseline_eval.evaluate(p0)
    replay=base.baseline_replay_gate(
        ev0,summary,baseline_cov,baseline_design,baseline_r,baseline_sigma
    )
    dump(out/"PSS5B2A_BASELINE_REPLAY.json",replay)
    if not replay["overall_pass"]:
        raise RuntimeError("Baseline replay failed; station-scale ablation blocked")

    # Build the ordinary diagonal likelihood (rho=0) with the existing frozen weights.
    prep,idx,err,scalar_blocks,groups=base.crosswalk_groups(project,ev0["residuals"])
    sigma=ev0["sigma"]

    # Evaluate the frozen baseline parameter vector under the harmonized station scale.
    evh0=harm_eval.evaluate(p0)
    C,L=base.build_covariance(sigma,groups,0.0)
    q_harmonized_at_baseline=base.objective(evh0["r"],L)
    q_baseline_at_baseline=base.objective(ev0["r"],L)

    # Full nonlinear 7-parameter M_Y re-estimation, identical to PSS3-A2 rho=0
    # except for the controlled MPC parallax-radius rescaling.
    result,history=base.optimize_rho(
        0.0,harm_eval,p0,scales,groups,sigma,conv,
        args.max_outer_iterations,out
    )

    # Recover station-scale audit from the first harmonized evaluation.
    station_audit_file=evh0["dir"]/"PSS5B2A_STATION_SCALE_AUDIT.json"
    station_audit=json.loads(station_audit_file.read_text(encoding="utf-8"))
    dump(out/"PSS5B2A_STATION_SCALE_RUNTIME_AUDIT.json",station_audit)

    a2_new=float(result["A2_au_d2"])
    ratio_new=abs(a2_new)/abs(ORBFIT_A2_AU_D2)
    baseline_a2=float(summary["A2_estimated_au_d2"])
    rel_shift=(a2_new-baseline_a2)/abs(baseline_a2)
    log_gap_removed=(
        1.0-abs(math.log(max(ratio_new,1e-300)))/abs(math.log(FROZEN_BASELINE_RATIO))
        if FROZEN_BASELINE_RATIO>0 and FROZEN_BASELINE_RATIO!=1 else None
    )

    validation={
        "stage":"PSS-5B2A controlled station parallax-radius ablation",
        "version":"1.0.1-postprocess-hotfix",
        "scientific_fit_executed":True,
        "baseline_replay":replay,
        "station_catalogue_values_identical_before_radius_scaling":True,
        "orbfit_target_radius_m":target_radius_m,
        "orbfit_radius_provenance":radius_audit.get("provenance"),
        "tudat_earth_average_radius_m":station_audit["tudat_earth_average_radius_m"],
        "parallax_scale_factor":station_audit["parallax_constant_scale_factor"],
        "max_body_fixed_station_shift_m":station_audit["max_body_fixed_shift_norm_m"],
        "baseline_Tudat_A2_au_d2":baseline_a2,
        "harmonized_A2_au_d2":a2_new,
        "harmonized_sigma_scaled_au_d2":float(result["sigma_A2_overdispersion_scaled_au_d2"]),
        "relative_A2_shift_from_baseline":float(rel_shift),
        "frozen_OrbFit_A2_au_d2":ORBFIT_A2_AU_D2,
        "frozen_baseline_amplitude_ratio_abs":FROZEN_BASELINE_RATIO,
        "harmonized_amplitude_ratio_abs":float(ratio_new),
        "fraction_of_log_amplitude_gap_removed":float(log_gap_removed),
        "baseline_diagonal_objective":float(q_baseline_at_baseline),
        "harmonized_objective_at_frozen_baseline_parameters":float(q_harmonized_at_baseline),
        "harmonized_final_objective":float(result["final_objective"]),
        "harmonized_converged":bool(result["converged"]),
        "harmonized_interval_excludes_zero":bool(result["interval_excludes_zero"]),
        "tudat_linearizations_baseline":baseline_eval.eval_count,
        "tudat_linearizations_harmonized":harm_eval.eval_count,
        "reciprocal_no_refit_metrics_recomputed":False,
        "frozen_reciprocal_no_refit_chi2_ratios":FROZEN_RECIPROCAL,
        "PHYSICAL_A2_DETECTION_AUTHORIZED":False,
        "YARKOVSKY_DETECTION_AUTHORIZED":False,
        "CAUSAL_EXPLANATION_AUTHORIZED":False,
        "claim_boundary_reason":(
            "This is a one-layer controlled station-coordinate scaling ablation. "
            "It can measure how much of the fitted amplitude gap moves under that layer, "
            "but it does not by itself identify all observation-model differences and does "
            "not supersede support-resampling, G37 identifiability, reciprocal transport, or radar gates."
        ),
        "PSS5B2A_STATION_SCALE_ABLATION_READY":bool(result["converged"]),
    }
    dump(out/"PSS5B2A_STATION_SCALE_VALIDATION.json",validation)
    pd.DataFrame(history).to_csv(out/"PSS5B2A_STATION_SCALE_ITERATION_HISTORY.csv",
                                 index=False,float_format="%.17g")

    report=f"""# PSS-5B2A station parallax-radius ablation

- OrbFit target parallax radius: **{target_radius_m:.6f} m**
- Tudat Earth average radius used by BatchMPC: **{station_audit['tudat_earth_average_radius_m']:.6f} m**
- parallax-constant scale factor: **{station_audit['parallax_constant_scale_factor']:.12f}**
- maximum body-fixed station shift induced by harmonisation: **{station_audit['max_body_fixed_shift_norm_m']:.3f} m**

Frozen Tudat A2:
`{baseline_a2:.17g} au d^-2`

Station-scale-harmonized A2:
`{a2_new:.17g} au d^-2`

Frozen |A2,T|/|A2,O|:
`{FROZEN_BASELINE_RATIO:.9f}`

Harmonized |A2,T|/|A2,O|:
`{ratio_new:.9f}`

Relative A2 shift from the frozen Tudat solution:
`{rel_shift:.6%}`

Fraction of the log-amplitude gap removed:
`{log_gap_removed:.6%}`

The reciprocal no-refit chi-square ratios were **not** recomputed in this substage
and remain frozen at {FROZEN_RECIPROCAL['OrbFit_candidate_in_Tudat']:.6f} and
{FROZEN_RECIPROCAL['Tudat_candidate_in_OrbFit']:.6f}.

No physical A2/Yarkovsky or single-cause claim is authorized by this stage.
"""
    (out/"PSS5B2A_STATION_SCALE_REPORT.md").write_text(report,encoding="utf-8")
    print(json.dumps(validation,indent=2))
    return 0 if validation["PSS5B2A_STATION_SCALE_ABLATION_READY"] else 2

if __name__=="__main__":
    raise SystemExit(main())
