from __future__ import annotations
from pathlib import Path
import argparse, json, math, shutil, tempfile, sys
import numpy as np
import pandas as pd

PACKAGE_ROOT = Path(__file__).resolve().parents[1]
if str(PACKAGE_ROOT/"scripts") not in sys.path:
    sys.path.insert(0, str(PACKAGE_ROOT/"scripts"))
import pss3a2_nonlinear_correlated_refit as base

ORBFIT_A2_AU_D2 = -4.1287077220144016e-13
FROZEN_BASELINE_RATIO = 4.632897979626392
FROZEN_RECIPROCAL = {
    "OrbFit_candidate_in_Tudat": 370.02643130748265,
    "Tudat_candidate_in_OrbFit": 12861.05166643932,
}

def dump(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, allow_nan=False), encoding="utf-8")

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--project-root",type=Path,required=True)
    ap.add_argument("--package-root",type=Path,default=PACKAGE_ROOT)
    ap.add_argument("--output-root",type=Path,default=None)
    ap.add_argument("--max-outer-iterations",type=int,default=10)
    args=ap.parse_args()

    project=args.project_root.resolve()
    package=args.package_root.resolve()
    out=(args.output_root.resolve() if args.output_root else project/"results"/"pss5b3r_relativity_ablation_v100")
    if out.exists():
        shutil.rmtree(out)
    out.mkdir(parents=True)

    config_audit=json.loads((package/"reference/PSS5B3R_ORBFIT_RELATIVITY_CONFIG_AUDIT.json").read_text(encoding="utf-8"))
    if not config_audit["configuration_supports_newtonian_default_for_this_run"]:
        raise RuntimeError("OrbFit configuration gate does not support the planned relativity-off ablation")

    summary, baseline_cov, baseline_design, baseline_r, baseline_sigma, p0, scales, conv = base.load_baseline(package)

    hash_audit={}
    for rel,expected in base.EXPECTED_HASHES.items():
        actual=base.sha256_file(project/rel)
        hash_audit[rel]={"expected":expected,"actual":actual,"match":actual==expected}
    dump(out/"PSS5B3R_SOURCE_HASH_AUDIT.json",hash_audit)
    if not all(v["match"] for v in hash_audit.values()):
        raise RuntimeError("Frozen source/input hash gate failed")

    work=Path(tempfile.mkdtemp(prefix="P5B3R_"))
    bwork=work/"baseline"; bwork.mkdir()
    owork=work/"relativity_off"; owork.mkdir()
    baseline_eval=base.Evaluator(project,package,bwork,relativity_mode="baseline")
    off_eval=base.Evaluator(project,package,owork,relativity_mode="off")

    ev0=baseline_eval.evaluate(p0)
    replay=base.baseline_replay_gate(ev0,summary,baseline_cov,baseline_design,baseline_r,baseline_sigma)
    dump(out/"PSS5B3R_BASELINE_REPLAY.json",replay)
    if not replay["overall_pass"]:
        raise RuntimeError("Baseline replay failed")

    prep,idx,err,scalar_blocks,groups=base.crosswalk_groups(project,ev0["residuals"])
    sigma=ev0["sigma"]
    C,L=base.build_covariance(sigma,groups,0.0)

    evoff0=off_eval.evaluate(p0)
    q_off_at_baseline=float(base.objective(evoff0["r"],L))
    q_base_at_baseline=float(base.objective(ev0["r"],L))
    off_mode_audit=json.loads((evoff0["dir"]/"PSS5B3R_RELATIVITY_MODE_AUDIT.json").read_text(encoding="utf-8"))
    dump(out/"PSS5B3R_RELATIVITY_MODE_RUNTIME_AUDIT.json",off_mode_audit)

    result,history=base.optimize_rho(
        0.0,off_eval,p0,scales,groups,sigma,conv,args.max_outer_iterations,out
    )

    baseline_a2=float(summary["A2_estimated_au_d2"])
    a2_new=float(result["A2_au_d2"])
    ratio_new=abs(a2_new)/abs(ORBFIT_A2_AU_D2)
    rel_shift=(a2_new-baseline_a2)/abs(baseline_a2)
    gap_change=(FROZEN_BASELINE_RATIO-ratio_new)/FROZEN_BASELINE_RATIO
    log_gap_removed=(
        1.0-abs(math.log(max(ratio_new,1e-300)))/abs(math.log(FROZEN_BASELINE_RATIO))
        if ratio_new>0 else None
    )
    objective_change=(float(result["final_objective"])-q_base_at_baseline)/q_base_at_baseline

    validation={
        "stage":"PSS-5B3R controlled relativity ablation",
        "version":"1.0.0",
        "scientific_fit_executed":True,
        "orbfit_configuration_audit":config_audit,
        "baseline_replay":replay,
        "tudat_baseline_schwarzschild":True,
        "tudat_ablation_schwarzschild":False,
        "baseline_Tudat_A2_au_d2":baseline_a2,
        "relativity_off_Tudat_A2_au_d2":a2_new,
        "relativity_off_sigma_scaled_au_d2":float(result["sigma_A2_overdispersion_scaled_au_d2"]),
        "relative_A2_shift_from_baseline":float(rel_shift),
        "frozen_OrbFit_A2_au_d2":ORBFIT_A2_AU_D2,
        "frozen_baseline_amplitude_ratio_abs":FROZEN_BASELINE_RATIO,
        "relativity_off_amplitude_ratio_abs":float(ratio_new),
        "fractional_reduction_in_amplitude_ratio":float(gap_change),
        "fraction_of_log_amplitude_gap_removed":float(log_gap_removed),
        "baseline_objective_at_baseline_parameters":q_base_at_baseline,
        "relativity_off_objective_at_baseline_parameters":q_off_at_baseline,
        "relativity_off_final_objective":float(result["final_objective"]),
        "relative_final_objective_change_vs_frozen_baseline":float(objective_change),
        "relativity_off_reduced_chi2":float(result["reduced_correlated_chi2"]),
        "relativity_off_converged":bool(result["converged"]),
        "relativity_off_status":result.get("status"),
        "relativity_off_interval_excludes_zero":bool(result["interval_excludes_zero"]),
        "relativity_off_normal_95_lo_au_d2":float(result["normal_approx_95_lo_au_d2"]),
        "relativity_off_normal_95_hi_au_d2":float(result["normal_approx_95_hi_au_d2"]),
        "tudat_linearizations_baseline":baseline_eval.eval_count,
        "tudat_linearizations_relativity_off":off_eval.eval_count,
        "reciprocal_no_refit_metrics_recomputed":False,
        "frozen_reciprocal_no_refit_chi2_ratios":FROZEN_RECIPROCAL,
        "PHYSICAL_A2_DETECTION_AUTHORIZED":False,
        "YARKOVSKY_DETECTION_AUTHORIZED":False,
        "CAUSAL_EXPLANATION_AUTHORIZED":False,
        "claim_boundary_reason":"This is a one-layer Tudat relativity ablation motivated by the recovered OrbFit configuration. It does not supersede support-resampling, G37 identifiability, reciprocal transport, radar closure, or remaining forward/observation-model layers.",
        "PSS5B3R_RELATIVITY_ABLATION_READY":bool(result["converged"]),
    }
    dump(out/"PSS5B3R_RELATIVITY_VALIDATION.json",validation)
    pd.DataFrame(history).to_csv(out/"PSS5B3R_RELATIVITY_ITERATION_HISTORY.csv",index=False,float_format="%.17g")

    report=f"""# PSS-5B3R relativity ablation

Recovered OrbFit configuration:
- `propag.def`: `irel = {config_audit['orbfit_propag_def_irel_default']}`
- actual `2020GE.fop`: no `irel` override

Controlled Tudat change:
- baseline: Sun point-mass gravity + Schwarzschild correction
- ablation: Sun point-mass gravity only
- all other force, observation, weighting, integration, and fitting settings frozen

Frozen Tudat A2:
`{baseline_a2:.17g} au d^-2`

Relativity-off Tudat A2:
`{a2_new:.17g} au d^-2`

Frozen |A2,T|/|A2,O|:
`{FROZEN_BASELINE_RATIO:.9f}`

Relativity-off |A2,T|/|A2,O|:
`{ratio_new:.9f}`

Relative A2 shift:
`{rel_shift:.6%}`

Fraction of the log-amplitude gap removed:
`{log_gap_removed:.6%}`

Baseline objective:
`{q_base_at_baseline:.12g}`

Relativity-off objective at frozen baseline parameters:
`{q_off_at_baseline:.12g}`

Relativity-off final objective:
`{float(result['final_objective']):.12g}`

Reciprocal no-refit chi-square ratios are not recomputed in this substage.
No physical A2, Yarkovsky, or single-cause claim is authorized.
"""
    (out/"PSS5B3R_RELATIVITY_REPORT.md").write_text(report,encoding="utf-8")
    print(json.dumps(validation,indent=2))
    return 0 if validation["PSS5B3R_RELATIVITY_ABLATION_READY"] else 2

if __name__=="__main__":
    raise SystemExit(main())
