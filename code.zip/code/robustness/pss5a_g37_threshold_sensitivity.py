from pathlib import Path
import argparse, json
import pandas as pd
import numpy as np

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--package-root',type=Path,default=Path(__file__).resolve().parents[1]); ap.add_argument('--output-root',type=Path,required=True)
    ap.add_argument('--thresholds',default='5,7.5,10,15,20'); args=ap.parse_args()
    pkg=args.package_root.resolve(); out=args.output_root.resolve(); out.mkdir(parents=True,exist_ok=True)
    df=pd.read_csv(pkg/'inputs/stage4b5_case_rankloss_v102.csv')
    ts=[float(x) for x in args.thresholds.split(',') if x.strip()]
    rows=[]
    for T in ts:
        for arm,g in df.groupby('arm'):
            pos=g[(g.fraction>0)&(~g.remove_rows.astype(bool))].copy()
            severe=(pos.objective_ratio_to_fraction_1>=T)&(pos.sigma_to_baseline_abs_A2_ratio>=T)&pos.zero_seed_family_exact_zero.astype(bool)&pos.negative_seed_family_constant.astype(bool)&pos.low_weight_seed_family_invariance.astype(bool)
            sev=pos[severe]; resolved=pos[~severe]
            largest_severe=float(sev.fraction.max()) if len(sev) else np.nan
            smaller_resolved=resolved[resolved.fraction>largest_severe] if np.isfinite(largest_severe) else resolved
            nearest_resolved=float(smaller_resolved.fraction.min()) if len(smaller_resolved) else np.nan
            rows.append({'threshold':T,'arm':arm,'n_severe_cases':int(len(sev)),'largest_fraction_severe':largest_severe,'nearest_larger_resolved_fraction':nearest_resolved,'onset_bracket_low':largest_severe,'onset_bracket_high':nearest_resolved})
    r=pd.DataFrame(rows); r.to_csv(out/'PSS5A_G37_THRESHOLD_SENSITIVITY.csv',index=False,float_format='%.17g')
    stable=True; byarm={}
    for arm,g in r.groupby('arm'):
        lows=set(g.onset_bracket_low.dropna().tolist()); highs=set(g.onset_bracket_high.dropna().tolist())
        ok=(len(lows)==1 and len(highs)==1); stable &= ok
        byarm[arm]={'stable_across_thresholds':bool(ok),'onset_bracket':[min(lows) if lows else None,min(highs) if highs else None]}
    val={'stage':'PSS-5A G37 threshold sensitivity','version':'1.0.0','thresholds':ts,'threshold_definition':'severe iff objective ratio >= T AND sigma inflation ratio >= T AND low-weight seed-family locking invariants are present','threshold_independent_onset':bool(stable),'arms':byarm,'PSS5A2_G37_THRESHOLD_CLOSURE_READY':bool(stable),'interpretation':'The practical-identifiability transition is insensitive to moving the operational objective/uncertainty multiplier from 5x to 20x. Use severe ill-conditioning / practical identifiability language, not algebraic rank loss.'}
    (out/'PSS5A_G37_THRESHOLD_VALIDATION.json').write_text(json.dumps(val,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(val,indent=2)); return 0 if stable else 2
if __name__=='__main__': raise SystemExit(main())
