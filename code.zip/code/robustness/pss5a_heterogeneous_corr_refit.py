from __future__ import annotations
from pathlib import Path
import argparse, itertools, json, math, os, shutil, sys, tempfile, zipfile, hashlib, traceback
import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))
import pss3a2_nonlinear_correlated_refit as base

LINE_SEARCH = base.LINE_SEARCH
DOF = base.DOF


def dump_json(path: Path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, default=float) + "\n", encoding="utf-8")


def crosswalk_station_metadata(project_root: Path, residual_table: pd.DataFrame):
    prep, idx, err, scalar_blocks, _ = base.crosswalk_groups(project_root, residual_table)
    stations_pos = prep["stn"].astype(str).str.strip().to_numpy()[idx]
    scalar_stations = np.repeat(stations_pos, 2)
    components = residual_table["component"].astype(str).to_numpy()
    if len(scalar_stations) != len(components):
        raise RuntimeError("station/component scalar length mismatch")
    return prep, idx, err, scalar_blocks, scalar_stations, components


def station_class(stn: str) -> str:
    s = str(stn).strip().upper()
    if s == "F51": return "F51"
    if s == "G37": return "G37"
    return "REST"


def build_hetero_covariance(sigmas, scalar_blocks, scalar_stations, components, rho_map):
    n=len(sigmas)
    C=np.zeros((n,n),float)
    group_labels=np.asarray([f"{b}|{c}" for b,c in zip(scalar_blocks,components)],dtype=object)
    for label in dict.fromkeys(group_labels.tolist()):
        ii=np.where(group_labels==label)[0]
        classes={station_class(scalar_stations[j]) for j in ii}
        if len(classes)!=1:
            raise RuntimeError(f"mixed station class inside station-night/component group {label}: {classes}")
        cls=next(iter(classes)); rho=float(rho_map[cls])
        m=len(ii)
        R=np.full((m,m),rho,float); np.fill_diagonal(R,1.0)
        C[np.ix_(ii,ii)] = R*np.outer(sigmas[ii],sigmas[ii])
    if np.any(np.diag(C)<=0): raise RuntimeError("invalid covariance diagonal")
    L=np.linalg.cholesky(C)
    return C,L


def optimize_case(case_id, rho_map, evaluator, p_start, scales, scalar_blocks, scalar_stations, components, sigma, conv, max_iter, output_root):
    C,L=build_hetero_covariance(sigma,scalar_blocks,scalar_stations,components,rho_map)
    p=np.asarray(p_start,float).copy(); history=[]; converged=False; status="MAX_ITERATIONS"
    ev=evaluator.evaluate(p); q=base.objective(ev["r"],L)
    for iteration in range(max_iter):
        dp,rank,cond,_=base.gls_step(ev["H"],ev["r"],L,scales)
        scaled_step=float(np.max(np.abs(dp/scales))); clip_factor=1.0
        if scaled_step>5.0:
            clip_factor=5.0/scaled_step; dp*=clip_factor; scaled_step=5.0
        accepted=False; best=None
        for lam in LINE_SEARCH:
            ptrial=p+lam*dp
            if not np.isfinite(ptrial).all(): continue
            trial=evaluator.evaluate(ptrial); qtrial=base.objective(trial["r"],L)
            if qtrial < q-max(1e-10,1e-12*abs(q)):
                best=(lam,ptrial,trial,qtrial); accepted=True; break
        row={"case_id":case_id,"iteration":iteration,"objective":q,"scaled_step_inf":scaled_step,
             "linear_rank":rank,"scaled_design_condition_number":cond,"clip_factor":clip_factor,
             "rho_F51":rho_map["F51"],"rho_G37":rho_map["G37"],"rho_rest":rho_map["REST"],
             "A2_au_d2":float(p[6]*conv)}
        if not accepted:
            row.update({"accepted":False,"lambda":0.0,"relative_improvement":0.0}); history.append(row)
            if scaled_step<=1e-4:
                converged=True; status="STATIONARY_NO_RESOLVABLE_IMPROVEMENT"
            else: status="LINE_SEARCH_FAILED"
            break
        lam,pnew,evnew,qnew=best; rel=float((q-qnew)/max(abs(q),1.0))
        row.update({"accepted":True,"lambda":lam,"trial_objective":qnew,"relative_improvement":rel,
                    "trial_A2_au_d2":float(pnew[6]*conv)}); history.append(row)
        p,ev,q=pnew,evnew,qnew
        if lam*scaled_step<=1e-4 and rel<=1e-8:
            converged=True; status="CONVERGED"; break
    ev=evaluator.evaluate(p); q=base.objective(ev["r"],L)
    V,rank,cond=base.correlated_covariance(ev["H"],L,scales)
    sigma_raw_m=math.sqrt(max(float(V[6,6]),0.0)); red=q/DOF; infl=max(1.0,math.sqrt(red))
    sigma_scaled_au=abs(sigma_raw_m*conv)*infl; a2=float(p[6]*conv)
    lo,hi=a2-1.96*sigma_scaled_au,a2+1.96*sigma_scaled_au
    result={"case_id":case_id,"rho_F51":float(rho_map["F51"]),"rho_G37":float(rho_map["G37"]),"rho_rest":float(rho_map["REST"]),
            "converged":bool(converged),"status":status,"iterations":len(history),"final_objective":q,
            "reduced_correlated_chi2":red,"A2_au_d2":a2,"sigma_A2_raw_au_d2":abs(sigma_raw_m*conv),
            "sigma_A2_overdispersion_scaled_au_d2":sigma_scaled_au,"normal_approx_95_lo_au_d2":lo,
            "normal_approx_95_hi_au_d2":hi,"interval_excludes_zero":bool(lo>0 or hi<0),
            "negative_zero_excluding_interval":bool(hi<0),"scaled_design_rank":rank,
            "scaled_design_condition_number":cond,"final_parameter_vector":p.tolist()}
    cdir=output_root/'heterogeneous_correlation'/case_id; cdir.mkdir(parents=True,exist_ok=True)
    dump_json(cdir/'final_result.json',result)
    pd.DataFrame(history).to_csv(cdir/'iteration_history.csv',index=False,float_format='%.17g')
    ev['residuals'].to_csv(cdir/'final_residuals.csv',index=False)
    return result,history


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--project-root',type=Path,required=True)
    ap.add_argument('--package-root',type=Path,default=Path(__file__).resolve().parents[1])
    ap.add_argument('--output-root',type=Path,default=None)
    ap.add_argument('--rho-values',default='0,0.5,0.9')
    ap.add_argument('--max-outer-iterations',type=int,default=8)
    ap.add_argument('--keep-work',action='store_true')
    args=ap.parse_args()
    project_root=args.project_root.resolve(); package_root=args.package_root.resolve()
    output_root=(args.output_root.resolve() if args.output_root else project_root/'results/pss5a_robustness_v100')
    output_root.mkdir(parents=True,exist_ok=True)
    vals=[float(x) for x in args.rho_values.split(',') if x.strip()]
    if any(x<0 or x>=1 for x in vals): raise RuntimeError('rho must satisfy 0 <= rho < 1')
    summary,bcov,bdesign,br,bsigma,p0,scales,conv=base.load_baseline(package_root)
    # Same frozen hash and Tudat readiness gates as PSS3-A2.
    hash_audit={}
    for rel,expected in base.EXPECTED_HASHES.items():
        path=project_root/rel; actual=base.sha256_file(path) if path.is_file() else None
        hash_audit[rel]={"expected":expected,"actual":actual,"match":actual==expected}
    dump_json(output_root/'PSS5A_SOURCE_HASH_AUDIT.json',hash_audit)
    if not all(x['match'] for x in hash_audit.values()): raise RuntimeError('frozen source/input hash gate failed')
    try: import tudatpy
    except Exception as exc: raise RuntimeError('tudatpy not importable; use darkcomet-tudat-clean Python') from exc
    work_root=Path(tempfile.mkdtemp(prefix='P5A_')); evaluator=base.Evaluator(project_root,package_root,work_root)
    runtime_env = {
        "python_executable": sys.executable,
        "python_env_root": str(Path(sys.executable).resolve().parent),
        "PATH_prefix": os.environ.get("PATH", "").split(os.pathsep)[:12],
        "PSS5A_DLL_SEARCH_DIRS": os.environ.get("PSS5A_DLL_SEARCH_DIRS"),
    }
    dump_json(output_root/'PSS5A_RUNTIME_ENVIRONMENT.json', runtime_env)
    failure = None
    try:
        baseline_ev=evaluator.evaluate(p0)
        replay=base.baseline_replay_gate(baseline_ev,summary,bcov,bdesign,br,bsigma)
        dump_json(output_root/'PSS5A_BASELINE_REPLAY.json',replay)
        if not replay['overall_pass']: raise RuntimeError('baseline replay failed')
        prep,idx,err,scalar_blocks,scalar_stations,components=crosswalk_station_metadata(project_root,baseline_ev['residuals'])
        sigma=baseline_ev['sigma']
        cases=[]
        for rf,rg,rr in itertools.product(vals,vals,vals):
            cid=f"F51_{rf:g}__G37_{rg:g}__REST_{rr:g}".replace('.','p')
            cases.append((cid,{"F51":rf,"G37":rg,"REST":rr}))
        results=[]; histories=[]
        for cid,rmap in cases:
            r,h=optimize_case(cid,rmap,evaluator,p0,scales,scalar_blocks,scalar_stations,components,sigma,conv,args.max_outer_iterations,output_root)
            results.append(r); histories.extend(h)
        df=pd.DataFrame(results); df.to_csv(output_root/'PSS5A_HETEROGENEOUS_RHO_SUMMARY.csv',index=False,float_format='%.17g')
        pd.DataFrame(histories).to_csv(output_root/'PSS5A_HETEROGENEOUS_RHO_ITERATIONS.csv',index=False,float_format='%.17g')
        ref=pd.read_csv(package_root/'reference/PSS3A2_RHO_SUMMARY.csv')
        checks=[]
        for rho in vals:
            if rho not in (0.0,0.5,0.9): continue
            got=df[(df.rho_F51==rho)&(df.rho_G37==rho)&(df.rho_rest==rho)]
            old=ref[np.isclose(ref['rho'],rho)]
            if len(got)==1 and len(old)==1:
                g=float(got.iloc[0].A2_au_d2); o=float(old.iloc[0].A2_au_d2)
                rel=abs(g-o)/max(abs(o),1e-30)
                checks.append({"rho":rho,"new_A2":g,"pss3a2_A2":o,"relative_difference":rel,"pass":rel<=1e-5})
        pd.DataFrame(checks).to_csv(output_root/'PSS5A_HOMOGENEOUS_REPLAY_CROSSCHECK.csv',index=False)
        validation={
            "stage":"PSS-5A heterogeneous correlation stress grid","version":"1.0.0","scientific_fit_executed":True,
            "rho_values":vals,"n_cases":len(cases),"all_cases_converged":bool(df.converged.all()),
            "all_cases_negative_zero_excluding":bool(df.negative_zero_excluding_interval.all()),
            "A2_min_au_d2":float(df.A2_au_d2.min()),"A2_max_au_d2":float(df.A2_au_d2.max()),
            "sigma_scaled_min_au_d2":float(df.sigma_A2_overdispersion_scaled_au_d2.min()),
            "sigma_scaled_max_au_d2":float(df.sigma_A2_overdispersion_scaled_au_d2.max()),
            "homogeneous_replay_crosscheck_pass":bool(checks and all(x['pass'] for x in checks)),
            "total_tudat_linearizations":int(evaluator.eval_count),
            "PHYSICAL_A2_DETECTION_AUTHORIZED":False,"YARKOVSKY_DETECTION_AUTHORIZED":False,
            "claim_boundary_reason":"Heterogeneous fixed-support correlation stress tests do not supersede support-resampling zero crossings, G37 practical-identifiability limits, cross-code non-transferability, or radar non-closure."
        }
        validation['PSS5A1_HETEROGENEOUS_CORRELATION_CLOSURE_READY']=bool(validation['all_cases_converged'] and validation['homogeneous_replay_crosscheck_pass'])
        dump_json(output_root/'PSS5A1_HETEROGENEOUS_CORRELATION_VALIDATION.json',validation)
        print(json.dumps(validation,indent=2))
        return 0 if validation['PSS5A1_HETEROGENEOUS_CORRELATION_CLOSURE_READY'] else 2
    except Exception as exc:
        failure = {
            "stage": "PSS-5A1 heterogeneous correlation stress grid",
            "version": "1.0.2-runtime-dll-hotfix",
            "error_type": type(exc).__name__,
            "error": str(exc),
            "traceback": traceback.format_exc(),
            "work_root": str(work_root),
            "tudat_linearizations_attempted": int(getattr(evaluator, "eval_count", 0)),
            "scientific_protocol_changed": False,
        }
        dump_json(output_root/'PSS5A1_FAILURE.json', failure)
        # Preserve any Tudat linearization log(s) in the stable output root.
        logs = sorted(work_root.rglob('tudat_linearization.log'))
        log_dir = output_root/'PSS5A1_FAILURE_LOGS'; log_dir.mkdir(parents=True, exist_ok=True)
        for i, log in enumerate(logs, start=1):
            shutil.copy2(log, log_dir/f'tudat_linearization_{i:03d}.log')
        print(json.dumps(failure, indent=2))
        return 3
    finally:
        keep = args.keep_work or failure is not None
        if keep: print('PSS5A_WORK_ROOT='+str(work_root))
        else: shutil.rmtree(work_root,ignore_errors=True)

if __name__=='__main__': raise SystemExit(main())
