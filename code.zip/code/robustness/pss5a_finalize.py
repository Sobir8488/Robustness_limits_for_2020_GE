from pathlib import Path
import argparse, json, hashlib, zipfile

def sha(p):
    h=hashlib.sha256();
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--project-root',type=Path,required=True); ap.add_argument('--output-root',type=Path,required=True); args=ap.parse_args()
    out=args.output_root.resolve(); proj=args.project_root.resolve()
    hpath=out/'PSS5A1_HETEROGENEOUS_CORRELATION_VALIDATION.json'; gpath=out/'PSS5A_G37_THRESHOLD_VALIDATION.json'; failpath=out/'PSS5A1_FAILURE.json'
    h=json.loads(hpath.read_text()) if hpath.exists() else {}; g=json.loads(gpath.read_text()) if gpath.exists() else {}; failure=json.loads(failpath.read_text()) if failpath.exists() else None
    final={'stage':'PSS-5A low-cost robustness closure','version':'1.0.2-runtime-dll-hotfix','heterogeneous_correlation':h,'heterogeneous_correlation_failure':failure,'g37_threshold_sensitivity':g,
      'A3_EXACT_R2_NULL_TEST_EXECUTED':False,
      'A3_reason':'The frozen Tudat model family contains M0, M_SRP, M_Y and M_SY only. Substituting a constant empirical cross-track acceleration would not be the same r^-2 normal A3 law, so no surrogate test is reported.',
      'PSS5A1_READY':bool(h.get('PSS5A1_HETEROGENEOUS_CORRELATION_CLOSURE_READY',False)),
      'PSS5A2_READY':bool(g.get('PSS5A2_G37_THRESHOLD_CLOSURE_READY',False)),
      'PSS5A_LOW_COST_ROBUSTNESS_CLOSURE_READY':bool(h.get('PSS5A1_HETEROGENEOUS_CORRELATION_CLOSURE_READY',False) and g.get('PSS5A2_G37_THRESHOLD_CLOSURE_READY',False)),
      'PHYSICAL_A2_DETECTION_AUTHORIZED':False,'YARKOVSKY_DETECTION_AUTHORIZED':False}
    (out/'PSS5A_VALIDATION.json').write_text(json.dumps(final,indent=2)+'\n',encoding='utf-8')
    report=['# PSS-5A final report','',f"Heterogeneous correlation closure: **{final['PSS5A1_READY']}**.",f"G37 threshold closure: **{final['PSS5A2_READY']}**.",'',
      'The exact r^-2 A3 null model is not present in the frozen model family. No constant empirical cross-track surrogate is substituted.','',
      'No physical A2 or Yarkovsky detection is authorized by PSS-5A. The wider support-resampling, cross-code and radar boundaries remain controlling.']
    (out/'PSS5A_FINAL_REPORT.md').write_text('\n'.join(report)+'\n',encoding='utf-8')
    rows=[]
    for p in sorted(out.rglob('*')):
        if p.is_file() and p.name!='MANIFEST_SHA256.txt': rows.append(f"{sha(p)}  {p.relative_to(out).as_posix()}")
    (out/'MANIFEST_SHA256.txt').write_text('\n'.join(rows)+'\n',encoding='utf-8')
    archive=proj/'2020_GE_PSS5A_OUTPUTS_v1_0_2.zip'
    if archive.exists(): archive.unlink()
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in sorted(out.rglob('*')):
            if p.is_file(): z.write(p,arcname=f"2020_GE_PSS5A_OUTPUTS_v1_0_1/{p.relative_to(out).as_posix()}")
    final['output_archive']={'path':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive)}
    (out/'PSS5A_VALIDATION.json').write_text(json.dumps(final,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(final,indent=2)); print('PSS5A_OUTPUT_ARCHIVE='+str(archive)); return 0 if final['PSS5A_LOW_COST_ROBUSTNESS_CLOSURE_READY'] else 2
if __name__=='__main__': raise SystemExit(main())
