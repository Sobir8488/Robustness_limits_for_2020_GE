# Authors and affiliations

1. **Sirojiddin Turaev**  
   Karshi State Technical University, 225 Mustaqillik Str., Karshi 180100, Uzbekistan.

2. **Qudratillo Yuldoshev**  
   Ulugh Beg Astronomical Institute, Uzbekistan Academy of Sciences, 33 Astronomy Str., Tashkent 100052, Uzbekistan.

3. **Sobir Turaev** — **Corresponding author**  
   Ulugh Beg Astronomical Institute, Uzbekistan Academy of Sciences, 33 Astronomy Str., Tashkent 100052, Uzbekistan.

4. **Davron Ismoilov**  
   Karshi State Technical University, 225 Mustaqillik Str., Karshi 180100, Uzbekistan.

Corresponding-author email and ORCID identifiers remain pending.
