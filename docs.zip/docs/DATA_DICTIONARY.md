# Data dictionary

## Optical inputs
- `2020_GE_ades.csv`: source optical astrometry catalogue used by the project ingest.
- `2020_GE_prepared_fallback_1.csv`: canonical prepared 51-position optical workset.
- `fallback_0.5` and `fallback_1.5`: alternate fallback-weight worksets.
- `2020_GE_ades__uniform_1arcsec.csv`, `...station_floor...csv`: standard-weighting sensitivity inputs.

## Radar inputs
- `2020_GE__jpl_sb_radar_astrometry.csv`: seven radar measurements used for diagnostic continuation/holdout tests.
- `2020_GE__radar_observables_tudat.csv`: Tudat-ready radar observable representation.
- `2020_GE__jpl_sb_radar_station_coordinates.json`: station-coordinate metadata.
- `2020_GE__jpl_sb_radar_raw.json`: captured source response used to derive the tabular radar file.

## Results
CSV/JSON files preserve the units encoded in their headers/keys. The primary transverse parameter A2 is reported in au d^-2 unless a filename/header explicitly scales it by 1e-12. Angular residuals are in arcsec. Radar normalized residuals are dimensionless.
