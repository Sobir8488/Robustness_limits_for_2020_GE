# Reproducibility levels

1. **Direct inspection — complete in this deposit.** Main result tables, robustness summaries, cross-code outputs, and figures are included in machine-readable/vector form.
2. **Figure replay — complete in this deposit.** Figure source data and plotting scripts are included.
3. **Tudat analysis replay — source/input complete; runtime-dependent.** Frozen scripts/configuration/input tables are included; TudatPy/SPICE must be installed.
4. **OrbFit replay — provenance complete; external executable/data required.** OrbFit 5.0.8 and its native DE431/AST17 runtime assets are not redistributed here. Exact hashes/provenance are recorded.
5. **Historical Golevka positive control — bounded provenance only.** The deposit retains the claim boundary ledgers rather than asserting a new full reconstruction.
